# EduConnect Frontend — Angular 19

A complete, production-ready Angular 19 frontend for the **EduConnect Digital Education & E-Learning Governance System**. Built following the exact backend microservices structure from the prototype.

---

## 🏗 Architecture

| Layer | Technology |
|---|---|
| Framework | Angular 19 (Standalone Components, no NgModules) |
| Routing | Angular Router with lazy loading per role |
| State | Angular Signals + RxJS |
| Forms | Reactive Forms with custom validators |
| HTTP | HttpClient + functional interceptors |
| Styling | Custom SCSS — Navy/Accent/Mint/Gold theme |
| Auth | JWT Bearer token via localStorage |
| Font | Plus Jakarta Sans + Fraunces (Google Fonts) |
| Icons | Bootstrap Icons (CDN) |

---

## 📁 Project Structure

```
src/app/
├── core/
│   ├── models/index.ts          ← All TypeScript types mapped 1:1 to Java enums/DTOs
│   ├── services/
│   │   ├── auth.service.ts      ← Login, register, JWT session (Angular Signals)
│   │   └── index.ts             ← All 12 backend API services + ToastService
│   ├── interceptors/index.ts    ← jwtInterceptor + errorInterceptor
│   └── guards/index.ts          ← authGuard, roleGuard, guestGuard
│
├── modules/
│   ├── auth/
│   │   ├── login/               ← Login form + demo accounts
│   │   └── register/            ← Student self-registration (password-match validator)
│   │
│   ├── student/
│   │   ├── dashboard/           ← Welcome card, progress ring, stats, deadlines
│   │   ├── courses/             ← Course cards with enroll CTA, tabs, search
│   │   ├── assessments/         ← Quiz/Test list, submit modal with URL input
│   │   ├── progress/            ← Per-course progress bars with overall ring
│   │   └── profile/             ← Edit student profile
│   │
│   ├── teacher/
│   │   ├── dashboard/           ← Stats, my courses, pending grading
│   │   ├── courses/             ← Create/edit courses (CRUD)
│   │   ├── content/             ← Upload videos/PDFs/docs, archive
│   │   ├── assessments/         ← Create quiz/exam, activate, grade submissions
│   │   └── students/            ← Enrolled students + progress per course
│   │
│   └── admin/
│       ├── dashboard/           ← Platform-wide KPIs, user list, quick actions
│       ├── users/               ← Full user management, create staff, activate/deactivate
│       ├── courses/             ← View all platform courses with filters
│       ├── compliance/          ← Compliance records CRUD, set result
│       ├── audits/              ← Formal audits, initiate, update status
│       └── reports/             ← Dashboard metrics, generate reports by scope
│
└── shared/
    ├── components/
    │   ├── shell/               ← Main layout (sidebar + topbar + router-outlet)
    │   ├── sidebar/             ← Role-aware navigation (computed from UserRole signal)
    │   ├── topbar/              ← Search bar, notification bell, avatar
    │   ├── toast/               ← Global toast container (success/error/info/warning)
    │   └── error-pages/         ← Unauthorized (403) page
    └── (pipes, directives — extend here)
```

---

## 🔐 Role-Based Access Control

| Role | Registers | Dashboard Route | Access |
|---|---|---|---|
| **STUDENT** | Self (public) | `/student/dashboard` | Courses, Assessments, Progress, Profile |
| **TEACHER** | Admin creates | `/teacher/dashboard` | Courses, Content, Assessments, Students |
| **ADMIN** | Admin creates | `/admin/dashboard` | Full platform access |
| **PROGRAM_MANAGER** | Admin creates | `/admin/dashboard` | Dashboard, Courses, Reports |
| **COMPLIANCE_OFFICER** | Admin creates | `/admin/compliance` | Compliance, Audits |
| **GOVERNMENT_AUDITOR** | Admin creates | `/admin/audits` | Audits (view/update) |

### Guards
```typescript
authGuard          // Redirects to /login if not authenticated
roleGuard(roles)   // Redirects to /unauthorized if wrong role
guestGuard         // Redirects to dashboard if already logged in
```

---

## 🔌 API Services — Exact Backend Mapping

| Service | Base URL | Java Microservice |
|---|---|---|
| AuthService | `/auth` | auth-service |
| AdminUserService | `/admin` | admin management in auth-service |
| StudentService | `/students` | student-service |
| CourseService | `/courses` | course-service |
| EnrollmentService | `/enrollments` | enrollment-service |
| ProgressService | `/progress` | progress-service |
| AssessmentService | `/assessments` | assessment-service |
| ContentService | `/contents` | content-service |
| NotificationService | `/notifications` | notification-service |
| ComplianceService | `/compliance` | compliance-service |
| AuditService | `/audits` | compliance-service (audits) |
| ReportService | `/reports` | report-service |

All URLs can be changed in `src/environments/environment.ts`.

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm 9+

### Install & Run
```bash
cd educonnect-frontend
npm install
npm start
# → http://localhost:4200
```

### Build for production
```bash
npm run build
```

### Demo Login Accounts (shown on login page)
| Role | Email | Password |
|---|---|---|
| Admin | admin@edu.com | Admin@1234 |
| Student | alice@edu.com | Alice@1234 |
| Teacher | bob@edu.com | Bob@12345 |

---

## 🎨 Design System

The UI faithfully reproduces the EduConnect theme with:

- **Palette**: Navy `#0D1B3E` · Accent Blue `#2E7BF6` · Mint `#00C9A7` · Gold `#F0A500`
- **Typography**: Fraunces (display headings) + Plus Jakarta Sans (body)
- **Components**: Cards, badges, data tables, modals, toasts, progress bars — all in SCSS with CSS custom properties
- **Animations**: CSS keyframes for slide-up, fade-in, progress ring draw, loading pulse
- **Responsive**: CSS Grid + Flexbox, breakpoints at 520/640/900/1280px

---

## 📝 Extending the App

### Add a new page under Student
1. Create component in `src/app/modules/student/new-page/`
2. Add route to `app.routes.ts` under the `student` parent
3. Add nav item to `sidebar.component.ts` with `roles: [UserRole.STUDENT]`
4. Add API call to `core/services/index.ts` if needed

### Add a new enum
Add to `core/models/index.ts` — mirror exactly from Java enum name/values.

### Change API gateway URL
Edit `src/environments/environment.ts`.
