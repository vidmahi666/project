// =============================================
// CORE MODELS — EduConnect
// =============================================

export type UserRole =
  | 'STUDENT'
  | 'TEACHER'
  | 'ADMIN'
  | 'PROGRAM_MANAGER'
  | 'COMPLIANCE_OFFICER'
  | 'GOVERNMENT_AUDITOR';

export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';
export type CourseStatus = 'DRAFT' | 'ACTIVE' | 'COMPLETED' | 'ARCHIVED';
export type AssessmentType = 'QUIZ' | 'TEST' | 'ASSIGNMENT' | 'PROJECT';
export type AssessmentStatus = 'DRAFT' | 'ACTIVE' | 'CLOSED' | 'ARCHIVED';
export type ContentType = 'VIDEO' | 'PDF' | 'QUIZ' | 'DOCUMENT' | 'PRESENTATION';
export type ContentStatus = 'ACTIVE' | 'ARCHIVED';
export type SubmissionStatus = 'SUBMITTED' | 'GRADED' | 'REJECTED';
export type EnrollmentStatus = 'ENROLLED' | 'COMPLETED' | 'DROPPED';
export type ProgressStatus = 'IN_PROGRESS' | 'COMPLETED';
export type NotificationCategory = 'COURSE' | 'ASSESSMENT' | 'PROGRAM' | 'COMPLIANCE' | 'SYSTEM';
export type NotificationStatus = 'UNREAD' | 'READ' | 'ARCHIVED';
export type DocumentType = 'ID_PROOF' | 'TRANSCRIPT';
export type VerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';

// ── API Wrapper ──────────────────────────────
export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data: T;
  timestamp?: string;
}

// ── Auth ─────────────────────────────────────
export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
  role: UserRole;
}

export interface AuthResponse {
  token: string;
  userId: number;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
}

// ── User ──────────────────────────────────────
export interface User {
  userId: number;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  createdAt?: string;
  updatedAt?: string;
}

// ── Student ───────────────────────────────────
export interface Student {
  studentId: number;
  userId: number;
  name: string;
  dob?: string;
  gender?: string;
  address?: string;
  contactInfo?: string;
  status: UserStatus;
}

export interface StudentDocument {
  documentId: number;
  studentId: number;
  documentType: DocumentType;
  fileUri: string;
  verificationStatus: VerificationStatus;
  uploadedAt?: string;
}

// ── Course ─────────────────────────────────────
export interface Course {
  courseId: number;
  title: string;
  description: string;
  teacherId: number;
  teacherName?: string;
  startDate: string;
  endDate: string;
  status: CourseStatus;
  createdAt?: string;
}

export interface CourseRequest {
  title: string;
  description: string;
  teacherId: number;
  startDate: string;
  endDate: string;
}

// ── Enrollment ─────────────────────────────────
export interface Enrollment {
  enrollmentId: number;
  studentId: number;
  courseId: number;
  studentName?: string;
  courseTitle?: string;
  status: EnrollmentStatus;
  enrollmentDate?: string;
}

export interface EnrollmentRequest {
  studentId: number;
  courseId: number;
}

// ── Progress ───────────────────────────────────
export interface Progress {
  progressId: number;
  studentId: number;
  courseId: number;
  studentName?: string;
  courseTitle?: string;
  completionPercentage: number;
  status: ProgressStatus;
  lastUpdated?: string;
}

// ── Content ────────────────────────────────────
export interface Content {
  contentId: number;
  courseId: number;
  courseTitle?: string;
  title: string;
  description?: string;
  type: ContentType;
  fileUri: string;
  status: ContentStatus;
  uploadedAt?: string;
}

export interface ContentRequest {
  courseId: number;
  title: string;
  description?: string;
  type: ContentType;
  fileUri: string;
}

// ── Assessment ─────────────────────────────────
export interface Assessment {
  assessmentId: number;
  courseId: number;
  courseTitle?: string;
  title: string;
  description?: string;
  type: AssessmentType;
  maxScore: number;
  dueDate: string;
  status: AssessmentStatus;
  createdAt?: string;
}

export interface AssessmentRequest {
  courseId: number;
  title: string;
  description?: string;
  type: AssessmentType;
  maxScore: number;
  dueDate: string;
}

// ── Submission ─────────────────────────────────
export interface Submission {
  submissionId: number;
  assessmentId: number;
  studentId: number;
  studentName?: string;
  assessmentTitle?: string;
  fileUri: string;
  score?: number;
  feedback?: string;
  status: SubmissionStatus;
  submittedAt?: string;
}

export interface SubmissionRequest {
  assessmentId: number;
  studentId: number;
  fileUri: string;
}

export interface GradeRequest {
  score: number;
  feedback?: string;
}

// ── Notification ───────────────────────────────
export interface Notification {
  notificationId: number;
  userId: number;
  message: string;
  category: NotificationCategory;
  status: NotificationStatus;
  createdDate?: string;
}

// ── Compliance ─────────────────────────────────
export interface ComplianceRecord {
  recordId: number;
  entityId: number;
  entityType: string;
  checkType: string;
  result: string;
  resolutionNotes?: string;
  createdAt?: string;
}

// ── Audit ──────────────────────────────────────
export interface Audit {
  auditId: number;
  officerId: number;
  scope: string;
  findings?: string;
  status: string;
  createdAt?: string;
}

// ── Report ─────────────────────────────────────
export interface DashboardMetrics {
  totalStudents: number;
  totalCourses: number;
  totalEnrollments: number;
  totalAssessments: number;
  completionRate: number;
  activeStudents: number;
  activeCourses: number;
}
