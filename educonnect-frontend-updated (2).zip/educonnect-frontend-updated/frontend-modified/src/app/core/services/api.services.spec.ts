declare const describe: any;
declare const it: any;
declare const beforeEach: any;
declare const afterEach: any;
declare const expect: any;

import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {
  AdminService,
  StudentService,
  CourseService,
  EnrollmentService,
  ProgressService,
  AssessmentService,
  ContentService,
  NotificationService,
  ReportService,
  ComplianceService,
} from './api.services';
import { ApiResponse, CourseRequest, GradeRequest, ContentRequest } from '../models/models';

/**
 * These tests cover the shared API service wiring and HTTP request generation.
 * They do not require a full backend and use HttpClientTestingModule.
 */

describe('Api Services', () => {
  let httpMock: HttpTestingController;
  let adminService: AdminService;
  let studentService: StudentService;
  let courseService: CourseService;
  let enrollmentService: EnrollmentService;
  let progressService: ProgressService;
  let assessmentService: AssessmentService;
  let contentService: ContentService;
  let notificationService: NotificationService;
  let reportService: ReportService;
  let complianceService: ComplianceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        AdminService,
        StudentService,
        CourseService,
        EnrollmentService,
        ProgressService,
        AssessmentService,
        ContentService,
        NotificationService,
        ReportService,
        ComplianceService,
      ],
    });

    httpMock = TestBed.inject(HttpTestingController);
    adminService = TestBed.inject(AdminService);
    studentService = TestBed.inject(StudentService);
    courseService = TestBed.inject(CourseService);
    enrollmentService = TestBed.inject(EnrollmentService);
    progressService = TestBed.inject(ProgressService);
    assessmentService = TestBed.inject(AssessmentService);
    contentService = TestBed.inject(ContentService);
    notificationService = TestBed.inject(NotificationService);
    reportService = TestBed.inject(ReportService);
    complianceService = TestBed.inject(ComplianceService);
  });

  afterEach(() => {
    httpMock.verify();
  });

  describe('AdminService', () => {
    it('should fetch all users', () => {
      const expected: ApiResponse<any[]> = { success: true, message: 'OK', data: [{ userId: 1, name: 'Alice', email: 'alice@test.com', role: 'ADMIN', status: 'ACTIVE', createdAt: '', updatedAt: '' }] };

      adminService.getAllUsers().subscribe(result => expect(result).toEqual(expected));
      const req = httpMock.expectOne((request) => request.method === 'GET' && request.url.endsWith('/users'));
      expect(req.request.method).toBe('GET');
      req.flush(expected);
    });

    it('should deactivate and activate a user', () => {
      const userId = 5;

      adminService.deactivateUser(userId).subscribe(result => expect(result.success).toBeTrue());
      let req = httpMock.expectOne((request) => request.method === 'PATCH' && request.url.endsWith(`/users/${userId}/deactivate`));
      expect(req.request.method).toBe('PATCH');
      req.flush({ success: true, message: 'Deactivated', data: null });

      adminService.activateUser(userId).subscribe(result => expect(result.success).toBeTrue());
      req = httpMock.expectOne((request) => request.method === 'PATCH' && request.url.endsWith(`/users/${userId}/activate`));
      expect(req.request.method).toBe('PATCH');
      req.flush({ success: true, message: 'Activated', data: null });
    });
  });

  describe('StudentService', () => {
    it('should fetch student and student documents', () => {
      const studentId = 10;

      studentService.getStudentById(studentId).subscribe(result => expect(result.data?.studentId).toBe(studentId));
      let req = httpMock.expectOne((request) => request.method === 'GET' && request.url.endsWith(`/${studentId}`));
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, message: 'OK', data: { studentId, userId: 20, name: 'Student', status: 'ACTIVE' } });

      studentService.getDocuments(studentId).subscribe(result => expect(result.data).toEqual([{ id: 1 }]));
      req = httpMock.expectOne((request) => request.method === 'GET' && request.url.endsWith(`/${studentId}/documents`));
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, message: 'OK', data: [{ id: 1 }] });
    });
  });

  describe('CourseService', () => {
    it('should create and update course', () => {
      const payload: CourseRequest = { title: 'Test Course', description: 'Desc', teacherId: 1, startDate: '2026-01-01', endDate: '2026-12-31' };
      const course = { courseId: 1, ...payload, status: 'ACTIVE', createdAt: '' };

      courseService.createCourse(payload).subscribe(result => expect(result.data).toEqual(course));
      let req = httpMock.expectOne((request) => request.method === 'POST' && request.url.endsWith('/courses'));
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, message: 'Created', data: course });

      courseService.updateCourse(course.courseId, { title: 'Updated' }).subscribe(result => expect(result.data?.title).toBe('Updated'));
      req = httpMock.expectOne((request) => request.method === 'PUT' && request.url.endsWith(`/courses/${course.courseId}`));
      expect(req.request.method).toBe('PUT');
      req.flush({ success: true, message: 'Updated', data: { ...course, title: 'Updated' } });
    });
  });

  describe('EnrollmentService', () => {
    it('should enroll and update status', () => {
      const payload = { studentId: 1, courseId: 2 };

      enrollmentService.enroll(payload).subscribe(result => expect(result.data?.studentId).toBe(payload.studentId));
      let req = httpMock.expectOne((request) => request.method === 'POST' && request.url.endsWith('/enrollments'));
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, message: 'Enrolled', data: { enrollmentId: 1, ...payload, status: 'ENROLLED' } });

      const enrollmentId = 1;
      enrollmentService.updateStatus(enrollmentId, 'INACTIVE').subscribe(result => expect(result.success).toBeTrue());
      req = httpMock.expectOne((request) => request.method === 'PATCH' && request.url.endsWith(`/enrollments/${enrollmentId}/status`));
      expect(req.request.method).toBe('PATCH');
      expect(req.request.params.get('status')).toBe('INACTIVE');
      req.flush({ success: true, message: 'OK', data: null });
    });
  });

  describe('ProgressService', () => {
    it('should init and update progress', () => {
      const studentId = 1;
      const courseId = 2;
      const response: ApiResponse<any> = { success: true, message: 'OK', data: { progressId: 1, studentId, courseId, completionPercentage: 10, status: 'IN_PROGRESS', lastUpdated: '' } };

      progressService.initProgress(studentId, courseId, 'Student A', 'Course A').subscribe(result => expect(result).toEqual(response));
      let req = httpMock.expectOne((request) => request.method === 'POST' && request.url.endsWith('/init'));
      expect(req.request.params.get('studentName')).toBe('Student A');
      expect(req.request.params.get('courseTitle')).toBe('Course A');
      req.flush(response);

      progressService.updateProgress(studentId, courseId, { completionPercentage: 50 }).subscribe(result => expect(result.success).toBeTrue());
      req = httpMock.expectOne((request) => request.method === 'PUT' && request.url.endsWith(`/student/${studentId}/course/${courseId}`));
      expect(req.request.method).toBe('PUT');
      req.flush({ success: true, message: 'Updated', data: response.data });
    });
  });

  describe('AssessmentService', () => {
    it('should create assessment and grade submission', () => {
      const payload = { courseId: 5, title: 'Test', description: 'Desc', type: 'QUIZ', maxScore: 100, dueDate: '2026-12-31' };

      assessmentService.create(payload as any).subscribe(result => expect(result.data?.title).toBe('Test'));
      let req = httpMock.expectOne((request) => request.method === 'POST' && request.url.endsWith('/assessments'));
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, message: 'Created', data: { assessmentId: 1, ...payload, status: 'DRAFT', createdAt: '' } });

      const gradePayload: GradeRequest = { score: 80, feedback: 'Good' };
      assessmentService.grade(99, gradePayload).subscribe(result => expect(result.success).toBeTrue());
      req = httpMock.expectOne((request) => request.method === 'PATCH' && request.url.endsWith('/submissions/99/grade'));
      expect(req.request.method).toBe('PATCH');
      req.flush({ success: true, message: 'Graded', data: null });
    });
  });

  describe('ContentService', () => {
    it('should upload content and update status', () => {
      const payload: ContentRequest = { courseId: 10, title: 'Video', description: 'Desc', type: 'VIDEO', fileUri: 'https://file' };

      contentService.upload(payload).subscribe(result => expect(result.data?.title).toBe('Video'));
      let req = httpMock.expectOne((request) => request.method === 'POST' && request.url.endsWith('/contents'));
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, message: 'Uploaded', data: { contentId: 1, ...payload, status: 'ACTIVE' } });

      contentService.updateStatus(1, 'ARCHIVED').subscribe(result => expect(result.success).toBeTrue());
      req = httpMock.expectOne((request) => request.method === 'PATCH' && request.url.endsWith('/contents/1/status'));
      expect(req.request.method).toBe('PATCH');
      expect(req.request.params.get('status')).toBe('ARCHIVED');
      req.flush({ success: true, message: 'Updated', data: null });
    });
  });

  describe('NotificationService', () => {
    it('should fetch unread notifications and archive one', () => {
      const userId = 7;
      notificationService.getUnread(userId).subscribe(result => expect(result.data?.length).toBe(2));
      let req = httpMock.expectOne((request) => request.method === 'GET' && request.url.endsWith(`/user/${userId}/unread`));
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, message: 'OK', data: [{ notificationId: 1 }, { notificationId: 2 }] });

      notificationService.archive(1).subscribe(result => expect(result.success).toBeTrue());
      req = httpMock.expectOne((request) => request.method === 'PATCH' && request.url.endsWith('/1/archive'));
      expect(req.request.method).toBe('PATCH');
      req.flush({ success: true, message: 'Archived', data: null });
    });
  });

  describe('ReportService', () => {
    it('should generate and fetch all reports', () => {
      reportService.generateReport('COMPLIANCE', 'admin').subscribe(result => expect(result.success).toBeTrue());
      let req = httpMock.expectOne((request) => request.method === 'POST' && request.url.endsWith('/generate'));
      expect(req.request.method).toBe('POST');
      expect(req.request.params.get('scope')).toBe('COMPLIANCE');
      expect(req.request.params.get('generatedBy')).toBe('admin');
      req.flush({ success: true, message: 'Generated', data: null });

      reportService.getAllReports().subscribe(result => expect(result.data?.length).toBe(1));
      req = httpMock.expectOne((request) => request.method === 'GET' && request.url.endsWith('/reports'));
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, message: 'OK', data: [{ reportId: 1 }] });
    });
  });

  describe('ComplianceService', () => {
    it('should fetch records, update result, and create audits', () => {
      complianceService.getAll().subscribe(result => expect(result.data?.length).toBe(1));
      let req = httpMock.expectOne((request) => request.method === 'GET' && request.url.endsWith('/compliance'));
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, message: 'OK', data: [{ recordId: 2, entityId: 10, entityType: 'CONTENT', checkType: 'ACCESS', result: 'PENDING' }] });

      complianceService.updateResult(2, 'COMPLIANT').subscribe(result => expect(result.success).toBeTrue());
      req = httpMock.expectOne((request) => request.method === 'PATCH' && request.url.endsWith('/compliance/2/result'));
      expect(req.request.method).toBe('PATCH');
      expect(req.request.params.get('result')).toBe('COMPLIANT');
      req.flush({ success: true, message: 'Updated', data: null });

      complianceService.createAudit({ auditId: 5 } as any).subscribe(result => expect(result.data?.auditId).toBe(5));
      req = httpMock.expectOne((request) => request.method === 'POST' && request.url.endsWith('/audits'));
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, message: 'Created', data: { auditId: 5 } });
    });
  });
});
