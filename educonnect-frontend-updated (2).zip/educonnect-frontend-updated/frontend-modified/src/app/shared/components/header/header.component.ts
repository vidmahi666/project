import { Component, computed, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/api.services';
 
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="header">
      <div class="header-left">
        <h3 class="page-title">{{ title() }}</h3>
      </div>
      <div class="header-right">
        <!-- Notifications -->
        <div class="notif-wrap" (click)="toggleNotif()">
          <button class="icon-btn">
            🔔
            @if (unreadCount() > 0) {
              <span class="notif-dot">{{ unreadCount() > 9 ? '9+' : unreadCount() }}</span>
            }
          </button>
          @if (showNotif()) {
            <div class="notif-dropdown">
              <div class="notif-header">
                <span>Notifications</span>
                @if (unreadCount() > 0) {
                  <button class="mark-all" (click)="markAllRead($event)">Mark all read</button>
                }
              </div>
              @if (notifications().length === 0) {
                <div class="notif-empty">No notifications</div>
              }
              @for (n of notifications().slice(0, 6); track n.notificationId) {
                <div class="notif-item" [class.unread]="n.status === 'UNREAD'">
                  <span class="notif-icon">{{ categoryIcon(n.category) }}</span>
                  <div class="notif-body">
                    <p class="notif-msg">{{ n.message }}</p>
                    <span class="notif-time">{{ n.createdDate | date:'short' }}</span>
                  </div>
                </div>
              }
            </div>
          }
        </div>
 
        <!-- User menu -->
        <div class="user-chip">
          <div class="user-av">{{ initials() }}</div>
          <span class="user-nm">{{ displayName() }}</span>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .header {
      position: sticky;
      top: 0;
      height: var(--header-height);
      background: rgba(8,13,26,0.9);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      z-index: 50;
    }
    .page-title {
      font-family: var(--font-display);
      font-size: 1rem;
      font-weight: 600;
      margin: 0;
    }
    .header-right { display: flex; align-items: center; gap: 1rem; }
 
    .icon-btn {
      position: relative;
      background: var(--bg-surface);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-sm);
      width: 36px; height: 36px;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      font-size: 1rem;
      transition: all var(--transition-fast);
    }
    .icon-btn:hover { border-color: var(--border-accent); }
 
    .notif-dot {
      position: absolute;
      top: -4px; right: -4px;
      background: var(--error);
      color: #fff;
      font-size: 0.6rem;
      font-weight: 700;
      width: 16px; height: 16px;
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
    }
    .notif-wrap { position: relative; }
    .notif-dropdown {
      position: absolute;
      top: calc(100% + 8px);
      right: 0;
      width: 320px;
      background: var(--bg-modal);
      border: 1px solid var(--border-soft);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-lift);
      z-index: 200;
      overflow: hidden;
      animation: slideUp 0.2s ease;
    }
    .notif-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.875rem 1rem;
      border-bottom: 1px solid var(--border-subtle);
      font-size: 0.875rem;
      font-weight: 600;
    }
    .mark-all {
      font-size: 0.75rem;
      color: var(--accent-primary);
      background: none;
      border: none;
      cursor: pointer;
    }
    .notif-item {
      display: flex;
      gap: 0.75rem;
      padding: 0.75rem 1rem;
      border-bottom: 1px solid rgba(255,255,255,0.03);
      transition: background var(--transition-fast);
    }
    .notif-item:hover { background: var(--bg-hover); }
    .notif-item.unread { background: rgba(20,184,166,0.04); }
    .notif-icon { font-size: 1.1rem; flex-shrink: 0; }
    .notif-msg { font-size: 0.82rem; color: var(--text-primary); margin: 0 0 0.2rem; }
    .notif-time { font-size: 0.73rem; color: var(--text-muted); }
    .notif-empty { padding: 1.5rem; text-align: center; color: var(--text-muted); font-size: 0.85rem; }
 
    .user-chip {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.25rem 0.75rem 0.25rem 0.25rem;
      background: var(--bg-surface);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
    }
    .user-av {
      width: 28px; height: 28px;
      background: linear-gradient(135deg, var(--teal-600), var(--teal-400));
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 0.7rem;
      font-weight: 700;
      color: #fff;
    }
    .user-nm { font-size: 0.85rem; font-weight: 500; }
  `]
})
export class HeaderComponent implements OnInit {
  user   = this.auth.currentUser;
  notifications = signal<any[]>([]);
  unreadCount   = signal(0);
  showNotif     = signal(false);
 
  title = computed(() => {
    const role = this.auth.getRole();
    const map: Record<string, string> = {
      STUDENT: 'Student Portal',
      TEACHER: 'Teacher Portal',
      ADMIN: 'Admin Console',
      PROGRAM_MANAGER: 'Program Manager',
      COMPLIANCE_OFFICER: 'Compliance Portal',
      GOVERNMENT_AUDITOR: 'Audit Portal',
    };
    return map[role ?? ''] ?? 'EduConnect';
  });
 
  initials = computed(() => {
    const name = this.user()?.name ?? '';
    return name.split(' ').slice(0,2).map((n: string) => n[0]).join('').toUpperCase();
  });
 
  displayName = computed(() => this.user()?.name?.split(' ')[0] ?? '');
 
  constructor(private auth: AuthService, private notifSvc: NotificationService) {}
 
  ngOnInit(): void {
    const userId = this.auth.getUserId();
    if (userId) {
      this.notifSvc.getUnread(userId).subscribe({
        next: res => {
          if (res.success) {
            this.notifications.set(res.data ?? []);
            this.unreadCount.set((res.data ?? []).length);
          }
        },
        error: () => {}
      });
    }
  }
 
  toggleNotif(): void { this.showNotif.update(v => !v); }
 
  markAllRead(e: Event): void {
    e.stopPropagation();
    this.notifications().filter(n => n.status === 'UNREAD').forEach(n => {
      this.notifSvc.markRead(n.notificationId).subscribe();
    });
    this.notifications.update(ns => ns.map(n => ({ ...n, status: 'READ' })));
    this.unreadCount.set(0);
  }
 
  categoryIcon(cat: string): string {
    const m: Record<string, string> = {
      COURSE: '📚', ASSESSMENT: '📝', PROGRAM: '📋',
      COMPLIANCE: '✅', SYSTEM: '⚙️'
    };
    return m[cat] ?? '🔔';
  }
}
 