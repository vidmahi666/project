import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-unauthorized',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="error-page">
      <div class="error-card">
        <div class="error-icon">🔒</div>
        <h1>Access Denied</h1>
        <p>You don't have permission to view this page.</p>
        <p class="sub">Your current role doesn't allow access to this resource.</p>
        <div style="display:flex;gap:0.75rem;justify-content:center;margin-top:2rem">
          <button class="ec-btn ec-btn-secondary" (click)="goBack()">← Go Back</button>
          <button class="ec-btn ec-btn-primary" (click)="goHome()">Go to Dashboard</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .error-page { min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg-void);padding:2rem; }
    .error-card { text-align:center;max-width:440px; }
    .error-icon { font-size:4rem;margin-bottom:1.5rem;animation:pulseGlow 3s infinite; }
    h1 { font-size:2rem;margin-bottom:0.75rem; }
    p { color:var(--text-secondary);margin-bottom:0.25rem; }
    .sub { font-size:0.85rem;color:var(--text-muted); }
  `]
})
export class UnauthorizedComponent {
  constructor(private auth: AuthService) {}
  goBack(): void { history.back(); }
  goHome(): void {
    const role = this.auth.getRole();
    if (role) this.auth.redirectAfterLogin(role);
  }
}
