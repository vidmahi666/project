import { Component, Input, Output, EventEmitter, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { UserRole } from '../../../core/models';

interface NavItem {
  label:  string;
  icon:   string;
  route:  string;
  roles:  UserRole[];
  exact?: boolean;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent {
  @Input() collapsed = false;
  @Output() toggleSidebar = new EventEmitter<void>();

  auth = inject(AuthService);

  roleLabel = computed(() => {
    const labels: Partial<Record<UserRole, string>> = {
      [UserRole.STUDENT]:            'Student',
      [UserRole.TEACHER]:            'Teacher',
      [UserRole.ADMIN]:              'Administrator',
      [UserRole.PROGRAM_MANAGER]:    'Program Manager',
      [UserRole.COMPLIANCE_OFFICER]: 'Compliance Officer',
      [UserRole.GOVERNMENT_AUDITOR]: 'Govt. Auditor',
    };
    return labels[this.auth.role()!] ?? this.auth.role();
  });

  private navItems: NavItem[] = [
    // Student
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',         route: '/student/dashboard',   roles: [UserRole.STUDENT], exact: true },
    { label: 'My Courses',    icon: 'bi-book-fill',              route: '/student/courses',     roles: [UserRole.STUDENT] },
    { label: 'Assessments',   icon: 'bi-pencil-square',          route: '/student/assessments', roles: [UserRole.STUDENT] },
    { label: 'My Progress',   icon: 'bi-bar-chart-fill',         route: '/student/progress',    roles: [UserRole.STUDENT] },
    { label: 'My Profile',    icon: 'bi-person-circle',          route: '/student/profile',     roles: [UserRole.STUDENT] },
    // Teacher
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',         route: '/teacher/dashboard',   roles: [UserRole.TEACHER], exact: true },
    { label: 'My Courses',    icon: 'bi-book-fill',              route: '/teacher/courses',     roles: [UserRole.TEACHER] },
    { label: 'Content',       icon: 'bi-collection-play',        route: '/teacher/content',     roles: [UserRole.TEACHER] },
    { label: 'Assessments',   icon: 'bi-pencil-square',          route: '/teacher/assessments', roles: [UserRole.TEACHER] },
    { label: 'Students',      icon: 'bi-people-fill',            route: '/teacher/students',    roles: [UserRole.TEACHER] },
    // Admin / Program Manager
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',         route: '/admin/dashboard',     roles: [UserRole.ADMIN, UserRole.PROGRAM_MANAGER], exact: true },
    { label: 'User Mgmt',     icon: 'bi-people-fill',            route: '/admin/users',         roles: [UserRole.ADMIN] },
    { label: 'Courses',       icon: 'bi-book-fill',              route: '/admin/courses',       roles: [UserRole.ADMIN, UserRole.PROGRAM_MANAGER] },
    { label: 'Audit Overview',icon: 'bi-shield-fill-check',      route: '/admin/audit-overview',roles: [UserRole.ADMIN] },
    { label: 'Reports',       icon: 'bi-file-earmark-bar-graph', route: '/admin/reports',       roles: [UserRole.ADMIN, UserRole.PROGRAM_MANAGER] },
    // Compliance Officer (isolated portal)
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',         route: '/compliance/dashboard',roles: [UserRole.COMPLIANCE_OFFICER], exact: true },
    // Government Auditor (isolated portal)
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',         route: '/auditor/dashboard',   roles: [UserRole.GOVERNMENT_AUDITOR], exact: true },
  ];

  visibleNav = computed(() => {
    const r = this.auth.role();
    return r ? this.navItems.filter(n => n.roles.includes(r)) : [];
  });
}
