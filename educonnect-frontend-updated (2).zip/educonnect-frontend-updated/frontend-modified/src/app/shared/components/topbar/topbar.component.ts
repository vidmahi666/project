import { Component, Input, Output, EventEmitter, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/index';
import { Notification, NotificationStatus } from '../../../core/models';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './topbar.component.html',
  styleUrls:['./topbar.component.scss'],
})
export class TopbarComponent implements OnInit {
  @Input()  collapsed = false;
  @Output() toggleSidebar = new EventEmitter<void>();
  auth = inject(AuthService);
  private notifSvc = inject(NotificationService);
  searchTerm    = '';
  showNotif     = false;
  notifications = signal<Notification[]>([]);
  unreadCount   = signal(0);

  ngOnInit(): void {
    const uid = this.auth.userId();
    if (uid) {
      this.notifSvc.getUnread(uid).subscribe({ next: r => { if (r.success) { this.notifications.set(r.data ?? []); this.unreadCount.set((r.data ?? []).length); } }, error: () => {} });
    }
  }
  markRead(n: Notification): void {
    if (n.status === NotificationStatus.UNREAD) {
      this.notifSvc.markRead(n.notificationId).subscribe();
      this.notifications.update(l => l.map(x => x.notificationId === n.notificationId ? { ...x, status: NotificationStatus.READ } : x));
      this.unreadCount.update(c => Math.max(0, c - 1));
    }
  }
  markAllRead(): void {
    this.notifications().filter(n => n.status === NotificationStatus.UNREAD).forEach(n => this.notifSvc.markRead(n.notificationId).subscribe());
    this.notifications.update(l => l.map(n => ({ ...n, status: NotificationStatus.READ })));
    this.unreadCount.set(0);
  }
}
