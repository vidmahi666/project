// This file re-exports FormsModule for components that use ngModel
// Already imported directly in each component's imports array
export { FormsModule } from '@angular/forms';
