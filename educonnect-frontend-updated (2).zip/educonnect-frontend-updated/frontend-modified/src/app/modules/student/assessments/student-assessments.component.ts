import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AssessmentService, EnrollmentService, ToastService } from '../../../core/services/index';
import { Assessment, AssessmentType, Submission } from '../../../core/models';

@Component({
  selector: 'app-student-assessments',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './student-assessments.component.html',
  styleUrls: ['./student-assessments.component.scss'],
})
export class StudentAssessmentsComponent implements OnInit {
  private auth      = inject(AuthService);
  private assessSvc = inject(AssessmentService);
  private enrollSvc = inject(EnrollmentService);
  private toast     = inject(ToastService);
  private fb        = inject(FormBuilder);

  loading       = signal(true);
  submitting    = signal(false);
  assessments   = signal<Assessment[]>([]);
  submissions   = signal<Submission[]>([]);
  submittedIds  = signal<Set<number>>(new Set());
  showModal     = signal(false);
  selectedAssessment = signal<Assessment | null>(null);
  activeTab     = signal<'available' | 'submissions'>('available');

  submitForm = this.fb.nonNullable.group({
    fileUri:  ['', [Validators.required, Validators.pattern('https?://.+')]],
    comments: [''],
  });

  tabs: Array<{ key: 'available' | 'submissions'; label: string }> = [
    { key: 'available',   label: 'Available' },
    { key: 'submissions', label: 'My Submissions' },
  ];

  tabCount(key: 'available' | 'submissions'): number {
    if (key === 'available')   return this.assessments().length;
    if (key === 'submissions') return this.submissions().length;
    return 0;
  }

  typeIcon(type: AssessmentType): string {
    const m: Partial<Record<AssessmentType, string>> = {
      QUIZ: 'bi-patch-question', EXAM: 'bi-journal-text',
      ASSIGNMENT: 'bi-pencil-square', PROJECT: 'bi-kanban',
    };
    return m[type] ?? 'bi-file-text';
  }

  isSubmitInvalid(f: string): boolean {
    const c = this.submitForm.get(f);
    return !!(c?.invalid && c?.touched);
  }

  getSubmission(assessmentId: number): Submission | undefined {
    return this.submissions().find(s => s.assessmentId === assessmentId);
  }

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    // Load submissions first
    this.assessSvc.getSubmissionsByStudent(sId).subscribe({
      next: r => {
        if (r.success) {
          this.submissions.set(r.data ?? []);
          this.submittedIds.set(new Set((r.data ?? []).map(s => s.assessmentId)));
        }
      },
    });
    // Get enrolled courses then fetch assessments
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => {
        if (!r.success || !r.data?.length) { this.loading.set(false); return; }
        const courseIds = [...new Set(r.data.map(e => e.courseId))];
        const all: Assessment[] = [];
        let pending = courseIds.length;
        courseIds.forEach(cId => {
          this.assessSvc.getByCourse(cId).subscribe({
            next: ar => { if (ar.success) all.push(...(ar.data ?? [])); },
            complete: () => { if (--pending === 0) { this.assessments.set(all); this.loading.set(false); } },
          });
        });
      },
      error: () => this.loading.set(false),
    });
  }

  openSubmit(a: Assessment): void {
    this.selectedAssessment.set(a);
    this.submitForm.reset();
    this.showModal.set(true);
  }

  closeModal(): void { this.showModal.set(false); }

  submitAssessment(): void {
    if (this.submitForm.invalid) { this.submitForm.markAllAsTouched(); return; }
    const a   = this.selectedAssessment()!;
    const sId = this.auth.userId() ?? 1;
    this.submitting.set(true);
    this.assessSvc.submit({ assessmentId: a.assessmentId, studentId: sId, ...this.submitForm.getRawValue() }).subscribe({
      next: r => {
        this.submitting.set(false);
        if (r.success) {
          this.submittedIds.update(s => { s.add(a.assessmentId); return new Set(s); });
          this.submissions.update(arr => [r.data, ...arr]);
          this.toast.success('Submitted!', `Your submission for "${a.title}" was received.`);
          this.closeModal();
        } else {
          this.toast.error('Submission failed', r.message);
        }
      },
      error: err => { this.submitting.set(false); this.toast.error('Error', err?.error?.message); },
    });
  }
}
