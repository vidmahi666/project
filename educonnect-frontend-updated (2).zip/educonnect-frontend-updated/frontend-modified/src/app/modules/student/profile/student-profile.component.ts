import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { StudentService, ToastService } from '../../../core/services/index';
import { Student } from '../../../core/models';

@Component({
  selector: 'app-student-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './student-profile.component.html',
  styleUrls: ['./student-profile.component.scss'],
})
export class StudentProfileComponent implements OnInit {
  auth       = inject(AuthService);
  studentSvc = inject(StudentService);
  toast      = inject(ToastService);
  fb         = inject(FormBuilder);

  loading = signal(true);
  saving  = signal(false);
  student = signal<Student | null>(null);

  initials = () => {
    const n = this.auth.user()?.name ?? '';
    return n.split(' ').slice(0,2).map(w => w[0]).join('').toUpperCase();
  };

  form = this.fb.nonNullable.group({
    name:        [''],
    dob:         [''],
    gender:      [''],
    address:     [''],
    contactInfo: [''],
  });

  ngOnInit(): void {
    const uid = this.auth.userId() ?? 1;
    this.studentSvc.getByUserId(uid).subscribe({
      next: r => {
        if (r.success && r.data) {
          this.student.set(r.data);
          this.form.patchValue(r.data);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  save(): void {
    const s = this.student();
    if (!s) return;
    this.saving.set(true);
    this.studentSvc.updateProfile(s.userId, this.form.getRawValue()).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.toast.success('Profile updated!', 'Your changes have been saved.');
        } else {
          this.toast.error('Update failed', r.message);
        }
      },
      error: err => { this.saving.set(false); this.toast.error('Error', err?.error?.message); },
    });
  }
}
