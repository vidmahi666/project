import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ContentService, EnrollmentService, CourseService, ToastService } from '../../../core/services/index';
import { Content, Course, Enrollment } from '../../../core/models';

@Component({
  selector: 'app-course-content',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './course-content.component.html',
  styleUrls: ['./course-content.component.scss'],
})
export class CourseContentComponent implements OnInit {
  private route       = inject(ActivatedRoute);
  private auth        = inject(AuthService);
  private contentSvc  = inject(ContentService);
  private enrollSvc   = inject(EnrollmentService);
  private courseSvc   = inject(CourseService);
  private toast       = inject(ToastService);

  loading     = signal(true);
  isEnrolled  = signal(false);
  course      = signal<Course | null>(null);
  contentList = signal<Content[]>([]);
  accessedIds = signal<Set<number>>(new Set());
  typeFilter  = signal<string>('all');

  courseId = computed(() => Number(this.route.snapshot.paramMap.get('courseId') ?? 0));

  accessedCount = computed(() => this.accessedIds().size);
  accessPct     = computed(() => {
    const total = this.contentList().length;
    return total ? Math.round((this.accessedIds().size / total) * 100) : 0;
  });

  typeFilters = [
    { key: 'all',          label: 'All',          icon: 'bi-collection' },
    { key: 'VIDEO',        label: 'Videos',       icon: 'bi-play-circle-fill' },
    { key: 'PDF',          label: 'PDFs',         icon: 'bi-file-earmark-pdf-fill' },
    { key: 'DOCUMENT',     label: 'Documents',    icon: 'bi-file-earmark-text-fill' },
    { key: 'PRESENTATION', label: 'Slides',       icon: 'bi-file-earmark-slides-fill' },
    { key: 'QUIZ',         label: 'Quizzes',      icon: 'bi-patch-question-fill' },
  ];

  filtered = computed(() => {
    const list = this.contentList().filter(c => c.status === 'ACTIVE');
    if (this.typeFilter() === 'all') return list;
    return list.filter(c => c.type === this.typeFilter());
  });

  countByType(key: string): number {
    if (key === 'all') return this.contentList().filter(c => c.status === 'ACTIVE').length;
    return this.contentList().filter(c => c.type === key && c.status === 'ACTIVE').length;
  }

  typeIcon(type: string): string {
    const map: Record<string, string> = {
      VIDEO: 'bi-play-circle-fill', PDF: 'bi-file-earmark-pdf-fill',
      DOCUMENT: 'bi-file-earmark-text-fill', PRESENTATION: 'bi-file-earmark-slides-fill',
      QUIZ: 'bi-patch-question-fill',
    };
    return map[type] ?? 'bi-file-earmark';
  }

  ngOnInit(): void {
    const studentId = this.auth.userId() ?? 1;
    const cId       = this.courseId();

    // Load course info
    this.courseSvc.getById(cId).subscribe({
      next: r => { if (r.success) this.course.set(r.data); },
    });

    // Check enrollment, then load content if enrolled
    this.enrollSvc.getByStudent(studentId).subscribe({
      next: r => {
        if (r.success) {
          const enrolled = (r.data ?? []).some(e =>
            e.courseId === cId && (e.status === 'ACTIVE' || e.status === 'COMPLETED')
          );
          this.isEnrolled.set(enrolled);

          if (enrolled) {
            this.loadContent(cId, studentId);
          } else {
            this.loading.set(false);
          }
        } else {
          this.loading.set(false);
        }
      },
      error: () => this.loading.set(false),
    });
  }

  loadContent(courseId: number, studentId: number): void {
    this.contentSvc.getByCourse(courseId).subscribe({
      next: r => {
        if (r.success) this.contentList.set(r.data ?? []);
        // Load access records
        this.contentSvc.getAccessByStudent(studentId).subscribe({
          next: ar => {
            if (ar.success) {
              const ids = new Set((ar.data ?? []).map(a => a.contentId));
              this.accessedIds.set(ids);
            }
            this.loading.set(false);
          },
          error: () => this.loading.set(false),
        });
      },
      error: () => this.loading.set(false),
    });
  }

  recordAccess(c: Content): void {
    if (this.accessedIds().has(c.contentId)) return;
    const studentId = this.auth.userId() ?? 1;
    this.contentSvc.recordAccess(c.contentId, studentId).subscribe({
      next: r => {
        if (r.success) {
          this.accessedIds.update(s => { s.add(c.contentId); return new Set(s); });
          this.toast.info('Progress updated', `"${c.title}" marked as viewed.`);
        }
      },
    });
  }
}
