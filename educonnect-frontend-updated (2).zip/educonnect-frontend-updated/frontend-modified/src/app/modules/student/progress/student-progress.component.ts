import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { ProgressService, EnrollmentService, StudentService } from '../../../core/services/index';
import { Progress, Enrollment } from '../../../core/models';
import { forkJoin, switchMap, of } from 'rxjs';

@Component({
  selector: 'app-student-progress',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './student-progress.component.html',
  styleUrls: ['./student-progress.component.scss'],
})
export class StudentProgressComponent implements OnInit {
  private auth          = inject(AuthService);
  private progressSvc   = inject(ProgressService);
  private enrollmentSvc = inject(EnrollmentService);
  private studentSvc    = inject(StudentService);

  loading      = signal(true);
  progressList = signal<Progress[]>([]);
  error        = signal('');

  completedCount  = computed(() => this.progressList().filter(p => p.status === 'COMPLETED').length);
  inProgressCount = computed(() => this.progressList().filter(p => p.status === 'IN_PROGRESS').length);
  overallPct = computed(() => {
    const list = this.progressList();
    if (!list.length) return 0;
    return Math.round(list.reduce((s, p) => s + p.completionPercentage, 0) / list.length);
  });

  colors = ['blue','mint','gold','purple','blue','mint','gold'];
  icons  = ['bi-book','bi-code-slash','bi-bar-chart','bi-flask','bi-camera','bi-globe','bi-music-note-beamed'];

  ngOnInit(): void {
    const userId = this.auth.userId() ?? 1;

    // First resolve studentId from userId, then fetch progress
    this.studentSvc.getByUserId(userId).pipe(
      switchMap(studentRes => {
        const studentId = studentRes.data?.studentId ?? userId;
        return forkJoin([
          this.progressSvc.getByStudent(studentId),
          this.enrollmentSvc.getByStudent(studentId),
        ]);
      })
    ).subscribe({
      next: ([progressRes, enrollmentRes]) => {
        const enrollments = enrollmentRes.data ?? [];
        const enrollmentMap = new Map(enrollments.map(e => [e.courseId, e.courseTitle]));

        const progressData = (progressRes.data ?? []).map(p => ({
          ...p,
          courseTitle: p.courseTitle || enrollmentMap.get(p.courseId) || `Course #${p.courseId}`
        }));

        this.progressList.set(progressData);
        this.loading.set(false);
      },
      error: () => {
        // Fallback: try with userId directly
        forkJoin([
          this.progressSvc.getByStudent(userId),
          this.enrollmentSvc.getByStudent(userId),
        ]).subscribe({
          next: ([progressRes, enrollmentRes]) => {
            const enrollments = enrollmentRes.data ?? [];
            const enrollmentMap = new Map(enrollments.map(e => [e.courseId, e.courseTitle]));
            const progressData = (progressRes.data ?? []).map(p => ({
              ...p,
              courseTitle: p.courseTitle || enrollmentMap.get(p.courseId) || `Course #${p.courseId}`
            }));
            this.progressList.set(progressData);
            this.loading.set(false);
          },
          error: () => { this.loading.set(false); this.error.set('Failed to load progress data.'); }
        });
      }
    });
  }
}
