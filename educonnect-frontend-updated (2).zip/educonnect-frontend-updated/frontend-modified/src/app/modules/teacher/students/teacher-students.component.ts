import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService, ProgressService, StudentService } from '../../../core/services/index';
import { Course, Enrollment, Progress, Student } from '../../../core/models';

@Component({
  selector: 'app-teacher-students',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './teacher-students.component.html',
  styleUrls: ['./teacher-students.component.scss'],
})
export class TeacherStudentsComponent implements OnInit {
  private auth        = inject(AuthService);
  private courseSvc   = inject(CourseService);
  private enrollSvc   = inject(EnrollmentService);
  private progressSvc = inject(ProgressService);

  loading           = signal(false);
  myCourses         = signal<Course[]>([]);
  enrollments       = signal<Enrollment[]>([]);
  progressMap       = signal<Map<number,Progress>>(new Map());
  selectedCourseId  = signal<number|null>(null);
  search            = '';

  completedCount = computed(() => Array.from(this.progressMap().values()).filter(p => p.status === 'COMPLETED').length);
  avgProgress    = computed(() => {
    const vals = Array.from(this.progressMap().values());
    if (!vals.length) return 0;
    return Math.round(vals.reduce((s,p) => s + p.completionPercentage, 0) / vals.length);
  });

  filtered = computed(() => {
    const q = this.search.toLowerCase();
    return this.enrollments().filter(e =>
      !q || String(e.studentId).includes(q) || (e.studentName ?? '').toLowerCase().includes(q)
    );
  });

  progressOf(studentId: number): Progress | undefined {
    return this.progressMap().get(studentId);
  }

  initials(nameOrId: string | number): string {
    if (typeof nameOrId === 'string' && nameOrId.trim()) {
      return nameOrId.trim().split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
    }
    return 'S' + String(nameOrId).slice(-2);
  }

  progressColor(pct: number): string {
    if (pct >= 70) return 'linear-gradient(90deg,#2E7BF6,#00C9A7)';
    if (pct >= 40) return 'linear-gradient(90deg,#F0A500,#2E7BF6)';
    return 'linear-gradient(90deg,#FB7185,#F0A500)';
  }

  ngOnInit(): void {
    const tid = this.auth.userId() ?? 1;
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) this.myCourses.set((r.data ?? []).filter(c => c.teacherUserId === tid));
      },
    });
  }

  selectCourse(id: number): void {
    this.selectedCourseId.set(id);
    this.loading.set(true);
    this.enrollments.set([]);
    this.progressMap.set(new Map());

    this.enrollSvc.getByCourse(id).subscribe({
      next: r => {
        if (r.success) {
          this.enrollments.set(r.data ?? []);
          this.loadProgress(id);
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false),
    });
  }

  loadProgress(courseId: number): void {
    this.progressSvc.getByCourse(courseId).subscribe({
      next: r => {
        if (r.success) {
          const map = new Map<number,Progress>();
          (r.data ?? []).forEach(p => map.set(p.studentId, p));
          this.progressMap.set(map);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }
}
