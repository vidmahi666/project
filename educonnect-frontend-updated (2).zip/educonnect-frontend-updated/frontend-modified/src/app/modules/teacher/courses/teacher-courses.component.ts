import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, ToastService } from '../../../core/services/index';
import { Course } from '../../../core/models';

@Component({
  selector: 'app-teacher-courses',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './teacher-courses.component.html',
  styleUrls: ['./teacher-courses.component.scss'],
})
export class TeacherCoursesComponent implements OnInit {
  private auth      = inject(AuthService);
  private courseSvc = inject(CourseService);
  private toast     = inject(ToastService);
  private fb        = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  courses   = signal<Course[]>([]);
  showModal = signal(false);
  editingId = signal<number | null>(null);

  form = this.fb.nonNullable.group({
    title:       ['', Validators.required],
    description: [''],
    startDate:   ['', Validators.required],
    endDate:     ['', Validators.required],
  });

  ii(f: string): boolean { const c = this.form.get(f); return !!(c?.invalid && c?.touched); }

  ngOnInit(): void { this.load(); }

  load(): void {
    const uid = this.auth.userId();
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) this.courses.set((r.data ?? []).filter(c => c.teacherUserId === uid));
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  openCreate(): void { this.editingId.set(null); this.form.reset(); this.showModal.set(true); }

  openEdit(c: Course): void {
    this.editingId.set(c.courseId);
    this.form.patchValue({ title: c.title, description: c.description, startDate: c.startDate, endDate: c.endDate });
    this.showModal.set(true);
  }

  closeModal(): void { this.showModal.set(false); }

  save(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const payload = { ...this.form.getRawValue(), teacherUserId: this.auth.userId()! };
    const call = this.editingId()
      ? this.courseSvc.update(this.editingId()!, payload)
      : this.courseSvc.create(payload);

    call.subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.toast.success(this.editingId() ? 'Course updated!' : 'Course created!');
          this.closeModal(); this.load();
        } else {
          this.toast.error('Failed', r.message);
        }
      },
      error: err => { this.saving.set(false); this.toast.error('Error', err?.error?.message); },
    });
  }
}
