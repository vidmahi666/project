import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService, AssessmentService, ToastService } from '../../../core/services/index';
import { Course, Enrollment, Assessment, Submission } from '../../../core/models';

@Component({
  selector: 'app-teacher-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './teacher-dashboard.component.html',
  styleUrls: ['./teacher-dashboard.component.scss'],
})
export class TeacherDashboardComponent implements OnInit {
  private auth      = inject(AuthService);
  private courseSvc = inject(CourseService);
  private enrollSvc = inject(EnrollmentService);
  private assessSvc = inject(AssessmentService);

  myCourses  = signal<Course[]>([]);
  pendingSubs = signal<Submission[]>([]);
  totalStudents = signal(0);

  firstName = computed(() => (this.auth.user()?.name ?? 'Teacher').split(' ')[0]);

  stats = computed(() => [
    { label: 'My Courses',   value: this.myCourses().length,  tone:'gold',  icon:'bi-book-fill' },
    { label: 'Total Students', value: this.totalStudents(),   tone:'blue',  icon:'bi-people-fill' },
    { label: 'Pending Grade', value: this.pendingSubs().length, tone:'rose', icon:'bi-hourglass-split' },
    { label: 'Active Courses', value: this.myCourses().filter(c => c.status === 'ACTIVE').length, tone:'mint', icon:'bi-play-circle-fill' },
  ]);

  ngOnInit(): void {
    const teacherId = this.auth.userId();
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const mine = (r.data ?? []).filter(c => c.teacherUserId === teacherId);
          this.myCourses.set(mine);
          let total = 0;
          let pending = mine.length || 1;
          mine.forEach(c => {
            this.enrollSvc.getByCourse(c.courseId).subscribe({
              next: er => { total += (er.data ?? []).length; if (--pending === 0) this.totalStudents.set(total); },
            });
            this.assessSvc.getByCourse(c.courseId).subscribe({
              next: ar => {
                (ar.data ?? []).forEach(a => {
                  this.assessSvc.getSubmissionsByAssessment(a.assessmentId).subscribe({
                    next: sr => {
                      const subs = (sr.data ?? []).filter(s => s.status === 'SUBMITTED');
                      this.pendingSubs.update(arr => [...arr, ...subs]);
                    },
                  });
                });
              },
            });
          });
        }
      },
    });
  }
}
