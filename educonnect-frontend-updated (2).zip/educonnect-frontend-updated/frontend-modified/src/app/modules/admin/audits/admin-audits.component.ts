import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AuditService, ToastService } from '../../../core/services/index';
import { Audit, AuditStatus } from '../../../core/models';

@Component({
  selector: 'app-admin-audits',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin-audits.component.html',
  styleUrls: ['./admin-audits.component.scss'],
})
export class AdminAuditsComponent implements OnInit {
  private auth     = inject(AuthService);
  private auditSvc = inject(AuditService);
  private toast    = inject(ToastService);
  private fb       = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  showModal = signal(false);
  audits    = signal<Audit[]>([]);
  formError = signal('');

  form = this.fb.nonNullable.group({
    title:        ['', Validators.required],
    description:  [''],
    auditorUserId: [null as unknown as number],
  });

  statusSummary = () => [
    { label: 'Scheduled',   tone: 'blue', icon: 'bi-calendar-check', count: this.audits().filter(a => a.status === 'SCHEDULED').length },
    { label: 'In Progress', tone: 'gold', icon: 'bi-hourglass-split', count: this.audits().filter(a => a.status === 'IN_PROGRESS').length },
    { label: 'Completed',   tone: 'mint', icon: 'bi-patch-check-fill', count: this.audits().filter(a => a.status === 'COMPLETED').length },
    { label: 'Cancelled',   tone: 'rose', icon: 'bi-x-circle-fill',   count: this.audits().filter(a => a.status === 'CANCELLED').length },
  ];

  statusIcon(s: AuditStatus): string {
    const m: Partial<Record<AuditStatus,string>> = {
      SCHEDULED:'bi-calendar-check', IN_PROGRESS:'bi-hourglass-split',
      COMPLETED:'bi-patch-check-fill', CANCELLED:'bi-x-circle-fill',
    };
    return m[s] ?? 'bi-search';
  }

  ngOnInit(): void {
    this.auditSvc.getAll().subscribe({
      next: r => { if (r.success) this.audits.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const v = this.form.getRawValue();
    this.auditSvc.create({ ...v, auditorUserId: v.auditorUserId || undefined }).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.audits.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Audit initiated', `"${r.data.title}" has been created.`);
        } else { this.formError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  updateStatus(a: Audit, status: string): void {
    this.auditSvc.updateStatus(a.auditId, status).subscribe({
      next: r => {
        if (r.success) {
          this.audits.update(arr => arr.map(x => x.auditId === a.auditId ? { ...x, status: status as AuditStatus } : x));
          this.toast.success('Updated', `Audit marked as ${status}.`);
        }
      },
    });
  }
}
