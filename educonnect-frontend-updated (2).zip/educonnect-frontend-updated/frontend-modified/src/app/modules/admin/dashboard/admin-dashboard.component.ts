import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ReportService, AdminUserService } from '../../../core/services/index';
import { DashboardMetrics, User } from '../../../core/models';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss'],
})
export class AdminDashboardComponent implements OnInit {
  private auth       = inject(AuthService);
  private reportSvc  = inject(ReportService);
  private adminSvc   = inject(AdminUserService);

  loadingMetrics = signal(true);
  loadingUsers   = signal(true);
  metrics        = signal<DashboardMetrics | null>(null);
  recentUsers    = signal<User[]>([]);

  quickActions = [
    { label: 'User Management', desc: 'Roles & accounts',  icon: 'bi-people-fill',            route: '/admin/users',      tone: 'blue' },
    { label: 'Courses',         desc: 'All platform courses', icon: 'bi-book-fill',            route: '/admin/courses',    tone: 'mint' },
    { label: 'Compliance',      desc: 'Policy records',    icon: 'bi-shield-check',            route: '/admin/compliance', tone: 'gold' },
    { label: 'Audits',          desc: 'Formal audits',     icon: 'bi-search',                  route: '/admin/audit-overview',     tone: 'purple' },
    { label: 'Reports',         desc: 'Analytics & KPIs',  icon: 'bi-file-earmark-bar-graph',  route: '/admin/reports',    tone: 'rose' },
  ];

  ngOnInit(): void {
    this.reportSvc.getDashboard().subscribe({
      next: r => { if (r.success) this.metrics.set(r.data); this.loadingMetrics.set(false); },
      error: () => this.loadingMetrics.set(false),
    });
    this.adminSvc.getAllUsers().subscribe({
      next: r => { if (r.success) this.recentUsers.set((r.data ?? []).slice(0, 6)); this.loadingUsers.set(false); },
      error: () => this.loadingUsers.set(false),
    });
  }
}
