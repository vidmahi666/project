import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { ReportService, ToastService } from '../../../core/services/index';
import { DashboardMetrics, Report } from '../../../core/models';

@Component({
  selector: 'app-admin-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-reports.component.html',
  styleUrls: ['./admin-reports.component.scss'],
})
export class AdminReportsComponent implements OnInit {
  private auth      = inject(AuthService);
  private reportSvc = inject(ReportService);
  private toast     = inject(ToastService);
  loadingMetrics = signal(true);
  loadingReports = signal(true);
  generating     = signal(false);
  metrics        = signal<DashboardMetrics | null>(null);
  reports        = signal<Report[]>([]);
  selectedReport = signal<Report | null>(null);
  scopes = [
    { key:'DASHBOARD',  label:'Dashboard Report',  desc:'Overall platform KPIs',     icon:'bi-grid-1x2-fill',         tone:'blue' },
    { key:'COURSE',     label:'Course Report',      desc:'Course performance metrics', icon:'bi-book-fill',             tone:'mint' },
    { key:'ASSESSMENT', label:'Assessment Report',  desc:'Test and quiz results',      icon:'bi-pencil-square',         tone:'rose' },
    { key:'STUDENT',    label:'Student Report',     desc:'Student progress analysis',  icon:'bi-people-fill',           tone:'purple' },
    { key:'PROGRAM',    label:'Program Report',     desc:'Program-level overview',     icon:'bi-clipboard-data-fill',   tone:'gold' },
    { key:'COMPLIANCE', label:'Compliance Report',  desc:'Compliance & audit summary', icon:'bi-shield-check',          tone:'mint' },
  ];
  scopeIcon(scope: string): string {
    return this.scopes.find(s => s.key === scope)?.icon ?? 'bi-file-earmark-bar-graph';
  }
  ngOnInit(): void { this.loadMetrics(); this.loadReports(); }
  loadMetrics(): void {
    this.reportSvc.getDashboard().subscribe({ next: r => { if (r.success) this.metrics.set(r.data); this.loadingMetrics.set(false); }, error: () => this.loadingMetrics.set(false) });
  }
  loadReports(): void {
    this.loadingReports.set(true);
    this.reportSvc.getAll().subscribe({ next: r => { if (r.success) this.reports.set(r.data ?? []); this.loadingReports.set(false); }, error: () => this.loadingReports.set(false) });
  }
  generateReport(scope: string): void {
    const by = this.auth.user()?.name ?? 'admin';
    this.generating.set(true);
    this.reportSvc.generate(scope, by).subscribe({
      next: r => { this.generating.set(false); if (r.success) { this.toast.success('Report generated!', scope + ' report is ready.'); this.loadReports(); } else { this.toast.error('Failed', 'Could not generate report.'); } },
      error: () => { this.generating.set(false); this.toast.error('Error', 'Report generation failed.'); }
    });
  }
}
