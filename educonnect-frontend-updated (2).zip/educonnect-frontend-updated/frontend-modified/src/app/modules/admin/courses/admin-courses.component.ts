// ─────────────────────────────────────────────────────────────
// Admin Courses Component
// ─────────────────────────────────────────────────────────────
import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseService, AdminUserService } from '../../../core/services/index';
import { Course, CourseStatus, User } from '../../../core/models';

@Component({
  selector: 'app-admin-courses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-courses.component.html',
  styleUrls: ['./admin-courses.component.scss'],
})
export class AdminCoursesComponent implements OnInit {
  private courseSvc = inject(CourseService);
  private adminSvc  = inject(AdminUserService);
  loading      = signal(true);
  courses      = signal<Course[]>([]);
  teacherMap   = signal<Map<number, string>>(new Map());
  statusFilter = signal('ALL');
  search       = '';
  statusFilters = ['ALL', 'DRAFT', 'ACTIVE', 'COMPLETED', 'ARCHIVED'];

  filtered = computed(() => {
    let list = this.courses();
    if (this.statusFilter() !== 'ALL') list = list.filter(c => c.status === this.statusFilter());
    if (this.search.trim()) list = list.filter(c => c.title.toLowerCase().includes(this.search.toLowerCase()));
    return list;
  });

  countByStatus(s: string): number {
    if (s === 'ALL') return this.courses().length;
    return this.courses().filter(c => c.status === s).length;
  }

  ngOnInit(): void {
    this.courseSvc.getAll().subscribe({
      next: r => { if (r.success) this.courses.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
    this.adminSvc.getAllTeachers().subscribe({
      next: r => {
        if (r.success) {
          const m = new Map<number, string>();
          (r.data ?? []).forEach(u => m.set(u.userId, u.name));
          this.teacherMap.set(m);
        }
      },
    });
  }

  teacherName(id: number): string {
    return this.teacherMap().get(id) ?? `Teacher #${id}`;
  }
}
