import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ComplianceService, ToastService } from '../../../core/services/index';
import { ComplianceRecord, ComplianceResult, ComplianceType } from '../../../core/models';

@Component({
  selector: 'app-admin-compliance',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin-compliance.component.html',
  styleUrls: ['./admin-compliance.component.scss'],
})
export class AdminComplianceComponent implements OnInit {
  readonly ComplianceResult = ComplianceResult;

  private complianceSvc = inject(ComplianceService);
  private toast         = inject(ToastService);
  private fb            = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  showModal = signal(false);
  records   = signal<ComplianceRecord[]>([]);
  formError = signal('');

  compTypes: ComplianceType[] = [
    ComplianceType.COURSE,
    ComplianceType.ASSESSMENT,
    ComplianceType.PROGRAM,
    ComplianceType.CONTENT,
  ];

  form = this.fb.nonNullable.group({
    entityId: [null as unknown as number, Validators.required],
    type:     ['', Validators.required],
    notes:    [''],
  });

  countByResult(r: string): number {
    return this.records().filter(x => (x.result ?? 'UNDER_REVIEW') === r).length;
  }

  ngOnInit(): void {
    this.complianceSvc.getAll().subscribe({
      next: r => { if (r.success) this.records.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    this.complianceSvc.create(this.form.getRawValue() as any).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.records.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Record added', 'Compliance record created.');
        } else { this.formError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  setResult(rec: ComplianceRecord, result: ComplianceResult): void {
    this.complianceSvc.updateResult(rec.complianceId, result).subscribe({
      next: r => {
        if (r.success) {
          this.records.update(arr => arr.map(x => x.complianceId === rec.complianceId ? { ...x, result } : x));
          this.toast.success('Updated', `Record marked as ${result}.`);
        }
      },
    });
  }
}
