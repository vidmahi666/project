import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { switchMap } from 'rxjs';
import { ComplianceService, ReportService, ToastService } from '../../../core/services/index';
import { ComplianceRecord, ComplianceResult, ComplianceType, Report } from '../../../core/models';

@Component({
  selector: 'app-compliance-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './compliance-dashboard.component.html',
  styleUrls: ['./compliance-dashboard.component.scss'],
})
export class ComplianceDashboardComponent implements OnInit {
  readonly ComplianceResult = ComplianceResult;

  private complianceSvc = inject(ComplianceService);
  private reportSvc     = inject(ReportService);
  private toast         = inject(ToastService);
  private fb            = inject(FormBuilder);

  loading         = signal(true);
  tab             = signal<'records'|'reports'>('records');
  records         = signal<ComplianceRecord[]>([]);
  reports         = signal<Report[]>([]);
  filtered        = signal<ComplianceRecord[]>([]);
  showCreateModal = signal(false);
  creating        = signal(false);
  generating      = signal(false);
  createError     = signal('');

  filterResult = '';
  filterType   = '';

  types:   ComplianceType[]   = [
    ComplianceType.COURSE,
    ComplianceType.ASSESSMENT,
    ComplianceType.PROGRAM,
    ComplianceType.CONTENT,
  ];
  results: ComplianceResult[] = [
    ComplianceResult.COMPLIANT,
    ComplianceResult.NON_COMPLIANT,
    ComplianceResult.UNDER_REVIEW,
    ComplianceResult.REMEDIATED,
  ];

  createForm = this.fb.nonNullable.group({
    entityId: [null as unknown as number, [Validators.required, Validators.min(1)]],
    type:     ['', Validators.required],
    notes:    [''],
  });

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.complianceSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          this.records.set(r.data ?? []);
          this.filtered.set(r.data ?? []);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
    this.reportSvc.getAll().subscribe({
      next: r => { if (r.success) this.reports.set((r.data ?? []).filter(x => x.scope === 'COMPLIANCE')); },
    });
  }

  countByResult(result: string): number {
    return this.records().filter(r => r.result === result).length;
  }

  applyFilter(): void {
    let list = this.records();
    if (this.filterResult) list = list.filter(r => r.result === this.filterResult);
    if (this.filterType)   list = list.filter(r => r.type   === this.filterType);
    this.filtered.set(list);
  }

  openCreate(): void { this.createForm.reset(); this.createError.set(''); this.showCreateModal.set(true); }

  doCreate(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.creating.set(true);
    this.complianceSvc.create(this.createForm.getRawValue() as any).subscribe({
      next: r => {
        this.creating.set(false);
        if (r.success) {
          this.records.update(arr => [r.data, ...arr]);
          this.filtered.update(arr => [r.data, ...arr]);
          this.showCreateModal.set(false);
          this.toast.success('Record added!', 'Compliance record has been saved.');
        } else { this.createError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.creating.set(false); this.createError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  updateResult(rec: ComplianceRecord, result: ComplianceResult): void {
    this.complianceSvc.updateResult(rec.complianceId, result).subscribe({
      next: r => {
        if (r.success) {
          const updated = (arr: ComplianceRecord[]) => arr.map(x => x.complianceId === rec.complianceId ? { ...x, result } : x);
          this.records.update(updated);
          this.filtered.update(updated);
          this.toast.success('Result updated', `Marked as ${result.replace('_',' ')}.`);
        }
      },
    });
  }

  generateReport(): void {
    this.generating.set(true);
    this.reportSvc.generate('COMPLIANCE').pipe(
      switchMap(() => this.reportSvc.getByScope('COMPLIANCE'))
    ).subscribe({
      next: r => {
        this.generating.set(false);
        if (r.success) {
          this.reports.set(r.data ?? []);
          this.toast.success('Report generated!', 'Compliance report is ready.');
        }
      },
      error: () => this.generating.set(false),
    });
  }
}
