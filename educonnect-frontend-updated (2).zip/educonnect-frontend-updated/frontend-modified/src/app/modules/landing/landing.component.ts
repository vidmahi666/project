import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
})
export class LandingComponent {
  features = [
    { title: 'Smart Enrollment', icon: 'bi-person-plus-fill', tone: 'blue', desc: 'Streamline course enrollment with automated notifications and instant status updates.' },
    { title: 'Live Progress Tracking', icon: 'bi-bar-chart-line-fill', tone: 'mint', desc: 'Per-course completion metrics updated in real-time after every graded submission.' },
    { title: 'Assessment Engine', icon: 'bi-pencil-square', tone: 'gold', desc: 'Create quizzes, exams, assignments and projects with file attachments and due dates.' },
    { title: 'Content Management', icon: 'bi-collection-play-fill', tone: 'purple', desc: 'Upload videos, PDFs and documents. Students see content only after valid enrollment.' },
    { title: 'Compliance & Auditing', icon: 'bi-shield-check-fill', tone: 'rose', desc: 'Full compliance records and government audit trails for regulatory accountability.' },
    { title: 'Role-Based Access', icon: 'bi-person-badge-fill', tone: 'teal', desc: 'Granular permissions for Students, Teachers, Admins, Compliance Officers and Auditors.' },
  ];

  roles = [
    { label: 'Student', icon: 'bi-person-fill', tone: 'blue', items: ['Enroll in courses', 'View locked content', 'Submit assessments', 'Track progress'] },
    { label: 'Teacher', icon: 'bi-person-video2', tone: 'mint', items: ['Create course content', 'Publish assessments', 'Grade submissions', 'Update progress'] },
    { label: 'Admin', icon: 'bi-gear-fill', tone: 'gold', items: ['Manage all users', 'Oversee courses', 'Audit overview', 'System reports'] },
    { label: 'Compliance Officer', icon: 'bi-shield-fill', tone: 'purple', items: ['Policy monitoring', 'Compliance records', 'Review violations', 'Generate reports'] },
    { label: 'Government Auditor', icon: 'bi-search', tone: 'rose', items: ['Audit scheduling', 'Log reviews', 'Status tracking', 'Oversight reports'] },
  ];
}
