import { Component, signal, inject } from '@angular/core';
import { AbstractControl, ReactiveFormsModule, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/index';
import { NotificationCategory } from '../../../core/models';

// Custom cross-field validator
function passwordMatch(ctrl: AbstractControl): ValidationErrors | null {
  const pw  = ctrl.get('password')?.value;
  const cpw = ctrl.get('confirmPassword')?.value;
  return pw && cpw && pw !== cpw ? { mismatch: true } : null;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent {
  private fb       = inject(FormBuilder);
  private auth     = inject(AuthService);
  private router   = inject(Router);
  private notifSvc = inject(NotificationService);

  loading = signal(false);
  error   = signal('');
  success = signal('');
  showPwd = signal(false);

  form = this.fb.nonNullable.group({
    name:            ['', Validators.required],
    email:           ['', [Validators.required, Validators.email]],
    phone:           ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    password:        ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', Validators.required],
  }, { validators: passwordMatch });

  isInvalid(field: string): boolean {
    const c = this.form.get(field);
    return !!(c?.invalid && c?.touched);
  }

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading.set(true);
    this.error.set('');

    const { confirmPassword, ...payload } = this.form.getRawValue();
    this.auth.register(payload).subscribe({
      next: res => {
        this.loading.set(false);
        if (res.success) {
          this.success.set('Account created! Redirecting to login...');
          const name = (this.form.getRawValue() as any).name ?? 'A new student';
          // Notify admin about new registration
          this.notifSvc.create({ userId: 1, message: `${name} has registered as a new student.`, category: NotificationCategory.PROGRAM }).subscribe();
          setTimeout(() => this.router.navigate(['/login']), 1500);
        } else {
          this.error.set(res.message ?? 'Registration failed');
        }
      },
      error: err => {
        this.loading.set(false);
        this.error.set(err?.error?.message ?? 'Registration failed. Email may already be in use.');
      },
    });
  }
}
