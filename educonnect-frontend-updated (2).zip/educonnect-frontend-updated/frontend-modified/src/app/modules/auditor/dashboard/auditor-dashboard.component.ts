import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { switchMap } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { AuditService, ComplianceService, ReportService, ToastService } from '../../../core/services/index';
import { Audit, AuditLog, AuditStatus, Report, ComplianceRecord, ComplianceResult, ComplianceType } from '../../../core/models';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-auditor-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './auditor-dashboard.component.html',
  styleUrls: ['./auditor-dashboard.component.scss'],
})
export class AuditorDashboardComponent implements OnInit {
  readonly ComplianceResult = ComplianceResult;

  private auth          = inject(AuthService);
  private auditSvc      = inject(AuditService);
  private complianceSvc = inject(ComplianceService);
  private reportSvc     = inject(ReportService);
  private toast         = inject(ToastService);
  private fb            = inject(FormBuilder);

  loading         = signal(true);
  tab             = signal<'audits'|'logs'|'reports'|'compliance'>('audits');
  audits          = signal<Audit[]>([]);
  logs            = signal<AuditLog[]>([]);
  reports         = signal<Report[]>([]);
  records         = signal<ComplianceRecord[]>([]);
  filtered        = signal<ComplianceRecord[]>([]);
  showCreateModal = signal(false);
  creating        = signal(false);
  generating      = signal(false);
  createError     = signal('');
  filterResult    = '';
  filterType      = '';
  types: ComplianceType[] = [
    ComplianceType.COURSE,
    ComplianceType.ASSESSMENT,
    ComplianceType.PROGRAM,
    ComplianceType.CONTENT,
  ];
  results: ComplianceResult[] = [
    ComplianceResult.COMPLIANT,
    ComplianceResult.NON_COMPLIANT,
    ComplianceResult.UNDER_REVIEW,
    ComplianceResult.REMEDIATED,
  ];

  summary = computed(() => [
    { label: 'Scheduled',   tone: 'gold', icon: 'bi-calendar-check', count: this.audits().filter(a => a.status === 'SCHEDULED').length },
    { label: 'In Progress', tone: 'blue', icon: 'bi-hourglass-split', count: this.audits().filter(a => a.status === 'IN_PROGRESS').length },
    { label: 'Completed',   tone: 'mint', icon: 'bi-check-circle-fill', count: this.audits().filter(a => a.status === 'COMPLETED').length },
    { label: 'Cancelled',   tone: 'rose', icon: 'bi-x-circle-fill', count: this.audits().filter(a => a.status === 'CANCELLED').length },
  ]);

  auditForm = this.fb.nonNullable.group({
    title:       ['', Validators.required],
    description: [''],
  });

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.auditSvc.getAll().subscribe({
      next: r => {
        if (r.success) this.audits.set(r.data ?? []);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
    this.reportSvc.getAll().subscribe({
      next: r => { if (r.success) this.reports.set((r.data ?? []).filter(x => x.scope === 'COMPLIANCE' || x.scope === 'PROGRAM')); },
    });
    this.complianceSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          this.records.set(r.data ?? []);
          this.filtered.set(r.data ?? []);
        }
      },
    });
  }

  loadLogs(): void {
    if (this.logs().length) return;
    this.auditSvc.getLogs().subscribe({
      next: r => { if (r.success) this.logs.set(r.data ?? []); },
    });
  }

  statusIcon(s: AuditStatus): string {
    const m: Record<string, string> = {
      SCHEDULED: 'bi-calendar-check', IN_PROGRESS: 'bi-hourglass-split',
      COMPLETED: 'bi-check-circle-fill', CANCELLED: 'bi-x-circle-fill',
    };
    return m[s] ?? 'bi-circle';
  }

  openCreate(): void { this.auditForm.reset(); this.createError.set(''); this.showCreateModal.set(true); }

  doCreate(): void {
    if (this.auditForm.invalid) { this.auditForm.markAllAsTouched(); return; }
    this.creating.set(true);
    const userId = this.auth.user()?.userId;
    this.auditSvc.create({ ...this.auditForm.getRawValue(), auditorUserId: userId }).subscribe({
      next: r => {
        this.creating.set(false);
        if (r.success) {
          this.audits.update(a => [r.data, ...a]);
          this.showCreateModal.set(false);
          this.toast.success('Audit initiated!', `"${r.data.title}" has been scheduled.`);
        } else { this.createError.set(r.message ?? 'Failed to create'); }
      },
      error: err => { this.creating.set(false); this.createError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  updateStatus(a: Audit, status: string): void {
    this.auditSvc.updateStatus(a.auditId, status).subscribe({
      next: r => {
        if (r.success) {
          this.audits.update(arr => arr.map(x => x.auditId === a.auditId ? { ...x, status: status as AuditStatus } : x));
          this.toast.success('Status updated', `Audit marked as ${status.replace('_',' ')}.`);
        }
      },
    });
  }

  applyFilter(): void {
    let list = this.records();
    if (this.filterResult) list = list.filter(r => r.result === this.filterResult);
    if (this.filterType)   list = list.filter(r => r.type === this.filterType);
    this.filtered.set(list);
  }

  updateResult(rec: ComplianceRecord, result: ComplianceResult): void {
    this.complianceSvc.updateResult(rec.complianceId, result).subscribe({
      next: r => {
        if (r.success) {
          const updated = (arr: ComplianceRecord[]) => arr.map(x => x.complianceId === rec.complianceId ? { ...x, result } : x);
          this.records.update(updated);
          this.filtered.update(updated);
          this.toast.success('Result updated', `Marked as ${result.replace('_',' ')}.`);
        }
      },
    });
  }

  generateReport(): void {
    this.generating.set(true);
    this.reportSvc.generate('COMPLIANCE').pipe(
      switchMap(() => this.reportSvc.getByScope('COMPLIANCE'))
    ).subscribe({
      next: r => {
        this.generating.set(false);
        if (r.success) {
          this.reports.set(r.data ?? []);
          this.toast.success('Report generated!', 'Audit compliance report is ready.');
        }
      },
      error: () => this.generating.set(false),
    });
  }
}
