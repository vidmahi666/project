import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { StudentService } from '../../../core/services/api.services';
import { Student } from '../../../core/models/models';

@Component({
  selector: 'app-student-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div>
      <div class="ec-page-header">
        <h2 class="ec-section-title">My Profile</h2>
        <p class="ec-section-sub">Manage your personal information and documents</p>
      </div>

      <div class="profile-layout">
        <!-- Avatar Card -->
        <div class="avatar-card ec-card">
          <div class="big-avatar">{{ initials() }}</div>
          <h3 class="profile-name">{{ user()?.name }}</h3>
          <p class="profile-email">{{ user()?.email }}</p>
          <span class="ec-badge ec-badge-teal role-chip">🎓 Student</span>
          <div class="ec-divider"></div>
          <div class="profile-stats">
            <div class="ps-item">
              <span class="ps-label">Account Status</span>
              <span class="ec-badge ec-badge-success">ACTIVE</span>
            </div>
            <div class="ps-item">
              <span class="ps-label">Member Since</span>
              <span class="ps-val">—</span>
            </div>
          </div>
        </div>

        <!-- Edit Form -->
        <div class="ec-card profile-form-card">
          <h4 style="margin-bottom:1.5rem">Personal Information</h4>
          @if (successMsg()) {
            <div class="ec-alert ec-alert-success"><span>✅</span><span>{{ successMsg() }}</span></div>
          }
          @if (errorMsg()) {
            <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ errorMsg() }}</span></div>
          }

          @if (loading()) {
            <div style="text-align:center;padding:3rem"><span class="ec-spinner ec-spinner-lg"></span></div>
          } @else {
            <form [formGroup]="form" (ngSubmit)="save()">
              <div class="ec-grid-2">
                <div class="ec-form-group">
                  <label class="ec-label">Full Name</label>
                  <input formControlName="name" type="text" class="ec-input" placeholder="Your full name" />
                </div>
                <div class="ec-form-group">
                  <label class="ec-label">Date of Birth</label>
                  <input formControlName="dob" type="date" class="ec-input" />
                </div>
              </div>
              <div class="ec-grid-2">
                <div class="ec-form-group">
                  <label class="ec-label">Gender</label>
                  <select formControlName="gender" class="ec-select">
                    <option value="">Select</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                    <option value="Prefer not to say">Prefer not to say</option>
                  </select>
                </div>
                <div class="ec-form-group">
                  <label class="ec-label">Contact Info</label>
                  <input formControlName="contactInfo" type="text" class="ec-input" placeholder="+91 9999999999" />
                </div>
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Address</label>
                <textarea formControlName="address" class="ec-textarea" rows="3" placeholder="Your address"></textarea>
              </div>
              <div style="display:flex;justify-content:flex-end">
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="ec-spinner"></span> }
                  Save Changes
                </button>
              </div>
            </form>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    .profile-layout {
      display: grid;
      grid-template-columns: 280px 1fr;
      gap: 1.5rem;
      align-items: start;
    }
    @media (max-width: 768px) { .profile-layout { grid-template-columns: 1fr; } }

    .avatar-card { display: flex; flex-direction: column; align-items: center; text-align: center; }
    .big-avatar {
      width: 80px; height: 80px;
      background: linear-gradient(135deg, var(--teal-600), var(--teal-400));
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-family: var(--font-display);
      font-size: 1.75rem;
      font-weight: 700;
      color: #fff;
      margin-bottom: 1rem;
    }
    .profile-name { font-size: 1.1rem; font-weight: 600; margin-bottom: 0.25rem; }
    .profile-email { font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.75rem; }
    .role-chip { margin-bottom: 1rem; }
    .profile-stats { width: 100%; }
    .ps-item { display: flex; justify-content: space-between; padding: 0.5rem 0; font-size: 0.85rem; }
    .ps-label { color: var(--text-secondary); }
    .ps-val { color: var(--text-primary); font-weight: 500; }
  `]
})
export class StudentProfileComponent implements OnInit {
  user     = this.auth.currentUser;
  loading  = signal(true);
  saving   = signal(false);
  successMsg = signal('');
  errorMsg   = signal('');
  student  = signal<Student | null>(null);
  form: FormGroup;

  initials = () => {
    const name = this.user()?.name ?? '';
    return name.split(' ').slice(0,2).map(n => n[0]).join('').toUpperCase();
  };

  constructor(private auth: AuthService, private studentSvc: StudentService, private fb: FormBuilder) {
    this.form = this.fb.group({
      name: [''], dob: [''], gender: [''], address: [''], contactInfo: ['']
    });
  }

  ngOnInit(): void {
    const userId = this.auth.getUserId() ?? 1;
    this.studentSvc.getStudentByUserId(userId).subscribe({
      next: r => {
        if (r.success && r.data) {
          this.student.set(r.data);
          this.form.patchValue(r.data);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  save(): void {
    const s = this.student();
    if (!s) return;
    this.saving.set(true);
    this.errorMsg.set('');
    this.studentSvc.updateProfile(s.studentId, this.form.value).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.successMsg.set('Profile updated successfully!');
          setTimeout(() => this.successMsg.set(''), 3000);
        } else {
          this.errorMsg.set(r.message ?? 'Update failed');
        }
      },
      error: err => {
        this.saving.set(false);
        this.errorMsg.set(err?.error?.message ?? 'Update failed');
      }
    });
  }
}
