import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import {
  EnrollmentService, ProgressService, AssessmentService
} from '../../../core/services/api.services';
import { Enrollment, Progress, Submission } from '../../../core/models/models';

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="dashboard">
      <!-- Welcome -->
      <div class="welcome-banner">
        <div>
          <h1>Hello, {{ name() }} 👋</h1>
          <p>Continue your learning journey today.</p>
        </div>
        <a routerLink="/student/courses" class="ec-btn ec-btn-primary">Browse Courses</a>
      </div>

      <!-- Stats -->
      <div class="stats-grid">
        <div class="ec-stat-card">
          <div class="ec-stat-icon">📚</div>
          <div class="ec-stat-number">{{ enrollments().length }}</div>
          <div class="ec-stat-label">Enrolled Courses</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">✅</div>
          <div class="ec-stat-number">{{ completedCount() }}</div>
          <div class="ec-stat-label">Completed Courses</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">📝</div>
          <div class="ec-stat-number">{{ submissions().length }}</div>
          <div class="ec-stat-label">Submissions</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">⭐</div>
          <div class="ec-stat-number">{{ avgScore() }}%</div>
          <div class="ec-stat-label">Average Score</div>
        </div>
      </div>

      <div class="bottom-grid">
        <!-- Current Progress -->
        <div class="ec-card">
          <div class="ec-section-title">📊 Course Progress</div>
          <div class="ec-section-sub">Your current learning status</div>
          @if (loading()) {
            <div style="text-align:center;padding:2rem;"><span class="ec-spinner ec-spinner-lg"></span></div>
          } @else if (progressList().length === 0) {
            <div class="ec-empty">
              <div class="ec-empty-icon">📭</div>
              <h3>No progress yet</h3>
              <p>Enroll in a course to get started</p>
            </div>
          } @else {
            @for (p of progressList(); track p.progressId) {
              <div class="progress-item">
                <div class="progress-header">
                  <span class="course-name">{{ p.courseTitle ?? 'Course #'+p.courseId }}</span>
                  <span class="progress-pct">{{ p.completionPercentage }}%</span>
                </div>
                <div class="ec-progress">
                  <div class="ec-progress-fill" [style.width.%]="p.completionPercentage"></div>
                </div>
                <span class="ec-badge" [class]="p.status === 'COMPLETED' ? 'ec-badge-success' : 'ec-badge-info'">
                  {{ p.status }}
                </span>
              </div>
            }
          }
        </div>

        <!-- Recent Submissions -->
        <div class="ec-card">
          <div class="ec-section-title">📝 Recent Submissions</div>
          <div class="ec-section-sub">Your latest assessment activity</div>
          @if (submissions().length === 0) {
            <div class="ec-empty">
              <div class="ec-empty-icon">📋</div>
              <h3>No submissions yet</h3>
            </div>
          } @else {
            @for (s of submissions().slice(0, 5); track s.submissionId) {
              <div class="submission-item">
                <div>
                  <p class="sub-title">{{ s.assessmentTitle ?? 'Assessment #'+s.assessmentId }}</p>
                  <p class="sub-date">{{ s.submittedAt | date:'mediumDate' }}</p>
                </div>
                <div class="sub-right">
                  @if (s.score !== null && s.score !== undefined) {
                    <span class="score-chip">{{ s.score }} pts</span>
                  }
                  <span class="ec-badge"
                    [class]="s.status === 'GRADED' ? 'ec-badge-success' : 'ec-badge-warning'">
                    {{ s.status }}
                  </span>
                </div>
              </div>
            }
          }
          <a routerLink="/student/assessments" class="view-all-link">View all assessments →</a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { animation: fadeIn 0.3s ease; }
    .welcome-banner {
      display: flex; align-items: center; justify-content: space-between;
      background: linear-gradient(135deg, var(--bg-card) 0%, rgba(20,184,166,0.05) 100%);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-xl);
      padding: 2rem;
      margin-bottom: 2rem;
    }
    .welcome-banner h1 { font-size: 1.75rem; margin-bottom: 0.25rem; }
    .welcome-banner p { color: var(--text-secondary); }

    .stats-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 1.25rem; margin-bottom: 2rem; }
    @media (max-width:1024px) { .stats-grid { grid-template-columns: repeat(2,1fr); } }

    .bottom-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    @media (max-width:900px) { .bottom-grid { grid-template-columns: 1fr; } }

    .progress-item { padding: 0.875rem 0; border-bottom: 1px solid var(--border-subtle); }
    .progress-item:last-child { border-bottom: none; }
    .progress-header { display: flex; justify-content: space-between; margin-bottom: 0.5rem; }
    .course-name { font-size: 0.9rem; font-weight: 500; }
    .progress-pct { font-size: 0.875rem; color: var(--teal-400); font-weight: 600; }
    .ec-progress { margin-bottom: 0.5rem; }

    .submission-item {
      display: flex; align-items: center; justify-content: space-between;
      padding: 0.75rem 0;
      border-bottom: 1px solid rgba(255,255,255,0.03);
    }
    .submission-item:last-of-type { border-bottom: none; }
    .sub-title { font-size: 0.875rem; font-weight: 500; margin-bottom: 0.2rem; }
    .sub-date { font-size: 0.78rem; color: var(--text-muted); }
    .sub-right { display: flex; align-items: center; gap: 0.5rem; flex-shrink: 0; }
    .score-chip {
      font-size: 0.78rem; font-weight: 600;
      color: var(--gold-400);
      background: rgba(245,158,11,0.1);
      padding: 0.15rem 0.5rem;
      border-radius: 10px;
    }
    .view-all-link {
      display: block; margin-top: 1rem; font-size: 0.85rem; color: var(--accent-primary); font-weight: 500;
    }
  `]
})
export class StudentDashboardComponent implements OnInit {
  loading     = signal(true);
  enrollments = signal<Enrollment[]>([]);
  progressList = signal<Progress[]>([]);
  submissions  = signal<Submission[]>([]);

  name = signal('Student');
  completedCount = signal(0);
  avgScore = signal(0);

  constructor(
    private auth: AuthService,
    private enrollSvc: EnrollmentService,
    private progressSvc: ProgressService,
    private assessSvc: AssessmentService,
  ) {}

  ngOnInit(): void {
    const userId = this.auth.getUserId();
    const userName = this.auth.currentUser()?.name ?? 'Student';
    this.name.set(userName.split(' ')[0]);

    // Need studentId — fetch from student service first
    // For now use userId as a proxy (adjust when student profile is loaded)
    const sId = userId ?? 1;

    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => {
        if (r.success) this.enrollments.set(r.data ?? []);
      }
    });

    this.progressSvc.getByStudent(sId).subscribe({
      next: r => {
        if (r.success) {
          const p = r.data ?? [];
          this.progressList.set(p);
          this.completedCount.set(p.filter(x => x.status === 'COMPLETED').length);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });

    this.assessSvc.getSubmissionsByStudent(sId).subscribe({
      next: r => {
        if (r.success) {
          const subs = r.data ?? [];
          this.submissions.set(subs);
          const graded = subs.filter(s => s.score !== null && s.score !== undefined);
          if (graded.length > 0) {
            const avg = graded.reduce((a, b) => a + (b.score ?? 0), 0) / graded.length;
            this.avgScore.set(Math.round(avg));
          }
        }
      }
    });
  }
}
