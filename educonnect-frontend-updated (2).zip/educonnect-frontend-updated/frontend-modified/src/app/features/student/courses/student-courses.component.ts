import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService } from '../../../core/services/api.services';
import { Course } from '../../../core/models/models';
 
@Component({
  selector: 'app-student-courses',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div>
      <div class="ec-page-header">
        <h2 class="ec-section-title">My Courses</h2>
        <p class="ec-section-sub">Browse available courses and manage your enrollments</p>
      </div>
 
      <!-- Tabs -->
      <div class="tabs">
        <button class="tab-btn" [class.active]="activeTab() === 'all'" (click)="activeTab.set('all')">
          All Courses
        </button>
        <button class="tab-btn" [class.active]="activeTab() === 'enrolled'" (click)="activeTab.set('enrolled')">
          Enrolled ({{ enrolledIds().size }})
        </button>
      </div>
 
      @if (loading()) {
        <div class="loader-center"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (visibleCourses().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">📚</div>
          <h3>No courses found</h3>
          <p>{{ activeTab() === 'enrolled' ? 'You are not enrolled in any courses yet.' : 'No courses available.' }}</p>
        </div>
      } @else {
        <div class="course-grid">
          @for (c of visibleCourses(); track c.courseId) {
            <div class="course-card ec-card">
              <div class="course-card-header">
                <div class="course-type-dot"></div>
                <span class="ec-badge" [class]="statusBadge(c.status)">{{ c.status }}</span>
              </div>
              <h4 class="course-title">{{ c.title }}</h4>
              <p class="course-desc">{{ c.description | slice:0:100 }}{{ (c.description?.length || 0) > 100 ? '...' : '' }}</p>
              <div class="course-meta">
                <span>👨‍🏫 {{ c.teacherName ?? 'Instructor' }}</span>
                <span>📅 {{ c.startDate | date:'medShortDate' }}</span>
              </div>
              <div class="course-footer">
                @if (enrolledIds().has(c.courseId)) {
                  <span class="enrolled-badge">✅ Enrolled</span>
                } @else {
                  <button
                    class="ec-btn ec-btn-primary ec-btn-sm"
                    [disabled]="c.status !== 'ACTIVE' || enrolling() === c.courseId"
                    (click)="enroll(c)"
                  >
                    @if (enrolling() === c.courseId) {
                      <span class="ec-spinner"></span>
                    }
                    Enroll Now
                  </button>
                }
              </div>
            </div>
          }
        </div>
      }
 
      @if (successMsg()) {
        <div class="toast-msg">✅ {{ successMsg() }}</div>
      }
    </div>
  `,
  styles: [`
    .tabs { display: flex; gap: 0.5rem; margin-bottom: 1.75rem; }
    .tab-btn {
      padding: 0.5rem 1.25rem;
      border-radius: 20px;
      border: 1px solid var(--border-subtle);
      background: transparent;
      color: var(--text-secondary);
      font-size: 0.875rem;
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    .tab-btn.active {
      background: var(--accent-primary);
      border-color: var(--accent-primary);
      color: #000;
      font-weight: 600;
    }
 
    .loader-center { display: flex; justify-content: center; padding: 4rem; }
 
    .course-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1.25rem;
    }
 
    .course-card { display: flex; flex-direction: column; }
    .course-card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem; }
    .course-type-dot { width: 8px; height: 8px; background: var(--teal-500); border-radius: 50%; }
    .course-title { font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem; }
    .course-desc { font-size: 0.85rem; color: var(--text-secondary); flex: 1; line-height: 1.5; margin-bottom: 0.875rem; }
    .course-meta {
      display: flex; gap: 1rem; font-size: 0.78rem; color: var(--text-muted);
      margin-bottom: 1rem; flex-wrap: wrap;
    }
    .course-footer { margin-top: auto; display: flex; align-items: center; justify-content: flex-end; }
    .enrolled-badge { font-size: 0.85rem; color: var(--success); font-weight: 500; }
 
    .toast-msg {
      position: fixed;
      bottom: 2rem; right: 2rem;
      background: var(--bg-card);
      border: 1px solid rgba(16,185,129,0.3);
      color: #34d399;
      padding: 0.75rem 1.25rem;
      border-radius: var(--radius-md);
      font-size: 0.875rem;
      animation: slideUp 0.3s ease;
      z-index: 300;
    }
  `]
})
export class StudentCoursesComponent implements OnInit {
  loading    = signal(true);
  courses    = signal<Course[]>([]);
  enrolledIds = signal<Set<number>>(new Set());
  enrolling  = signal<number | null>(null);
  successMsg = signal('');
  activeTab  = signal<'all' | 'enrolled'>('all');
 
  constructor(
    private auth: AuthService,
    private courseSvc: CourseService,
    private enrollSvc: EnrollmentService,
  ) {}
 
  get visibleCourses() {
    return () => {
      const all = this.courses();
      if (this.activeTab() === 'enrolled') {
        return all.filter(c => this.enrolledIds().has(c.courseId));
      }
      return all;
    };
  }
 
  statusBadge(s: string): string {
    const m: Record<string, string> = {
      ACTIVE: 'ec-badge-success', DRAFT: 'ec-badge-neutral',
      COMPLETED: 'ec-badge-info', ARCHIVED: 'ec-badge-warning',
    };
    return m[s] ?? 'ec-badge-neutral';
  }
 
  ngOnInit(): void {
    this.courseSvc.getAllCourses().subscribe({
      next: r => {
        if (r.success) this.courses.set(r.data ?? []);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
 
    const sId = this.auth.getUserId() ?? 1;
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => {
        if (r.success) {
          const ids = new Set((r.data ?? []).map(e => e.courseId));
          this.enrolledIds.set(ids);
        }
      }
    });
  }
 
  enroll(course: Course): void {
    const studentId = this.auth.getUserId() ?? 1;
    this.enrolling.set(course.courseId);
    this.enrollSvc.enroll({ studentId, courseId: course.courseId }).subscribe({
      next: r => {
        if (r.success) {
          this.enrolledIds.update(s => { s.add(course.courseId); return new Set(s); });
          this.successMsg.set(`Enrolled in "${course.title}" successfully!`);
          setTimeout(() => this.successMsg.set(''), 3000);
        }
        this.enrolling.set(null);
      },
      error: () => this.enrolling.set(null),
    });
  }
}
 