import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-auth-shell',
  standalone: true,
  imports: [RouterOutlet,CommonModule],
  template: `
    <div class="auth-shell">
      <!-- Left Panel -->
      <div class="auth-panel auth-hero">
        <div class="hero-bg"></div>
        <div class="hero-content">
          <div class="brand">
            <span class="brand-icon">🎓</span>
            <h1 class="brand-name">EduConnect</h1>
          </div>
          <p class="brand-tagline">Digital Education & E-Learning Governance System</p>
          <div class="hero-features">
            <div class="feature-item" *ngFor="let f of features">
              <span class="feature-icon">{{ f.icon }}</span>
              <span>{{ f.label }}</span>
            </div>
          </div>
          <div class="hero-orbs">
            <div class="orb orb-1"></div>
            <div class="orb orb-2"></div>
            <div class="orb orb-3"></div>
          </div>
        </div>
      </div>

      <!-- Right Panel -->
      <div class="auth-panel auth-form-panel">
        <div class="form-container">
          <router-outlet />
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-shell {
      display: flex;
      min-height: 100vh;
    }
    .auth-panel { flex: 1; }

    /* Hero Side */
    .auth-hero {
      position: relative;
      background: var(--bg-deep);
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      max-width: 520px;
    }
    .hero-bg {
      position: absolute;
      inset: 0;
      background:
        radial-gradient(ellipse 80% 60% at 20% 30%, rgba(20,184,166,0.12) 0%, transparent 60%),
        radial-gradient(ellipse 60% 50% at 80% 70%, rgba(245,158,11,0.08) 0%, transparent 60%);
    }
    .hero-content {
      position: relative;
      z-index: 1;
      padding: 3rem;
      max-width: 400px;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 0.875rem;
      margin-bottom: 1rem;
    }
    .brand-icon { font-size: 2.5rem; }
    .brand-name {
      font-family: var(--font-display);
      font-size: 2rem;
      font-weight: 800;
      background: linear-gradient(135deg, var(--teal-400), var(--gold-400));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    .brand-tagline {
      color: var(--text-secondary);
      font-size: 0.95rem;
      line-height: 1.6;
      margin-bottom: 2.5rem;
    }
    .hero-features {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .feature-item {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      color: var(--text-secondary);
      font-size: 0.9rem;
    }
    .feature-icon { font-size: 1.25rem; }

    /* Orbs */
    .hero-orbs { position: absolute; inset: 0; pointer-events: none; }
    .orb {
      position: absolute;
      border-radius: 50%;
      filter: blur(60px);
      opacity: 0.12;
    }
    .orb-1 { width: 300px; height: 300px; background: var(--teal-500); top: -100px; right: -100px; }
    .orb-2 { width: 200px; height: 200px; background: var(--gold-500); bottom: -50px; left: -50px; }
    .orb-3 { width: 150px; height: 150px; background: var(--teal-400); top: 50%; right: -30px; }

    /* Form Side */
    .auth-form-panel {
      background: var(--bg-void);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .form-container {
      width: 100%;
      max-width: 440px;
    }

    @media (max-width: 768px) {
      .auth-shell { flex-direction: column; }
      .auth-hero { max-width: 100%; min-height: 200px; }
      .hero-features { display: none; }
    }
  `]
})
export class AuthShellComponent {
  features = [
    { icon: '📚', label: 'Access courses anytime, anywhere' },
    { icon: '📝', label: 'Take quizzes, tests and submit assignments' },
    { icon: '📊', label: 'Track your learning progress in real-time' },
    { icon: '🏆', label: 'Earn certificates upon completion' },
    { icon: '👨‍🏫', label: 'Learn from expert instructors' },
  ];
}
