import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService, AssessmentService } from '../../../core/services/api.services';
import { Course, Enrollment, Assessment } from '../../../core/models/models';

@Component({
  selector: 'app-teacher-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="dashboard">
      <!-- Welcome Banner -->
      <div class="welcome-banner">
        <div>
          <h1>Teacher Portal 👨‍🏫</h1>
          <p>Welcome back, <strong>{{ name() }}</strong>! Manage your courses and content.</p>
        </div>
        <div style="display:flex;gap:0.75rem">
          <a routerLink="/teacher/courses" class="ec-btn ec-btn-secondary">Manage Courses</a>
          <a routerLink="/teacher/content" class="ec-btn ec-btn-primary">Upload Content</a>
        </div>
      </div>

      <!-- Stats -->
      <div class="stats-grid">
        <div class="ec-stat-card">
          <div class="ec-stat-icon">📚</div>
          <div class="ec-stat-number">{{ courses().length }}</div>
          <div class="ec-stat-label">My Courses</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">👥</div>
          <div class="ec-stat-number">{{ totalStudents() }}</div>
          <div class="ec-stat-label">Total Students</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">📝</div>
          <div class="ec-stat-number">{{ assessments().length }}</div>
          <div class="ec-stat-label">Assessments</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">✅</div>
          <div class="ec-stat-number">{{ activeCourses() }}</div>
          <div class="ec-stat-label">Active Courses</div>
        </div>
      </div>

      <div class="bottom-grid">
        <!-- My Courses -->
        <div class="ec-card">
          <div class="card-header-row">
            <div>
              <div class="ec-section-title">My Courses</div>
              <div class="ec-section-sub">Courses you are teaching</div>
            </div>
            <a routerLink="/teacher/courses" class="ec-btn ec-btn-secondary ec-btn-sm">View All</a>
          </div>
          @if (courses().length === 0) {
            <div class="ec-empty">
              <div class="ec-empty-icon">📚</div>
              <h3>No courses yet</h3>
            </div>
          } @else {
            @for (c of courses().slice(0, 5); track c.courseId) {
              <div class="course-row">
                <div class="course-info">
                  <span class="course-dot"></span>
                  <div>
                    <p class="course-name">{{ c.title }}</p>
                    <p class="course-date">{{ c.startDate | date:'mediumDate' }} — {{ c.endDate | date:'mediumDate' }}</p>
                  </div>
                </div>
                <span class="ec-badge" [class]="statusBadge(c.status)">{{ c.status }}</span>
              </div>
            }
          }
        </div>

        <!-- Pending Grading -->
        <div class="ec-card">
          <div class="card-header-row">
            <div>
              <div class="ec-section-title">Pending Grading</div>
              <div class="ec-section-sub">Submissions awaiting your review</div>
            </div>
            <a routerLink="/teacher/assessments" class="ec-btn ec-btn-secondary ec-btn-sm">Grade</a>
          </div>
          @if (pendingSubmissions().length === 0) {
            <div class="ec-empty">
              <div class="ec-empty-icon">✅</div>
              <h3>All caught up!</h3>
              <p>No pending submissions</p>
            </div>
          } @else {
            @for (s of pendingSubmissions().slice(0, 5); track s.submissionId) {
              <div class="submission-row">
                <div>
                  <p class="sub-name">{{ s.studentName ?? 'Student #'+s.studentId }}</p>
                  <p class="sub-assessment">{{ s.assessmentTitle ?? 'Assessment #'+s.assessmentId }}</p>
                </div>
                <span class="ec-badge ec-badge-warning">SUBMITTED</span>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { animation: fadeIn 0.3s ease; }
    .welcome-banner {
      display: flex; align-items: center; justify-content: space-between;
      background: linear-gradient(135deg, var(--bg-card), rgba(245,158,11,0.04));
      border: 1px solid var(--border-subtle); border-radius: var(--radius-xl);
      padding: 2rem; margin-bottom: 2rem;
    }
    .welcome-banner h1 { font-size: 1.75rem; margin-bottom: 0.25rem; }
    .welcome-banner p { color: var(--text-secondary); }

    .stats-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 1.25rem; margin-bottom: 2rem; }
    @media (max-width:1024px) { .stats-grid { grid-template-columns: repeat(2,1fr); } }

    .bottom-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    @media (max-width:900px) { .bottom-grid { grid-template-columns: 1fr; } }

    .card-header-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.25rem; }

    .course-row {
      display: flex; align-items: center; justify-content: space-between;
      padding: 0.75rem 0; border-bottom: 1px solid rgba(255,255,255,0.03);
    }
    .course-row:last-child { border-bottom: none; }
    .course-info { display: flex; align-items: center; gap: 0.75rem; }
    .course-dot { width: 8px; height: 8px; background: var(--gold-500); border-radius: 50%; flex-shrink: 0; }
    .course-name { font-size: 0.875rem; font-weight: 500; margin-bottom: 0.2rem; }
    .course-date { font-size: 0.75rem; color: var(--text-muted); }

    .submission-row {
      display: flex; align-items: center; justify-content: space-between;
      padding: 0.75rem 0; border-bottom: 1px solid rgba(255,255,255,0.03);
    }
    .submission-row:last-child { border-bottom: none; }
    .sub-name { font-size: 0.875rem; font-weight: 500; margin-bottom: 0.2rem; }
    .sub-assessment { font-size: 0.75rem; color: var(--text-muted); }
  `]
})
export class TeacherDashboardComponent implements OnInit {
  name = signal('Teacher');
  courses = signal<Course[]>([]);
  assessments = signal<Assessment[]>([]);
  totalStudents = signal(0);
  activeCourses = signal(0);
  pendingSubmissions = signal<any[]>([]);

  constructor(
    private auth: AuthService,
    private courseSvc: CourseService,
    private assessSvc: AssessmentService,
    private enrollSvc: EnrollmentService,
  ) {}

  statusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'ec-badge-success', DRAFT:'ec-badge-neutral', COMPLETED:'ec-badge-info', ARCHIVED:'ec-badge-warning' };
    return m[s] ?? 'ec-badge-neutral';
  }

  ngOnInit(): void {
    const userName = this.auth.currentUser()?.name ?? 'Teacher';
    this.name.set(userName.split(' ')[0]);

    this.courseSvc.getAllCourses().subscribe({
      next: r => {
        if (r.success) {
          const teacherId = this.auth.getUserId();
          const myCourses = (r.data ?? []).filter(c => c.teacherId === teacherId);
          this.courses.set(myCourses);
          this.activeCourses.set(myCourses.filter(c => c.status === 'ACTIVE').length);

          // Load enrollments for each course to count students
          let total = 0;
          let pending = myCourses.length;
          if (pending === 0) return;
          myCourses.forEach(c => {
            this.enrollSvc.getByCourse(c.courseId).subscribe({
              next: er => {
                if (er.success) total += (er.data ?? []).length;
                pending--;
                if (pending === 0) this.totalStudents.set(total);
              },
              error: () => { pending--; }
            });

            // Load assessments per course
            this.assessSvc.getByCourse(c.courseId).subscribe({
              next: ar => {
                if (ar.success) {
                  this.assessments.update(arr => [...arr, ...(ar.data ?? [])]);
                  // Load pending submissions per assessment
                  (ar.data ?? []).forEach(a => {
                    this.assessSvc.getSubmissionsByAssessment(a.assessmentId).subscribe({
                      next: sr => {
                        if (sr.success) {
                          const pending_subs = (sr.data ?? []).filter(s => s.status === 'SUBMITTED');
                          this.pendingSubmissions.update(arr => [...arr, ...pending_subs]);
                        }
                      }
                    });
                  });
                }
              }
            });
          });
        }
      }
    });
  }
}
