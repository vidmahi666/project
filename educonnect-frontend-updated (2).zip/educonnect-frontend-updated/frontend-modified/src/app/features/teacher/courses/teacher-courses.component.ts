import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService } from '../../../core/services/api.services';
import { Course } from '../../../core/models/models';

@Component({
  selector: 'app-teacher-courses',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div>
      <div class="ec-page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h2 class="ec-section-title">My Courses</h2>
          <p class="ec-section-sub">Create and manage your courses</p>
        </div>
        <button class="ec-btn ec-btn-primary" (click)="openCreate()">+ New Course</button>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (courses().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">📚</div>
          <h3>No courses yet</h3>
          <p>Create your first course to get started</p>
          <button class="ec-btn ec-btn-primary" style="margin-top:1rem" (click)="openCreate()">Create Course</button>
        </div>
      } @else {
        <div class="ec-table-wrap">
          <table class="ec-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              @for (c of courses(); track c.courseId) {
                <tr>
                  <td>
                    <div>
                      <p style="font-weight:500">{{ c.title }}</p>
                      <p style="font-size:0.78rem;color:var(--text-muted)">{{ c.description | slice:0:60 }}...</p>
                    </div>
                  </td>
                  <td>{{ c.startDate | date:'mediumDate' }}</td>
                  <td>{{ c.endDate | date:'mediumDate' }}</td>
                  <td>
                    <span class="ec-badge" [class]="statusBadge(c.status)">{{ c.status }}</span>
                  </td>
                  <td>
                    <button class="ec-btn ec-btn-secondary ec-btn-sm" (click)="openEdit(c)">Edit</button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }

      <!-- Create / Edit Modal -->
      @if (showModal()) {
        <div class="ec-modal-overlay" (click)="closeModal()">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>{{ editingId() ? 'Edit Course' : 'Create New Course' }}</h3>
              <button class="ec-modal-close" (click)="closeModal()">✕</button>
            </div>
            @if (formError()) {
              <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ formError() }}</span></div>
            }
            <form [formGroup]="form" (ngSubmit)="submit()">
              <div class="ec-form-group">
                <label class="ec-label">Course Title *</label>
                <input formControlName="title" type="text" class="ec-input"
                  [class.error]="isInvalid('title')" placeholder="e.g. Introduction to Java" />
                @if (isInvalid('title')) { <span class="ec-error-text">Title is required</span> }
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Description</label>
                <textarea formControlName="description" class="ec-textarea" rows="3"
                  placeholder="Course description..."></textarea>
              </div>
              <div class="ec-grid-2">
                <div class="ec-form-group">
                  <label class="ec-label">Start Date *</label>
                  <input formControlName="startDate" type="date" class="ec-input" [class.error]="isInvalid('startDate')" />
                  @if (isInvalid('startDate')) { <span class="ec-error-text">Required</span> }
                </div>
                <div class="ec-form-group">
                  <label class="ec-label">End Date *</label>
                  <input formControlName="endDate" type="date" class="ec-input" [class.error]="isInvalid('endDate')" />
                  @if (isInvalid('endDate')) { <span class="ec-error-text">Required</span> }
                </div>
              </div>
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="closeModal()">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="ec-spinner"></span> }
                  {{ editingId() ? 'Update' : 'Create' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .ec-page-header { margin-bottom: 2rem; }
  `]
})
export class TeacherCoursesComponent implements OnInit {
  loading   = signal(true);
  courses   = signal<Course[]>([]);
  showModal = signal(false);
  editingId = signal<number | null>(null);
  saving    = signal(false);
  formError = signal('');
  form: FormGroup;

  constructor(private auth: AuthService, private courseSvc: CourseService, private fb: FormBuilder) {
    this.form = this.fb.group({
      title:       ['', Validators.required],
      description: [''],
      startDate:   ['', Validators.required],
      endDate:     ['', Validators.required],
    });
  }

  isInvalid(f: string): boolean {
    const c = this.form.get(f);
    return !!(c?.invalid && c?.touched);
  }

  statusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'ec-badge-success', DRAFT:'ec-badge-neutral', COMPLETED:'ec-badge-info', ARCHIVED:'ec-badge-warning' };
    return m[s] ?? 'ec-badge-neutral';
  }

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses(): void {
    this.courseSvc.getAllCourses().subscribe({
      next: r => {
        if (r.success) {
          const teacherId = this.auth.getUserId();
          this.courses.set((r.data ?? []).filter(c => c.teacherId === teacherId));
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  openCreate(): void {
    this.editingId.set(null);
    this.form.reset();
    this.formError.set('');
    this.showModal.set(true);
  }

  openEdit(c: Course): void {
    this.editingId.set(c.courseId);
    this.form.patchValue({ title: c.title, description: c.description, startDate: c.startDate, endDate: c.endDate });
    this.formError.set('');
    this.showModal.set(true);
  }

  closeModal(): void { this.showModal.set(false); }

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const teacherId = this.auth.getUserId()!;
    const payload = { ...this.form.value, teacherId };
    this.saving.set(true);
    const call = this.editingId()
      ? this.courseSvc.updateCourse(this.editingId()!, payload)
      : this.courseSvc.createCourse(payload);

    call.subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.closeModal();
          this.loadCourses();
        } else {
          this.formError.set(r.message ?? 'Operation failed');
        }
      },
      error: err => {
        this.saving.set(false);
        this.formError.set(err?.error?.message ?? 'Operation failed');
      }
    });
  }
}
