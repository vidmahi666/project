import { Routes } from '@angular/router';
import { ShellComponent } from '../../shared/components/shell/shell.component';

export const TEACHER_ROUTES: Routes = [
  {
    path: '',
    component: ShellComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/teacher-dashboard.component').then(m => m.TeacherDashboardComponent)
      },
      {
        path: 'courses',
        loadComponent: () => import('./courses/teacher-courses.component').then(m => m.TeacherCoursesComponent)
      },
      {
        path: 'content',
        loadComponent: () => import('./content/teacher-content.component').then(m => m.TeacherContentComponent)
      },
      {
        path: 'assessments',
        loadComponent: () => import('./assessments/teacher-assessments.component').then(m => m.TeacherAssessmentsComponent)
      },
      {
        path: 'students',
        loadComponent: () => import('./students/teacher-students.component').then(m => m.TeacherStudentsComponent)
      }
    ]
  }
];
