import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../core/services/api.services';
import { User, UserRole } from '../../../core/models/models';

type StaffRole = 'TEACHER' | 'PROGRAM_MANAGER' | 'COMPLIANCE_OFFICER' | 'GOVERNMENT_AUDITOR';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div>
      <div class="page-header-row">
        <div>
          <h2 class="ec-section-title">User Management</h2>
          <p class="ec-section-sub">Manage all platform users and their roles</p>
        </div>
        <button class="ec-btn ec-btn-primary" (click)="openCreate()">+ Create Staff Account</button>
      </div>

      <!-- Role filter -->
      <div class="filter-bar">
        @for (f of filters; track f.value) {
          <button class="filter-chip" [class.active]="filterRole() === f.value" (click)="setFilter(f.value)">
            {{ f.label }} ({{ countByRole(f.value) }})
          </button>
        }
      </div>

      <!-- Search -->
      <div style="margin-bottom:1.25rem">
        <input type="text" class="ec-input search-input" placeholder="Search by name or email..."
          [(ngModel)]="searchQuery" (ngModelChange)="onSearch($event)" />
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (filteredUsers().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">👥</div>
          <h3>No users found</h3>
        </div>
      } @else {
        <div class="ec-table-wrap">
          <table class="ec-table">
            <thead>
              <tr><th>User</th><th>Role</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              @for (u of filteredUsers(); track u.userId) {
                <tr>
                  <td>
                    <div style="display:flex;align-items:center;gap:0.75rem">
                      <div class="u-av">{{ u.name.charAt(0).toUpperCase() }}</div>
                      <div>
                        <p style="font-weight:500">{{ u.name }}</p>
                        <p style="font-size:0.78rem;color:var(--text-muted)">{{ u.email }}</p>
                      </div>
                    </div>
                  </td>
                  <td><span class="ec-badge" [class]="roleBadge(u.role)">{{ u.role }}</span></td>
                  <td>
                    <span class="ec-badge" [class]="u.status === 'ACTIVE' ? 'ec-badge-success' : 'ec-badge-danger'">
                      {{ u.status }}
                    </span>
                  </td>
                  <td>
                    <div style="display:flex;gap:0.5rem;flex-wrap:wrap">
                      @if (u.status === 'ACTIVE') {
                        <button class="ec-btn ec-btn-danger ec-btn-sm" (click)="deactivate(u)">Deactivate</button>
                      } @else {
                        <button class="ec-btn ec-btn-primary ec-btn-sm" (click)="activate(u)">Activate</button>
                      }
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }

      <!-- Create Staff Modal -->
      @if (showModal()) {
        <div class="ec-modal-overlay" (click)="closeModal()">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>Create Staff Account</h3>
              <button class="ec-modal-close" (click)="closeModal()">✕</button>
            </div>
            @if (formError()) {
              <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ formError() }}</span></div>
            }
            @if (formSuccess()) {
              <div class="ec-alert ec-alert-success"><span>✅</span><span>{{ formSuccess() }}</span></div>
            }
            <form [formGroup]="form" (ngSubmit)="createStaff()">
              <div class="ec-form-group">
                <label class="ec-label">Role *</label>
                <select formControlName="role" class="ec-select">
                  <option value="">Select role</option>
                  @for (r of staffRoles; track r.value) {
                    <option [value]="r.value">{{ r.label }}</option>
                  }
                </select>
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Full Name *</label>
                <input formControlName="name" type="text" class="ec-input"
                  [class.error]="isInvalid('name')" placeholder="Full name" />
                @if (isInvalid('name')) { <span class="ec-error-text">Name required</span> }
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Email *</label>
                <input formControlName="email" type="email" class="ec-input"
                  [class.error]="isInvalid('email')" placeholder="email@example.com" />
                @if (isInvalid('email')) { <span class="ec-error-text">Valid email required</span> }
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Password *</label>
                <input formControlName="password" type="password" class="ec-input"
                  [class.error]="isInvalid('password')" placeholder="Min. 8 characters" />
                @if (isInvalid('password')) { <span class="ec-error-text">Min 8 characters</span> }
              </div>
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="closeModal()">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="ec-spinner"></span> } Create Account
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .page-header-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem; }
    .filter-bar { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.25rem; }
    .filter-chip {
      padding: 0.35rem 0.875rem; border-radius: 20px;
      border: 1px solid var(--border-subtle); background: transparent;
      color: var(--text-secondary); font-size: 0.8rem; cursor: pointer;
      transition: all var(--transition-fast);
    }
    .filter-chip.active { background: rgba(20,184,166,0.15); border-color: var(--border-accent); color: var(--teal-400); }
    .search-input { max-width: 360px; }
    .u-av {
      width: 32px; height: 32px;
      background: var(--bg-hover); border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 0.8rem; font-weight: 700; flex-shrink: 0;
    }
  `]
})
export class AdminUsersComponent implements OnInit {
  loading   = signal(true);
  users     = signal<User[]>([]);
  filteredUsers = signal<User[]>([]);
  filterRole = signal<string>('ALL');
  searchQuery = '';
  showModal = signal(false);
  saving    = signal(false);
  formError = signal('');
  formSuccess = signal('');
  form: FormGroup;

  filters = [
    { label: 'All', value: 'ALL' },
    { label: 'Students', value: 'STUDENT' },
    { label: 'Teachers', value: 'TEACHER' },
    { label: 'Admins', value: 'ADMIN' },
    { label: 'Program Mgr', value: 'PROGRAM_MANAGER' },
    { label: 'Compliance', value: 'COMPLIANCE_OFFICER' },
    { label: 'Auditors', value: 'GOVERNMENT_AUDITOR' },
  ];

  staffRoles = [
    { label: 'Teacher', value: 'TEACHER' },
    { label: 'Program Manager', value: 'PROGRAM_MANAGER' },
    { label: 'Compliance Officer', value: 'COMPLIANCE_OFFICER' },
    { label: 'Government Auditor', value: 'GOVERNMENT_AUDITOR' },
  ];

  constructor(private adminSvc: AdminService, private fb: FormBuilder) {
    this.form = this.fb.group({
      role:     ['', Validators.required],
      name:     ['', Validators.required],
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }

  roleBadge(r: string): string {
    const m: Record<string,string> = {
      STUDENT:'ec-badge-teal', TEACHER:'ec-badge-gold', ADMIN:'ec-badge-danger',
      PROGRAM_MANAGER:'ec-badge-info', COMPLIANCE_OFFICER:'ec-badge-warning', GOVERNMENT_AUDITOR:'ec-badge-neutral'
    };
    return m[r] ?? 'ec-badge-neutral';
  }

  isInvalid(f: string): boolean {
    const c = this.form.get(f);
    return !!(c?.invalid && c?.touched);
  }

  countByRole(role: string): number {
    if (role === 'ALL') return this.users().length;
    return this.users().filter(u => u.role === role).length;
  }

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.adminSvc.getAllUsers().subscribe({
      next: r => {
        if (r.success) {
          this.users.set(r.data ?? []);
          this.applyFilter();
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  setFilter(role: string): void {
    this.filterRole.set(role);
    this.applyFilter();
  }

  onSearch(q: string): void { this.applyFilter(); }

  applyFilter(): void {
    let list = this.users();
    const role = this.filterRole();
    if (role !== 'ALL') list = list.filter(u => u.role === role);
    const q = this.searchQuery.toLowerCase();
    if (q) list = list.filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
    this.filteredUsers.set(list);
  }

  deactivate(u: User): void {
    this.adminSvc.deactivateUser(u.userId).subscribe({
      next: r => {
        if (r.success) {
          this.users.update(arr => arr.map(x => x.userId === u.userId ? { ...x, status: 'INACTIVE' as any } : x));
          this.applyFilter();
        }
      }
    });
  }

  activate(u: User): void {
    this.adminSvc.activateUser(u.userId).subscribe({
      next: r => {
        if (r.success) {
          this.users.update(arr => arr.map(x => x.userId === u.userId ? { ...x, status: 'ACTIVE' as any } : x));
          this.applyFilter();
        }
      }
    });
  }

  openCreate(): void {
    this.form.reset();
    this.formError.set('');
    this.formSuccess.set('');
    this.showModal.set(true);
  }
  closeModal(): void { this.showModal.set(false); }

  createStaff(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const { role, name, email, password } = this.form.value;
    const payload = { name, email, password };

    const callMap: Record<StaffRole, any> = {
      TEACHER: this.adminSvc.createTeacher(payload),
      PROGRAM_MANAGER: this.adminSvc.createProgramManager(payload),
      COMPLIANCE_OFFICER: this.adminSvc.createComplianceOfficer(payload),
      GOVERNMENT_AUDITOR: this.adminSvc.createGovernmentAuditor(payload),
    };

    const call = callMap[role as StaffRole];
    if (!call) { this.formError.set('Invalid role selected'); this.saving.set(false); return; }

    call.subscribe({
      next: (r: any) => {
        this.saving.set(false);
        if (r.success) {
          this.formSuccess.set('Account created successfully!');
          this.loadUsers();
          setTimeout(() => this.closeModal(), 1500);
        } else { this.formError.set(r.message ?? 'Creation failed'); }
      },
      error: (err: any) => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Creation failed'); }
    });
  }
}
