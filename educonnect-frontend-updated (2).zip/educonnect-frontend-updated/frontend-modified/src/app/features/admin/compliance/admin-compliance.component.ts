import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComplianceService } from '../../../core/services/api.services';
import { ComplianceRecord } from '../../../core/models/models';

@Component({
  selector: 'app-admin-compliance',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div>
      <div class="page-header-row">
        <div>
          <h2 class="ec-section-title">Compliance Management</h2>
          <p class="ec-section-sub">Monitor policy compliance across the platform</p>
        </div>
        <button class="ec-btn ec-btn-primary" (click)="openCreate()">+ Add Record</button>
      </div>

      <!-- Summary Cards -->
      <div class="summary-grid">
        <div class="ec-stat-card">
          <div class="ec-stat-icon">📋</div>
          <div class="ec-stat-number">{{ records().length }}</div>
          <div class="ec-stat-label">Total Records</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">✅</div>
          <div class="ec-stat-number">{{ passCount() }}</div>
          <div class="ec-stat-label">Passed</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">❌</div>
          <div class="ec-stat-number">{{ failCount() }}</div>
          <div class="ec-stat-label">Failed</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">⏳</div>
          <div class="ec-stat-number">{{ pendingCount() }}</div>
          <div class="ec-stat-label">Pending</div>
        </div>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (records().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">✅</div>
          <h3>No compliance records</h3>
          <p>Add compliance checks to track policy adherence</p>
        </div>
      } @else {
        <div class="ec-table-wrap">
          <table class="ec-table">
            <thead>
              <tr><th>Entity ID</th><th>Type</th><th>Check Type</th><th>Result</th><th>Notes</th><th>Date</th><th>Actions</th></tr>
            </thead>
            <tbody>
              @for (r of records(); track r.recordId) {
                <tr>
                  <td>{{ r.entityId }}</td>
                  <td><span class="type-tag">{{ r.entityType }}</span></td>
                  <td style="font-size:0.85rem">{{ r.checkType }}</td>
                  <td>
                    <span class="ec-badge" [class]="resultBadge(r.result)">{{ r.result }}</span>
                  </td>
                  <td style="font-size:0.82rem;color:var(--text-secondary);max-width:180px">
                    {{ r.resolutionNotes ?? '—' }}
                  </td>
                  <td style="font-size:0.82rem">{{ r.createdAt | date:'mediumDate' }}</td>
                  <td>
                    @if (r.result === 'PENDING') {
                      <div style="display:flex;gap:0.4rem">
                        <button class="ec-btn ec-btn-primary ec-btn-sm" (click)="updateResult(r, 'PASS')">Pass</button>
                        <button class="ec-btn ec-btn-danger ec-btn-sm" (click)="updateResult(r, 'FAIL')">Fail</button>
                      </div>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }

      <!-- Create Modal -->
      @if (showModal()) {
        <div class="ec-modal-overlay" (click)="closeModal()">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>Add Compliance Record</h3>
              <button class="ec-modal-close" (click)="closeModal()">✕</button>
            </div>
            @if (formError()) {
              <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ formError() }}</span></div>
            }
            <form [formGroup]="form" (ngSubmit)="create()">
              <div class="ec-grid-2">
                <div class="ec-form-group">
                  <label class="ec-label">Entity ID *</label>
                  <input formControlName="entityId" type="number" class="ec-input" placeholder="1" />
                </div>
                <div class="ec-form-group">
                  <label class="ec-label">Entity Type *</label>
                  <select formControlName="entityType" class="ec-select">
                    <option value="">Select</option>
                    <option value="STUDENT">Student</option>
                    <option value="COURSE">Course</option>
                    <option value="TEACHER">Teacher</option>
                    <option value="PROGRAM">Program</option>
                  </select>
                </div>
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Check Type *</label>
                <input formControlName="checkType" type="text" class="ec-input" placeholder="e.g. GDPR_COMPLIANCE" />
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Resolution Notes</label>
                <textarea formControlName="resolutionNotes" class="ec-textarea" rows="3" placeholder="Optional notes..."></textarea>
              </div>
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="closeModal()">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="ec-spinner"></span> } Add Record
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .page-header-row { display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:2rem; }
    .summary-grid { display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;margin-bottom:2rem; }
    @media(max-width:768px) { .summary-grid { grid-template-columns:repeat(2,1fr); } }
    .type-tag {
      font-size:0.72rem;font-weight:700;text-transform:uppercase;
      background:rgba(59,130,246,0.12);color:#60a5fa;
      padding:0.15rem 0.5rem;border-radius:4px;
    }
  `]
})
export class AdminComplianceComponent implements OnInit {
  loading   = signal(true);
  records   = signal<ComplianceRecord[]>([]);
  showModal = signal(false);
  saving    = signal(false);
  formError = signal('');
  passCount   = signal(0);
  failCount   = signal(0);
  pendingCount = signal(0);
  form: FormGroup;

  constructor(private complianceSvc: ComplianceService, private fb: FormBuilder) {
    this.form = this.fb.group({
      entityId:        ['', Validators.required],
      entityType:      ['', Validators.required],
      checkType:       ['', Validators.required],
      resolutionNotes: [''],
    });
  }

  resultBadge(r: string): string {
    const m: Record<string,string> = { PASS:'ec-badge-success', FAIL:'ec-badge-danger', PENDING:'ec-badge-warning' };
    return m[r] ?? 'ec-badge-neutral';
  }

  ngOnInit(): void { this.loadRecords(); }

  loadRecords(): void {
    this.complianceSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const list = r.data ?? [];
          this.records.set(list);
          this.passCount.set(list.filter(x => x.result === 'PASS').length);
          this.failCount.set(list.filter(x => x.result === 'FAIL').length);
          this.pendingCount.set(list.filter(x => x.result === 'PENDING').length);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  create(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const payload = { ...this.form.value, result: 'PENDING' };
    this.complianceSvc.create(payload).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) { this.closeModal(); this.loadRecords(); }
        else this.formError.set(r.message ?? 'Failed');
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); }
    });
  }

  updateResult(rec: ComplianceRecord, result: string): void {
    this.complianceSvc.updateResult(rec.recordId, result).subscribe({
      next: r => {
        if (r.success) {
          this.records.update(arr => arr.map(x => x.recordId === rec.recordId ? { ...x, result } : x));
          this.loadRecords();
        }
      }
    });
  }
}
