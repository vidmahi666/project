import { Routes } from '@angular/router';
import { ShellComponent } from '../../shared/components/shell/shell.component';
import { roleGuard } from '../../core/guards/auth.guard';

export const ADMIN_ROUTES: Routes = [
  {
    path: '',
    component: ShellComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent)
      },
      {
        path: 'users',
        canActivate: [roleGuard('ADMIN')],
        loadComponent: () => import('./users/admin-users.component').then(m => m.AdminUsersComponent)
      },
      {
        path: 'courses',
        loadComponent: () => import('./courses/admin-courses.component').then(m => m.AdminCoursesComponent)
      },
      {
        path: 'reports',
        loadComponent: () => import('./reports/admin-reports.component').then(m => m.AdminReportsComponent)
      },
      {
        path: 'compliance',
        loadComponent: () => import('./compliance/admin-compliance.component').then(m => m.AdminComplianceComponent)
      },
      {
        path: 'audits',
        loadComponent: () => import('./audits/admin-audits.component').then(m => m.AdminAuditsComponent)
      }
    ]
  }
];
