import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ComplianceService } from '../../../core/services/api.services';
import { Audit } from '../../../core/models/models';

@Component({
  selector: 'app-admin-audits',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div>
      <div class="page-header-row">
        <div>
          <h2 class="ec-section-title">Audit Management</h2>
          <p class="ec-section-sub">Manage formal government and compliance audits</p>
        </div>
        <button class="ec-btn ec-btn-primary" (click)="openCreate()">+ Initiate Audit</button>
      </div>

      <!-- Status summary -->
      <div class="summary-grid">
        <div class="ec-stat-card">
          <div class="ec-stat-icon">🔍</div>
          <div class="ec-stat-number">{{ audits().length }}</div>
          <div class="ec-stat-label">Total Audits</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">⏳</div>
          <div class="ec-stat-number">{{ countByStatus('IN_PROGRESS') }}</div>
          <div class="ec-stat-label">In Progress</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">✅</div>
          <div class="ec-stat-number">{{ countByStatus('COMPLETED') }}</div>
          <div class="ec-stat-label">Completed</div>
        </div>
        <div class="ec-stat-card">
          <div class="ec-stat-icon">🚨</div>
          <div class="ec-stat-number">{{ countByStatus('FLAGGED') }}</div>
          <div class="ec-stat-label">Flagged</div>
        </div>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (audits().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">🔍</div>
          <h3>No audits yet</h3>
          <p>Initiate an audit to begin formal review</p>
        </div>
      } @else {
        <div class="audit-cards">
          @for (a of audits(); track a.auditId) {
            <div class="audit-card ec-card">
              <div class="audit-header">
                <div>
                  <span class="ec-badge" [class]="statusBadge(a.status)">{{ a.status }}</span>
                </div>
                <span class="audit-date">{{ a.createdAt | date:'mediumDate' }}</span>
              </div>
              <div class="audit-scope">
                <span class="scope-label">Scope</span>
                <p class="scope-value">{{ a.scope }}</p>
              </div>
              @if (a.findings) {
                <div class="audit-findings">
                  <span class="findings-label">Findings</span>
                  <p class="findings-text">{{ a.findings }}</p>
                </div>
              }
              <div class="audit-footer">
                <span class="officer-tag">🧑‍💼 Officer #{{ a.officerId }}</span>
                <div style="display:flex;gap:0.5rem">
                  @if (a.status === 'IN_PROGRESS') {
                    <button class="ec-btn ec-btn-primary ec-btn-sm" (click)="updateStatus(a, 'COMPLETED')">
                      Mark Complete
                    </button>
                    <button class="ec-btn ec-btn-danger ec-btn-sm" (click)="updateStatus(a, 'FLAGGED')">
                      Flag
                    </button>
                  }
                </div>
              </div>
            </div>
          }
        </div>
      }

      <!-- Create Audit Modal -->
      @if (showModal()) {
        <div class="ec-modal-overlay" (click)="closeModal()">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>Initiate Audit</h3>
              <button class="ec-modal-close" (click)="closeModal()">✕</button>
            </div>
            @if (formError()) {
              <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ formError() }}</span></div>
            }
            <form [formGroup]="form" (ngSubmit)="create()">
              <div class="ec-form-group">
                <label class="ec-label">Audit Scope *</label>
                <select formControlName="scope" class="ec-select">
                  <option value="">Select scope</option>
                  <option value="FULL_PLATFORM">Full Platform</option>
                  <option value="STUDENT_DATA">Student Data</option>
                  <option value="COURSE_QUALITY">Course Quality</option>
                  <option value="FINANCIAL">Financial</option>
                  <option value="GDPR">GDPR Compliance</option>
                  <option value="ACCREDITATION">Accreditation</option>
                </select>
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Initial Findings / Notes</label>
                <textarea formControlName="findings" class="ec-textarea" rows="3"
                  placeholder="Initial observations or scope details..."></textarea>
              </div>
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="closeModal()">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="ec-spinner"></span> } Initiate
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .page-header-row { display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:2rem; }
    .summary-grid { display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;margin-bottom:2rem; }
    @media(max-width:768px) { .summary-grid { grid-template-columns:repeat(2,1fr); } }

    .audit-cards { display:flex;flex-direction:column;gap:1.25rem; }
    .audit-card {}
    .audit-header { display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem; }
    .audit-date { font-size:0.8rem;color:var(--text-muted); }

    .audit-scope { margin-bottom:0.875rem; }
    .scope-label { font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:0.25rem; }
    .scope-value { font-size:1rem;font-weight:600;color:var(--text-primary); }

    .audit-findings { background:var(--bg-surface);border-radius:var(--radius-sm);padding:0.75rem;margin-bottom:0.875rem; }
    .findings-label { font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:0.25rem; }
    .findings-text { font-size:0.875rem;color:var(--text-secondary);line-height:1.5; }

    .audit-footer { display:flex;justify-content:space-between;align-items:center; }
    .officer-tag { font-size:0.8rem;color:var(--text-secondary); }
  `]
})
export class AdminAuditsComponent implements OnInit {
  loading   = signal(true);
  audits    = signal<Audit[]>([]);
  showModal = signal(false);
  saving    = signal(false);
  formError = signal('');
  form: FormGroup;

  constructor(
    private auth: AuthService,
    private complianceSvc: ComplianceService,
    private fb: FormBuilder
  ) {
    this.form = this.fb.group({
      scope:    ['', Validators.required],
      findings: [''],
    });
  }

  statusBadge(s: string): string {
    const m: Record<string,string> = {
      IN_PROGRESS:'ec-badge-info', COMPLETED:'ec-badge-success',
      FLAGGED:'ec-badge-danger', PENDING:'ec-badge-warning'
    };
    return m[s] ?? 'ec-badge-neutral';
  }

  countByStatus(status: string): number {
    return this.audits().filter(a => a.status === status).length;
  }

  ngOnInit(): void { this.loadAudits(); }

  loadAudits(): void {
    this.complianceSvc.getAllAudits().subscribe({
      next: r => { if (r.success) this.audits.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  create(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const officerId = this.auth.getUserId()!;
    this.saving.set(true);
    this.complianceSvc.createAudit({ ...this.form.value, officerId, status: 'IN_PROGRESS' }).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) { this.closeModal(); this.loadAudits(); }
        else this.formError.set(r.message ?? 'Failed');
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); }
    });
  }

  updateStatus(a: Audit, status: string): void {
    this.complianceSvc.updateAuditStatus(a.auditId, status).subscribe({
      next: r => {
        if (r.success) this.audits.update(arr => arr.map(x => x.auditId === a.auditId ? { ...x, status } : x));
      }
    });
  }
}
