import { Component, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  private fb     = inject(FormBuilder);
  private auth   = inject(AuthService);
  private router = inject(Router);

  loading  = signal(false);
  error    = signal('');
  showPwd  = signal(false);

  form = this.fb.nonNullable.group({
    email:    ['', [Validators.required, Validators.email]],
    password: ['', Validators.required],
  });

  demos = [
    { role: 'Admin',   email: 'admin@educonnect.com',   password: 'Admin@123' },
    { role: 'Student', email: 'student@educonnect.com',    password: 'Student@123' },
    { role: 'Teacher', email: 'teacher@educonnect.com',      password: 'Teacher@123' },
    { role: 'Compliance', email: 'compliance@educonnect.com',      password: 'Compliance@123' },
    { role: 'Auditor', email: 'auditor@educonnect.com',      password: 'Auditor@123' }
  ];

  isInvalid(field: string): boolean {
    const c = this.form.get(field);
    return !!(c?.invalid && c?.touched);
  }

  fillDemo(d: { email: string; password: string }): void {
    this.form.patchValue(d);
  }

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading.set(true);
    this.error.set('');

    this.auth.login(this.form.getRawValue()).subscribe({
      next: res => {
        this.loading.set(false);
        if (res.data?.role) this.router.navigateByUrl(this.auth.dashboardRoute());
        else this.error.set(res.message ?? 'Login failed');
      },
      error: err => {
        this.loading.set(false);
        this.error.set(err?.error?.message ?? 'Invalid credentials. Please try again.');
      },
    });
  }
}
