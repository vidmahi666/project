import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { ProgressService, EnrollmentService } from '../../../core/services/index';
import { Progress, Enrollment } from '../../../core/models';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-student-progress',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './student-progress.component.html',
  styleUrls: ['./student-progress.component.scss'],
})
export class StudentProgressComponent implements OnInit {
  private auth         = inject(AuthService);
  private progressSvc  = inject(ProgressService);
  private enrollmentSvc = inject(EnrollmentService);

  loading      = signal(true);
  progressList = signal<Progress[]>([]);

  completedCount  = computed(() => this.progressList().filter(p => p.status === 'COMPLETED').length);
  inProgressCount = computed(() => this.progressList().filter(p => p.status === 'IN_PROGRESS').length);
  overallPct = computed(() => {
    const list = this.progressList();
    if (!list.length) return 0;
    return Math.round(list.reduce((s, p) => s + p.completionPercentage, 0) / list.length);
  });

  colors = ['blue','mint','gold','purple','blue','mint','gold'];
  icons  = ['bi-book','bi-code-slash','bi-bar-chart','bi-flask','bi-camera','bi-globe','bi-music-note-beamed'];

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    forkJoin([
      this.progressSvc.getByStudent(sId),
      this.enrollmentSvc.getByStudent(sId)
    ]).subscribe({
      next: ([progressRes, enrollmentRes]) => {
        if (progressRes.success && enrollmentRes.success) {
          const enrollments = enrollmentRes.data ?? [];
          const enrollmentMap = new Map(enrollments.map(e => [e.courseId, e.courseTitle]));
          
          const progressData = (progressRes.data ?? []).map(p => ({
            ...p,
            courseTitle: p.courseTitle || enrollmentMap.get(p.courseId) || undefined
          }));
          
          this.progressList.set(progressData);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }
}
