package com.educonnect.authservice.security;

import com.educonnect.authservice.entity.User;
import com.educonnect.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service @RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {
    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + email));

        // Inactive users cannot authenticate
        if (user.getStatus() == User.Status.INACTIVE) {
            throw new DisabledException("Account is deactivated");
        }

        return new org.springframework.security.core.userdetails.User(
                user.getEmail(), user.getPassword(),
                true, true, true,
                user.getStatus() == User.Status.ACTIVE,  // accountNonLocked = only if ACTIVE
                List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name())));
    }
}
