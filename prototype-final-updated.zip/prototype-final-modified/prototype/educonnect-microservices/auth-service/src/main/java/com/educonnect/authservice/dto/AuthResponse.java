package com.educonnect.authservice.dto;

import com.educonnect.authservice.entity.User;
import lombok.*;

@Data @Builder @AllArgsConstructor @NoArgsConstructor
public class AuthResponse {
    private Long userId;
    private String name;
    private String email;
    private User.Role role;
    private String token;
    private User.Status status;
}
