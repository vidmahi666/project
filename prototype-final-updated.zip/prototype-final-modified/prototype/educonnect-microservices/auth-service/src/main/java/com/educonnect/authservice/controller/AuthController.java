package com.educonnect.authservice.controller;

import com.educonnect.authservice.dto.*;
import com.educonnect.authservice.entity.User;
import com.educonnect.authservice.repository.UserRepository;
import com.educonnect.authservice.service.AuthService;
import com.educonnect.authservice.service.JWTService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Register, Login and Admin user management")
public class AuthController {
    private final AuthService authService;
    private final UserRepository userRepository;
    private final AuthenticationManager authenticationManager;
    private final JWTService jwtService;

    @PostMapping("/auth/register")
    @Operation(summary = "Register new student account")
    public ResponseEntity<ApiResponse<AuthResponse>> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Registration successful", authService.register(request)));
    }

    @PostMapping("/auth/login")
    @Operation(summary = "Login and receive JWT token")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Block deactivated users from logging in
        if (user.getStatus() == User.Status.INACTIVE) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(ApiResponse.error("Your account has been deactivated. Please contact the administrator."));
        }

        String token = authentication.isAuthenticated() ? jwtService.generateToken(user) : null;
        AuthResponse response = AuthResponse.builder()
                .userId(user.getUserId()).name(user.getName())
                .email(user.getEmail()).role(user.getRole()).token(token).build();
        return ResponseEntity.ok(ApiResponse.ok("Login successful", response));
    }

    @PostMapping("/admin/teachers")
    @Operation(summary = "[ADMIN] Create Teacher account")
    public ResponseEntity<ApiResponse<User>> createTeacher(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Teacher created", authService.createTeacher(request)));
    }

    @GetMapping("/admin/teachers")
    @Operation(summary = "[ADMIN] List all Teachers")
    public ResponseEntity<ApiResponse<List<User>>> getAllTeachers() {
        return ResponseEntity.ok(ApiResponse.ok("All teachers", authService.getAllTeachers()));
    }

    @PostMapping("/admin/program-managers")
    @Operation(summary = "[ADMIN] Create Program Manager account")
    public ResponseEntity<ApiResponse<User>> createProgramManager(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Program Manager created", authService.createProgramManager(request)));
    }

    @PostMapping("/admin/compliance-officers")
    @Operation(summary = "[ADMIN] Create Compliance Officer account")
    public ResponseEntity<ApiResponse<User>> createComplianceOfficer(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Compliance Officer created", authService.createComplianceOfficer(request)));
    }

    @PostMapping("/admin/government-auditors")
    @Operation(summary = "[ADMIN] Create Government Auditor account")
    public ResponseEntity<ApiResponse<User>> createGovernmentAuditor(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Government Auditor created", authService.createGovernmentAuditor(request)));
    }

    @GetMapping("/admin/users")
    @Operation(summary = "[ADMIN] List all users")
    public ResponseEntity<ApiResponse<List<User>>> getAllUsers() {
        return ResponseEntity.ok(ApiResponse.ok("All users", authService.getAllUsers()));
    }

    @GetMapping("/admin/users/{id}")
    @Operation(summary = "[ADMIN] Get user by ID")
    public ResponseEntity<ApiResponse<User>> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("User", authService.getUserById(id)));
    }

    @PatchMapping("/admin/users/{id}/deactivate")
    @Operation(summary = "[ADMIN] Deactivate user account")
    public ResponseEntity<ApiResponse<User>> deactivateUser(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("User deactivated", authService.deactivateUser(id)));
    }

    @PatchMapping("/admin/users/{id}/activate")
    @Operation(summary = "[ADMIN] Activate user account")
    public ResponseEntity<ApiResponse<User>> activateUser(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("User activated", authService.activateUser(id)));
    }
}
