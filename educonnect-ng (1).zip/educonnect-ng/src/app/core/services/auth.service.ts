import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiResponse, AuthResponse, LoginRequest, RegisterRequest, UserRole } from '../models';

const TOKEN_KEY = 'ec_token';
const USER_KEY  = 'ec_user';

@Injectable({ providedIn: 'root' })
export class AuthService {

  // ── Reactive state ──────────────────────────────────────────
  private _user = signal<AuthResponse | null>(this.loadUser());
  readonly user      = this._user.asReadonly();
  readonly isLoggedIn = computed(() => !!this._user());
  readonly role       = computed(() => this._user()?.role ?? null);
  readonly userId     = computed(() => this._user()?.userId ?? null);
  readonly initials   = computed(() => {
    const n = this._user()?.name ?? '';
    return n.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
  });

  constructor(private http: HttpClient, private router: Router) {}

  // ── Public API ──────────────────────────────────────────────
  login(req: LoginRequest): Observable<ApiResponse<AuthResponse>> {
    return this.http
      .post<ApiResponse<AuthResponse>>(`${environment.authUrl}/login`, req)
      .pipe(tap(res => { if (res.data?.token) this.persist(res.data); }));
  }

  register(req: RegisterRequest): Observable<ApiResponse<AuthResponse>> {
    return this.http.post<ApiResponse<AuthResponse>>(`${environment.authUrl}/register`, req);
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this._user.set(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  hasRole(...roles: UserRole[]): boolean {
    const r = this.role();
    return r ? roles.includes(r) : false;
  }

  dashboardRoute(): string {
    const routes: Partial<Record<UserRole, string>> = {
      [UserRole.STUDENT]:            '/student/dashboard',
      [UserRole.TEACHER]:            '/teacher/dashboard',
      [UserRole.ADMIN]:              '/admin/dashboard',
      [UserRole.PROGRAM_MANAGER]:    '/admin/dashboard',
      [UserRole.COMPLIANCE_OFFICER]: '/compliance/dashboard',
      [UserRole.GOVERNMENT_AUDITOR]: '/auditor/dashboard',
    };
    return routes[this.role()!] ?? '/login';
  }

  // ── Private helpers ─────────────────────────────────────────
  private persist(data: AuthResponse): void {
    localStorage.setItem(TOKEN_KEY, data.token);
    localStorage.setItem(USER_KEY, JSON.stringify(data));
    this._user.set(data);
  }

  private loadUser(): AuthResponse | null {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }
}
