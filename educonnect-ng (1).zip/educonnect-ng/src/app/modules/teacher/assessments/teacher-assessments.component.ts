import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AssessmentService, CourseService, ProgressService, StudentService, ToastService } from '../../../core/services/index';
import { Assessment, Submission, Course, Student, AssessmentType, AssessmentStatus } from '../../../core/models';

@Component({
  selector: 'app-teacher-assessments',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './teacher-assessments.component.html',
  styleUrls: ['./teacher-assessments.component.scss'],
})
export class TeacherAssessmentsComponent implements OnInit {
  private auth        = inject(AuthService);
  private assessSvc   = inject(AssessmentService);
  private courseSvc   = inject(CourseService);
  private progressSvc = inject(ProgressService);
  private studentSvc  = inject(StudentService);
  private toast       = inject(ToastService);
  private fb          = inject(FormBuilder);

  loading              = signal(true);
  tab                  = signal<'list'|'grading'>('list');
  myCourses            = signal<Course[]>([]);
  assessments          = signal<Assessment[]>([]);
  pendingSubmissions   = signal<Submission[]>([]);
  studentNameMap       = signal<Map<number, string>>(new Map());
  showCreateModal      = signal(false);
  showGradeModal       = signal(false);
  showProgressPrompt   = signal(false);
  selectedSub          = signal<Submission|null>(null);
  gradedStudentId      = signal<number>(0);
  gradedCourseId       = signal<number>(0);
  creating             = signal(false);
  grading              = signal(false);
  updatingProgress     = signal(false);
  createError          = signal('');
  gradeError           = signal('');
  progressPct          = 0;
  progressMetrics      = '';

  types: AssessmentType[] = [
    AssessmentType.QUIZ,
    AssessmentType.EXAM,
    AssessmentType.ASSIGNMENT,
    AssessmentType.PROJECT,
  ];

  studentName(id: number): string {
    return this.studentNameMap().get(id) ?? `Student #${id}`;
  }

  studentInitials(id: number): string {
    const name = this.studentNameMap().get(id);
    if (name) return name.trim().split(' ').slice(0,2).map(w => w[0]).join('').toUpperCase();
    return 'S' + String(id).slice(-2);
  }

  assessmentTitle(id: number): string {
    return this.assessments().find(a => a.assessmentId === id)?.title ?? `Assessment #${id}`;
  }

  courseTitle(id: number): string {
    return this.myCourses().find(c => c.courseId === id)?.title ?? `Course #${id}`;
  }

  createForm = this.fb.nonNullable.group({
    courseId:     ['', Validators.required],
    title:        ['', Validators.required],
    type:         ['', Validators.required],
    instructions: [''],
    maxScore:     [100, [Validators.required, Validators.min(0)]],
    passingScore: [60],
    dueDate:      [''],
    fileUri:      [''],
  });

  gradeForm = this.fb.nonNullable.group({
    score:    [null as unknown as number, [Validators.required, Validators.min(0)]],
    comments: [''],
  });

  isCInvalid(f: string): boolean {
    const c = this.createForm.get(f);
    return !!(c?.invalid && c?.touched);
  }

  ngOnInit(): void {
    const tid = this.auth.userId() ?? 1;
    // Load all students to build name map
    this.studentSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const m = new Map<number, string>();
          (r.data ?? []).forEach(s => m.set(s.studentId, s.name));
          this.studentNameMap.set(m);
        }
      },
    });
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const mine = (r.data ?? []).filter(c => c.teacherUserId === tid);
          this.myCourses.set(mine);
          this.loadAssessments(mine.map(c => c.courseId));
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false),
    });
  }

  loadAssessments(courseIds: number[]): void {
    if (!courseIds.length) { this.loading.set(false); return; }
    const all: Assessment[] = [];
    let pending = courseIds.length;
    courseIds.forEach(id => {
      this.assessSvc.getByCourse(id).subscribe({
        next: r => {
          if (r.success) all.push(...(r.data ?? []));
          if (--pending === 0) {
            this.assessments.set(all);
            this.loadAllSubmissions(all.map(a => a.assessmentId));
            this.loading.set(false);
          }
        },
        error: () => { if (--pending === 0) this.loading.set(false); },
      });
    });
  }

  loadAllSubmissions(assessmentIds: number[]): void {
    if (!assessmentIds.length) return;
    const pending_subs: Submission[] = [];
    let pending = assessmentIds.length;
    assessmentIds.forEach(id => {
      this.assessSvc.getSubmissionsByAssessment(id).subscribe({
        next: r => {
          if (r.success) pending_subs.push(...(r.data ?? []).filter(s => s.status === 'SUBMITTED'));
          if (--pending === 0) this.pendingSubmissions.set(pending_subs);
        },
        error: () => { --pending; },
      });
    });
  }

  loadSubmissions(a: Assessment): void {
    this.tab.set('grading');
    this.assessSvc.getSubmissionsByAssessment(a.assessmentId).subscribe({
      next: r => {
        if (r.success) {
          const pending = (r.data ?? []).filter(s => s.status === 'SUBMITTED');
          this.pendingSubmissions.update(all => [...all.filter(x => x.assessmentId !== a.assessmentId), ...pending]);
        }
      },
    });
  }

  openCreate(): void { this.createForm.reset({ maxScore: 100, passingScore: 60 }); this.createError.set(''); this.showCreateModal.set(true); }

  doCreate(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.creating.set(true);
    const v = this.createForm.getRawValue();
    this.assessSvc.create({ ...v, courseId: +v.courseId } as any).subscribe({
      next: r => {
        this.creating.set(false);
        if (r.success) {
          this.assessments.update(a => [r.data, ...a]);
          this.showCreateModal.set(false);
          this.toast.success('Assessment created!', `"${r.data.title}" saved as draft.`);
        } else { this.createError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.creating.set(false); this.createError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  activate(a: Assessment): void {
    this.assessSvc.activate(a.assessmentId).subscribe({
      next: r => {
        if (r.success) {
          this.assessments.update(arr => arr.map(x => x.assessmentId === a.assessmentId ? { ...x, status: AssessmentStatus.ACTIVE } : x));
          this.toast.success('Activated!', `"${a.title}" is now live for students.`);
        }
      },
    });
  }

  openGrade(s: Submission): void {
    this.selectedSub.set(s);
    this.gradeForm.reset();
    this.gradeError.set('');
    this.showGradeModal.set(true);
  }

  doGrade(): void {
    if (this.gradeForm.invalid) { this.gradeForm.markAllAsTouched(); return; }
    const s = this.selectedSub()!;
    this.grading.set(true);
    this.assessSvc.grade(s.submissionId, this.gradeForm.getRawValue() as any).subscribe({
      next: r => {
        this.grading.set(false);
        if (r.success) {
          this.pendingSubmissions.update(arr => arr.filter(x => x.submissionId !== s.submissionId));
          this.showGradeModal.set(false);
          this.toast.success('Graded!', `Score of ${this.gradeForm.value.score} saved.`);
          // Find courseId for this assessment to support progress update
          const assessment = this.assessments().find(a => a.assessmentId === s.assessmentId);
          this.gradedStudentId.set(s.studentId);
          this.gradedCourseId.set(assessment?.courseId ?? 0);
          this.progressPct = 0;
          this.progressMetrics = '';
          this.showProgressPrompt.set(true);
        } else { this.gradeError.set(r.message ?? 'Grading failed'); }
      },
      error: err => { this.grading.set(false); this.gradeError.set(err?.error?.message ?? 'Grading failed'); },
    });
  }

  doUpdateProgress(): void {
    const studentId = this.gradedStudentId();
    const courseId  = this.gradedCourseId();
    if (!studentId || !courseId) { this.showProgressPrompt.set(false); return; }
    this.updatingProgress.set(true);
    this.progressSvc.update(studentId, courseId, {
      completionPercentage: this.progressPct,
      metricsJson: this.progressMetrics || undefined,
    }).subscribe({
      next: r => {
        this.updatingProgress.set(false);
        this.showProgressPrompt.set(false);
        if (r.success) {
          this.toast.success('Progress updated!', `Student #${studentId} is now at ${this.progressPct}%.`);
        } else {
          this.toast.warning('Progress update failed', r.message ?? 'Could not update progress.');
        }
      },
      error: () => {
        this.updatingProgress.set(false);
        this.showProgressPrompt.set(false);
        this.toast.error('Error', 'Could not update progress.');
      },
    });
  }
}
