import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ContentService, CourseService, ToastService } from '../../../core/services/index';
import { Content, Course, ContentType, ContentStatus } from '../../../core/models';

@Component({
  selector: 'app-teacher-content',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './teacher-content.component.html',
  styleUrls: ['./teacher-content.component.scss'],
})
export class TeacherContentComponent implements OnInit {
  private auth       = inject(AuthService);
  private contentSvc = inject(ContentService);
  private courseSvc  = inject(CourseService);
  private toast      = inject(ToastService);
  private fb         = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  showModal = signal(false);
  formError = signal('');
  myCourses = signal<Course[]>([]);
  allContent = signal<Content[]>([]);
  selectedCourseId: number | null = null;
  typeFilter = '';

  contentTypes: ContentType[] = [
    ContentType.VIDEO,
    ContentType.PDF,
    ContentType.QUIZ,
    ContentType.DOCUMENT,
    ContentType.PRESENTATION,
  ];

  form = this.fb.nonNullable.group({
    courseId:    ['', Validators.required],
    title:       ['', Validators.required],
    type:        ['', Validators.required],
    fileUri:     ['', [Validators.required, Validators.pattern(/^https?:\/\/.+/)]],
    description: [''],
    sortOrder:   [1],
  });

  isInvalid(f: string): boolean {
    const c = this.form.get(f);
    return !!(c?.invalid && c?.touched);
  }

  typeIcon(t: ContentType): string {
    const m: Record<ContentType,string> = {
      VIDEO:'bi-play-circle-fill', PDF:'bi-file-earmark-pdf-fill',
      QUIZ:'bi-question-circle-fill', DOCUMENT:'bi-file-earmark-text-fill',
      PRESENTATION:'bi-easel-fill',
    };
    return m[t] ?? 'bi-file-fill';
  }

  filtered = computed(() => {
    let list = this.allContent();
    if (this.selectedCourseId) list = list.filter(c => c.courseId === this.selectedCourseId);
    if (this.typeFilter) list = list.filter(c => c.type === this.typeFilter);
    return list;
  });

  onCourseFilter(id: number | null): void { this.selectedCourseId = id; }

  ngOnInit(): void {
    const tid = this.auth.userId() ?? 1;
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const mine = (r.data ?? []).filter(c => c.teacherUserId === tid);
          this.myCourses.set(mine);
          this.loadContent(mine.map(c => c.courseId));
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false),
    });
  }

  loadContent(courseIds: number[]): void {
    if (!courseIds.length) { this.loading.set(false); return; }
    const all: Content[] = [];
    let pending = courseIds.length;
    courseIds.forEach(id => {
      this.contentSvc.getByCourse(id).subscribe({
        next: r => {
          if (r.success) all.push(...(r.data ?? []));
          if (--pending === 0) { this.allContent.set(all); this.loading.set(false); }
        },
        error: () => { if (--pending === 0) this.loading.set(false); },
      });
    });
  }

  openUpload(): void { this.form.reset({ sortOrder: 1 }); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doUpload(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const v = this.form.getRawValue();
    this.contentSvc.create({ ...v, courseId: +v.courseId } as any).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.allContent.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Uploaded!', `"${r.data.title}" added successfully.`);
        } else { this.formError.set(r.message ?? 'Upload failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Upload failed'); },
    });
  }

  archive(c: Content): void {
    this.contentSvc.updateStatus(c.contentId, ContentStatus.ARCHIVED).subscribe({
      next: r => {
        if (r.success) {
          this.allContent.update(arr => arr.map(x => x.contentId === c.contentId ? { ...x, status: ContentStatus.ARCHIVED } : x));
          this.toast.info('Archived', `"${c.title}" has been archived.`);
        }
      },
    });
  }
}
