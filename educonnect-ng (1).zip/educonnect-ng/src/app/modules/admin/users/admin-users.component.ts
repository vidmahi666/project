import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AdminUserService, ToastService } from '../../../core/services/index';
import { User, UserRole, UserStatus, CreateUserRequest } from '../../../core/models';

type StaffRole = 'TEACHER' | 'PROGRAM_MANAGER' | 'COMPLIANCE_OFFICER' | 'GOVERNMENT_AUDITOR';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './admin-users.component.html',
  styleUrls: [`./admin-users.component.scss`],
})
export class AdminUsersComponent implements OnInit {
  private adminSvc = inject(AdminUserService);
  private toast    = inject(ToastService);
  private fb       = inject(FormBuilder);

  loading      = signal(true);
  saving       = signal(false);
  showModal    = signal(false);
  allUsers     = signal<User[]>([]);
  roleFilter   = signal('ALL');
  statusFilter = signal('ALL');
  search       = '';
  formError    = signal('');
  formSuccess  = signal('');

  activeCount = computed(() => this.allUsers().filter(u => u.status === 'ACTIVE').length);

  roleTabs = [
    { key: 'ALL',              label: 'All',        icon: 'bi-people-fill' },
    { key: 'STUDENT',          label: 'Students',   icon: 'bi-mortarboard' },
    { key: 'TEACHER',          label: 'Teachers',   icon: 'bi-person-video2' },
    { key: 'ADMIN',            label: 'Admins',     icon: 'bi-shield-fill' },
    { key: 'PROGRAM_MANAGER',  label: 'PM',         icon: 'bi-briefcase-fill' },
    { key: 'COMPLIANCE_OFFICER', label: 'Compliance', icon: 'bi-shield-check' },
    { key: 'GOVERNMENT_AUDITOR', label: 'Auditors', icon: 'bi-search' },
  ];

  staffRoles = [
    { label: 'Teacher',            value: 'TEACHER',            icon: 'bi-person-video2' },
    { label: 'Program Manager',    value: 'PROGRAM_MANAGER',    icon: 'bi-briefcase' },
    { label: 'Compliance Officer', value: 'COMPLIANCE_OFFICER', icon: 'bi-shield-check' },
    { label: 'Govt. Auditor',      value: 'GOVERNMENT_AUDITOR', icon: 'bi-search' },
  ];

  createForm = this.fb.nonNullable.group({
    role:     ['', Validators.required],
    name:     ['', Validators.required],
    email:    ['', [Validators.required, Validators.email]],
    phone:    [''],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  filtered = computed(() => {
    let list = this.allUsers();
    const rf = this.roleFilter();
    if (rf !== 'ALL') list = list.filter(u => u.role === rf);
    const sf = this.statusFilter();
    if (sf !== 'ALL') list = list.filter(u => u.status === sf);
    const q = this.search.toLowerCase().trim();
    if (q) list = list.filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
    return list;
  });

  countByRole(key: string): number {
    if (key === 'ALL') return this.allUsers().length;
    return this.allUsers().filter(u => u.role === key).length;
  }

  roleLabel(r: string): string {
    const m: Record<string,string> = {
      STUDENT:'Student', TEACHER:'Teacher', ADMIN:'Admin',
      PROGRAM_MANAGER:'PM', COMPLIANCE_OFFICER:'Compliance', GOVERNMENT_AUDITOR:'Auditor',
    };
    return m[r] ?? r;
  }

  roleIcon(r: string): string {
    const m: Record<string,string> = {
      STUDENT:'bi-mortarboard', TEACHER:'bi-person-video2', ADMIN:'bi-shield-fill',
      PROGRAM_MANAGER:'bi-briefcase-fill', COMPLIANCE_OFFICER:'bi-shield-check', GOVERNMENT_AUDITOR:'bi-search',
    };
    return m[r] ?? 'bi-person';
  }

  isInvalid(f: string): boolean {
    const c = this.createForm.get(f);
    return !!(c?.invalid && c?.touched);
  }

  ngOnInit(): void { this.loadUsers(); }

  loadUsers(): void {
    this.adminSvc.getAllUsers().subscribe({
      next: r => { if (r.success) this.allUsers.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  deactivate(u: User): void {
    this.adminSvc.deactivateUser(u.userId).subscribe({
      next: r => {
        if (r.success) {
          this.allUsers.update(arr => arr.map(x => x.userId === u.userId ? { ...x, status: UserStatus.INACTIVE } : x));
          this.toast.warning('Deactivated', `${u.name}'s account has been deactivated.`);
        }
      },
    });
  }

  activate(u: User): void {
    this.adminSvc.activateUser(u.userId).subscribe({
      next: r => {
        if (r.success) {
          this.allUsers.update(arr => arr.map(x => x.userId === u.userId ? { ...x, status: UserStatus.ACTIVE } : x));
          this.toast.success('Activated', `${u.name}'s account is now active.`);
        }
      },
    });
  }

  openCreate(): void {
    this.createForm.reset();
    this.formError.set('');
    this.formSuccess.set('');
    this.showModal.set(true);
  }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.saving.set(true);
    const { role, name, email, phone, password } = this.createForm.getRawValue();
    const payload: CreateUserRequest = { name, email, password, phone: phone || undefined };

    const callMap: Record<StaffRole, any> = {
      TEACHER:            this.adminSvc.createTeacher(payload),
      PROGRAM_MANAGER:    this.adminSvc.createProgramManager(payload),
      COMPLIANCE_OFFICER: this.adminSvc.createComplianceOfficer(payload),
      GOVERNMENT_AUDITOR: this.adminSvc.createGovernmentAuditor(payload),
    };

    const call = callMap[role as StaffRole];
    if (!call) { this.formError.set('Invalid role'); this.saving.set(false); return; }

    call.subscribe({
      next: (r: any) => {
        this.saving.set(false);
        if (r.success) {
          this.formSuccess.set(`Account created for ${r.data.name}!`);
          this.allUsers.update(arr => [r.data, ...arr]);
          setTimeout(() => this.closeModal(), 1500);
        } else { this.formError.set(r.message ?? 'Creation failed'); }
      },
      error: (err: any) => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Creation failed'); },
    });
  }
}
