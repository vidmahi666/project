import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { EnrollmentService, ProgressService, AssessmentService } from '../../../core/services/index';
import { Course, Enrollment, Progress, Submission } from '../../../core/models';

interface CourseDisplay {
  title: string; courseId: number;
  progress: number; color: string; icon: string;
  nextLesson: string;
}
interface DeadlineDisplay {
  title: string; course: string; due: string;
  icon: string; urgent: boolean;
}

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './student-dashboard.component.html',
  styleUrls: ['./student-dashboard.component.scss'],
})
export class StudentDashboardComponent implements OnInit {
  private auth        = inject(AuthService);
  private enrollSvc   = inject(EnrollmentService);
  private progressSvc = inject(ProgressService);
  private assessSvc   = inject(AssessmentService);

  loadingCourses = signal(true);
  enrollments    = signal<Enrollment[]>([]);
  progressList   = signal<Progress[]>([]);
  submissions    = signal<Submission[]>([]);

  firstName = computed(() => (this.auth.user()?.name ?? 'Student').split(' ')[0]);

  overallPct = computed(() => {
    const list = this.progressList();
    if (!list.length) return 0;
    return Math.round(list.reduce((s, p) => s + p.completionPercentage, 0) / list.length);
  });

  stats = computed(() => [
    { label: 'Enrolled',    value: this.enrollments().length, tone: 'blue',   icon: 'bi-book-fill',        change: 'courses' },
    { label: 'Completed',   value: this.progressList().filter(p => p.status === 'COMPLETED').length, tone: 'mint', icon: 'bi-patch-check-fill', change: 'courses' },
    { label: 'Submissions', value: this.submissions().length, tone: 'gold',   icon: 'bi-pencil-fill',      change: 'total' },
    { label: 'Avg Score',   value: this.avgScore() + '%',     tone: 'purple', icon: 'bi-star-fill',        change: 'this term' },
  ]);

  courseDisplays = computed<CourseDisplay[]>(() => {
    const colors = ['blue', 'mint', 'gold', 'purple'];
    const icons  = ['bi-book', 'bi-code-slash', 'bi-bar-chart', 'bi-flask'];
    return this.enrollments().map((e, i) => {
      const p = this.progressList().find(x => x.courseId === e.courseId);
      return {
        title:      e.courseTitle ?? `Course #${e.courseId}`,
        courseId:   e.courseId,
        progress:   p?.completionPercentage ?? 0,
        color:      colors[i % colors.length],
        icon:       icons[i % icons.length],
        nextLesson: p?.status === 'COMPLETED' ? 'Completed!' : 'Continue',
      };
    });
  });

  deadlines = computed<DeadlineDisplay[]>(() =>
    this.submissions().filter(s => s.status === 'SUBMITTED').map(s => ({
      title:  `Assessment #${s.assessmentId}`,
      course: `Submission #${s.submissionId}`,
      due:    s.submittedAt ? new Date(s.submittedAt).toLocaleDateString() : 'TBD',
      icon:   'bi-pencil-square',
      urgent: false,
    }))
  );

  avgScore = computed(() => {
    const graded = this.submissions().filter(s => s.score !== null && s.score !== undefined);
    if (!graded.length) return 0;
    return Math.round(graded.reduce((a, b) => a + (b.score ?? 0), 0) / graded.length);
  });

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => { if (r.success) this.enrollments.set(r.data ?? []); this.loadingCourses.set(false); },
      error: () => this.loadingCourses.set(false),
    });
    this.progressSvc.getByStudent(sId).subscribe({ next: r => { if (r.success) this.progressList.set(r.data ?? []); } });
    this.assessSvc.getSubmissionsByStudent(sId).subscribe({ next: r => { if (r.success) this.submissions.set(r.data ?? []); } });
  }
}