import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { ProgressService } from '../../../core/services/index';
import { Progress } from '../../../core/models';

@Component({
  selector: 'app-student-progress',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './student-progress.component.html',
  styleUrls: ['./student-progress.component.scss'],
})
export class StudentProgressComponent implements OnInit {
  private auth        = inject(AuthService);
  private progressSvc = inject(ProgressService);

  loading      = signal(true);
  progressList = signal<Progress[]>([]);

  completedCount  = computed(() => this.progressList().filter(p => p.status === 'COMPLETED').length);
  inProgressCount = computed(() => this.progressList().filter(p => p.status === 'IN_PROGRESS').length);
  overallPct = computed(() => {
    const list = this.progressList();
    if (!list.length) return 0;
    return Math.round(list.reduce((s, p) => s + p.completionPercentage, 0) / list.length);
  });

  colors = ['blue','mint','gold','purple','blue','mint','gold'];
  icons  = ['bi-book','bi-code-slash','bi-bar-chart','bi-flask','bi-camera','bi-globe','bi-music-note-beamed'];

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    this.progressSvc.getByStudent(sId).subscribe({
      next: r => { if (r.success) this.progressList.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
