import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-unauthorized',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.scss'],
})
export class UnauthorizedComponent {
  private auth = inject(AuthService);
  back(): void { history.back(); }
  home(): void { if (this.auth.isLoggedIn()) window.location.href = this.auth.dashboardRoute(); else window.location.href = '/login'; }
}
