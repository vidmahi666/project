package com.educonnect.contentservice.service;
import com.educonnect.contentservice.dto.ContentRequest;
import com.educonnect.contentservice.entity.Content; import com.educonnect.contentservice.entity.ContentAccess;
import com.educonnect.contentservice.exception.ResourceNotFoundException;
import com.educonnect.contentservice.repository.ContentAccessRepository; import com.educonnect.contentservice.repository.ContentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
import java.util.List;
@Service @RequiredArgsConstructor
public class ContentService {
    private final ContentRepository contentRepository;
    private final ContentAccessRepository contentAccessRepository;

    @Transactional
    public Content createContent(ContentRequest req) {
        return contentRepository.save(Content.builder().courseId(req.getCourseId()).title(req.getTitle())
                .type(req.getType()).fileUri(req.getFileUri()).description(req.getDescription())
                .sortOrder(req.getSortOrder()).build());
    }

    public List<Content> getContentByCourse(Long courseId) { return contentRepository.findByCourseIdOrderBySortOrder(courseId); }

    public Content getContentById(Long id) { return contentRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Content",id)); }

    @Transactional
    public ContentAccess recordAccess(Long contentId, Long studentId) {
        Content content = getContentById(contentId);
        return contentAccessRepository.save(ContentAccess.builder().content(content).studentId(studentId).build());
    }

    public List<ContentAccess> getAccessByStudent(Long studentId) { return contentAccessRepository.findByStudentId(studentId); }

    @Transactional
    public Content updateContentStatus(Long id, Content.ContentStatus status) {
        Content c = getContentById(id); c.setStatus(status); return contentRepository.save(c);
    }
}
