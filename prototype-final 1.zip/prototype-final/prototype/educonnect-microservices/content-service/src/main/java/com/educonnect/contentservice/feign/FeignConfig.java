package com.educonnect.contentservice.feign;
import feign.RequestInterceptor; import feign.RequestTemplate;
import org.springframework.context.annotation.Bean; import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder; import org.springframework.web.context.request.ServletRequestAttributes;
@Configuration public class FeignConfig {
    @Bean public RequestInterceptor requestInterceptor(){
        return (RequestTemplate t)->{ServletRequestAttributes a=(ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
            if(a!=null){String auth=a.getRequest().getHeader("Authorization");if(auth!=null&&!auth.isBlank())t.header("Authorization",auth);}};
    }
}
