package com.educonnect.contentservice;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients; import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
@SpringBootApplication @EnableFeignClients @EnableJpaAuditing
public class ContentServiceApplication { public static void main(String[] a){SpringApplication.run(ContentServiceApplication.class,a);} }
