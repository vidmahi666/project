package com.educonnect.contentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name = "content_access")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class ContentAccess {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long accessId;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "content_id", nullable = false) private Content content;
    @Column(nullable = false) private Long studentId;
    @CreatedDate @Column(name = "accessed_at", nullable = false, updatable = false) private LocalDateTime accessedAt;
}
