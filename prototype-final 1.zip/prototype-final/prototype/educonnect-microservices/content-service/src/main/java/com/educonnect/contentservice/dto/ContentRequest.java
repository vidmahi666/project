package com.educonnect.contentservice.dto;
import com.educonnect.contentservice.entity.Content;
import jakarta.validation.constraints.NotBlank; import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data public class ContentRequest {
    @NotNull private Long courseId;
    @NotBlank private String title;
    @NotNull private Content.ContentType type;
    @NotBlank private String fileUri;
    private String description; private Integer sortOrder;
}
