package com.educonnect.contentservice.controller;

import com.educonnect.contentservice.dto.*;
import com.educonnect.contentservice.entity.Content;
import com.educonnect.contentservice.entity.ContentAccess;
import com.educonnect.contentservice.exception.ResourceNotFoundException;
import com.educonnect.contentservice.service.ContentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ContentController.class)
class ContentControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean ContentService contentService;

    @Test
    @DisplayName("GET /contents/course/{courseId} – 200 with list")
    void getByCourse_returns200() throws Exception {
        Content c = Content.builder().contentId(1L).courseId(10L).title("Week 1").build();
        when(contentService.getContentByCourse(10L)).thenReturn(List.of(c));

        mockMvc.perform(get("/contents/course/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data[0].title").value("Week 1"));
    }

    @Test
    @DisplayName("GET /contents/{id} – 404 when not found")
    void getById_notFound_returns404() throws Exception {
        when(contentService.getContentById(99L))
                .thenThrow(new ResourceNotFoundException("Content", 99L));

        mockMvc.perform(get("/contents/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("POST /contents/{id}/access – 400 when studentId param missing")
    void recordAccess_missingStudentId_returns400() throws Exception {
        mockMvc.perform(post("/contents/1/access"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("studentId")));
    }

    @Test
    @DisplayName("POST /contents/{id}/access – 200 when studentId provided")
    void recordAccess_success_returns200() throws Exception {
        ContentAccess access = ContentAccess.builder().accessId(1L).studentId(5L).build();
        when(contentService.recordAccess(1L, 5L)).thenReturn(access);

        mockMvc.perform(post("/contents/1/access").param("studentId", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.studentId").value(5));
    }

    @Test
    @DisplayName("PATCH /contents/{id}/status – 400 when status param missing")
    void updateStatus_missingStatus_returns400() throws Exception {
        mockMvc.perform(patch("/contents/1/status"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("status")));
    }

    @Test
    @DisplayName("PATCH /contents/{id}/status – 200 on success")
    void updateStatus_success_returns200() throws Exception {
        Content c = Content.builder().contentId(1L).status(Content.ContentStatus.ARCHIVED).build();
        when(contentService.updateContentStatus(1L, Content.ContentStatus.ARCHIVED)).thenReturn(c);

        mockMvc.perform(patch("/contents/1/status").param("status", "ARCHIVED"))
                .andExpect(status().isOk());
    }
}
