package com.educonnect.contentservice.service;

import com.educonnect.contentservice.dto.ContentRequest;
import com.educonnect.contentservice.entity.Content;
import com.educonnect.contentservice.entity.ContentAccess;
import com.educonnect.contentservice.exception.ResourceNotFoundException;
import com.educonnect.contentservice.repository.ContentAccessRepository;
import com.educonnect.contentservice.repository.ContentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ContentServiceTest {

    @Mock private ContentRepository contentRepository;
    @Mock private ContentAccessRepository contentAccessRepository;

    @InjectMocks private ContentService contentService;

    private Content content;

    @BeforeEach
    void setUp() {
        content = Content.builder()
                .contentId(1L).courseId(10L).title("Week 1 - Intro")
                .type(Content.ContentType.VIDEO)
                .fileUri("s3://bucket/week1.mp4")
                .status(Content.ContentStatus.ACTIVE)
                .sortOrder(1)
                .build();
    }

    @Test
    @DisplayName("createContent – saves and returns content")
    void createContent_success() {
        ContentRequest req = new ContentRequest();
        req.setCourseId(10L); req.setTitle("Week 1 - Intro");
        req.setType(Content.ContentType.VIDEO);
        req.setFileUri("s3://bucket/week1.mp4");
        req.setSortOrder(1);

        when(contentRepository.save(any(Content.class))).thenReturn(content);
        Content result = contentService.createContent(req);

        assertThat(result.getTitle()).isEqualTo("Week 1 - Intro");
        assertThat(result.getCourseId()).isEqualTo(10L);
        verify(contentRepository).save(any(Content.class));
    }

    @Test
    @DisplayName("getContentByCourse – returns ordered list for course")
    void getContentByCourse_returnsList() {
        when(contentRepository.findByCourseIdOrderBySortOrder(10L)).thenReturn(List.of(content));
        List<Content> result = contentService.getContentByCourse(10L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getCourseId()).isEqualTo(10L);
    }

    @Test
    @DisplayName("getContentById – returns content when found")
    void getContentById_found() {
        when(contentRepository.findById(1L)).thenReturn(Optional.of(content));
        Content result = contentService.getContentById(1L);
        assertThat(result.getContentId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getContentById – throws ResourceNotFoundException for unknown id")
    void getContentById_notFound_throws() {
        when(contentRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> contentService.getContentById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("recordAccess – creates ContentAccess record")
    void recordAccess_success() {
        ContentAccess access = ContentAccess.builder()
                .accessId(1L).content(content).studentId(5L).build();

        when(contentRepository.findById(1L)).thenReturn(Optional.of(content));
        when(contentAccessRepository.save(any(ContentAccess.class))).thenReturn(access);

        ContentAccess result = contentService.recordAccess(1L, 5L);
        assertThat(result.getStudentId()).isEqualTo(5L);
        verify(contentAccessRepository).save(any(ContentAccess.class));
    }

    @Test
    @DisplayName("getAccessByStudent – returns history for student")
    void getAccessByStudent_returnsList() {
        ContentAccess access = ContentAccess.builder().studentId(5L).content(content).build();
        when(contentAccessRepository.findByStudentId(5L)).thenReturn(List.of(access));
        List<ContentAccess> result = contentService.getAccessByStudent(5L);
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("updateContentStatus – sets new status")
    void updateContentStatus_success() {
        when(contentRepository.findById(1L)).thenReturn(Optional.of(content));
        when(contentRepository.save(any(Content.class))).thenAnswer(inv -> inv.getArgument(0));
        Content result = contentService.updateContentStatus(1L, Content.ContentStatus.ARCHIVED);
        assertThat(result.getStatus()).isEqualTo(Content.ContentStatus.ARCHIVED);
    }

    @Test
    @DisplayName("updateContentStatus – throws when content not found")
    void updateContentStatus_notFound_throws() {
        when(contentRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> contentService.updateContentStatus(99L, Content.ContentStatus.ARCHIVED))
                .isInstanceOf(ResourceNotFoundException.class);
    }
}
