package com.educonnect.studentservice.controller;

import com.educonnect.studentservice.dto.ApiResponse;
import com.educonnect.studentservice.dto.StudentInternalCreateRequest;
import com.educonnect.studentservice.entity.Student;
import com.educonnect.studentservice.service.StudentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students/internal")
@RequiredArgsConstructor
@Tag(name = "Student-Internal", description = "Internal endpoints for OpenFeign inter-service calls")
public class InternalStudentController {
    private final StudentService studentService;

    @PostMapping("/create")
    @Operation(summary = "[INTERNAL/OpenFeign] Auto-create student profile on user registration")
    public ResponseEntity<ApiResponse<Student>> createStudentFromRegistration(
            @Valid @RequestBody StudentInternalCreateRequest request) {
        Student student = studentService.createStudentFromRegistration(
                request.getUserId(), request.getName(), request.getContactInfo());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Student profile created", student));
    }

    @GetMapping("/{userId}")
    @Operation(summary = "[INTERNAL/OpenFeign] Get student by userId")
    public ResponseEntity<ApiResponse<Student>> getStudentByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Student found", studentService.getStudentByUserId(userId)));
    }
}
