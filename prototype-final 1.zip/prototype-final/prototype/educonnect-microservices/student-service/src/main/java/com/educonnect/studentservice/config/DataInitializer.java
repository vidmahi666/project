package com.educonnect.studentservice.config;

import com.educonnect.studentservice.entity.Student;
import com.educonnect.studentservice.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final StudentRepository studentRepository;

    @Override
    public void run(String... args) {
        // userId=3 corresponds to student@educonnect.com seeded in auth-service
        if (!studentRepository.existsByUserId(3L)) {
            studentRepository.save(Student.builder()
                    .userId(3L).name("Student One").dob(LocalDate.of(2000, 5, 15))
                    .gender("MALE").address("123 Main Street, Chennai")
                    .contactInfo("9876543210").status(Student.Status.ACTIVE).build());
            log.info("Seeded student profile for userId=3");
        }
    }
}
