package com.educonnect.studentservice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "student_documents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class StudentDocument {
    public enum VerificationStatus { PENDING, VERIFIED, REJECTED }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @Lob @Column(nullable = false, columnDefinition = "LONGBLOB")
    private byte[] documentData;

    private LocalDate uploadedDate;

    @Enumerated(EnumType.STRING) @Column(nullable = false)
    @Builder.Default private VerificationStatus verificationStatus = VerificationStatus.PENDING;

    @CreatedDate @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
}
