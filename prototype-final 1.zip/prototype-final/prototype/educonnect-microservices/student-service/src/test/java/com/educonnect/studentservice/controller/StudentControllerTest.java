package com.educonnect.studentservice.controller;

import com.educonnect.studentservice.dto.*;
import com.educonnect.studentservice.entity.Student;
import com.educonnect.studentservice.entity.StudentDocument;
import com.educonnect.studentservice.exception.ResourceNotFoundException;
import com.educonnect.studentservice.service.StudentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(StudentController.class)
class StudentControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean StudentService studentService;

    @Test
    @DisplayName("GET /students – 200 with list")
    void getAllStudents_returns200() throws Exception {
        Student s = Student.builder().studentId(1L).name("Alice").build();
        when(studentService.getAllStudents()).thenReturn(List.of(s));

        mockMvc.perform(get("/students"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /students/{id} – 200 when found")
    void getStudentById_returns200() throws Exception {
        Student s = Student.builder().studentId(1L).name("Alice").build();
        when(studentService.getStudentById(1L)).thenReturn(s);

        mockMvc.perform(get("/students/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.studentId").value(1));
    }

    @Test
    @DisplayName("GET /students/{id} – 404 when not found")
    void getStudentById_notFound_returns404() throws Exception {
        when(studentService.getStudentById(99L))
                .thenThrow(new ResourceNotFoundException("Student", 99L));

        mockMvc.perform(get("/students/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("GET /students/by-user/{userId} – 200 when found")
    void getStudentByUserId_returns200() throws Exception {
        Student s = Student.builder().studentId(1L).userId(100L).name("Alice").build();
        when(studentService.getStudentByUserId(100L)).thenReturn(s);

        mockMvc.perform(get("/students/by-user/100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userId").value(100));
    }

    @Test
    @DisplayName("PATCH /students/documents/{id}/verify – 400 when status param missing")
    void verifyDocument_missingStatus_returns400() throws Exception {
        mockMvc.perform(patch("/students/documents/1/verify"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("status")));
    }

    @Test
    @DisplayName("PATCH /students/documents/{id}/verify – 200 on success")
    void verifyDocument_returns200() throws Exception {
        StudentDocument doc = StudentDocument.builder().documentId(1L)
                .verificationStatus(StudentDocument.VerificationStatus.VERIFIED).build();
        when(studentService.verifyDocument(1L, StudentDocument.VerificationStatus.VERIFIED)).thenReturn(doc);

        mockMvc.perform(patch("/students/documents/1/verify")
                        .param("status", "VERIFIED"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.verificationStatus").value("VERIFIED"));
    }

    @Test
    @DisplayName("POST /students/{id}/documents – 201 on file upload")
    void uploadDocument_returns201() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "transcript.pdf", "application/pdf", "content".getBytes());

        StudentDocument doc = StudentDocument.builder().documentId(10L).build();
        when(studentService.uploadDocument(1L, any())).thenReturn(doc);

        mockMvc.perform(multipart("/students/1/documents").file(file))
                .andExpect(status().isCreated());
    }
}
