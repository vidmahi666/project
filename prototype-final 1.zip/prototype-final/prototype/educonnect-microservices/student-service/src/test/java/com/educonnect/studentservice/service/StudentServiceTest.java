package com.educonnect.studentservice.service;

import com.educonnect.studentservice.dto.StudentProfileRequest;
import com.educonnect.studentservice.entity.Student;
import com.educonnect.studentservice.entity.StudentDocument;
import com.educonnect.studentservice.exception.ResourceNotFoundException;
import com.educonnect.studentservice.repository.StudentDocumentRepository;
import com.educonnect.studentservice.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

    @Mock private StudentRepository studentRepository;
    @Mock private StudentDocumentRepository studentDocumentRepository;

    @InjectMocks private StudentService studentService;

    private Student student;

    @BeforeEach
    void setUp() {
        student = Student.builder()
                .studentId(1L).userId(100L).name("Alice")
                .contactInfo("alice@test.com")
                .status(Student.Status.ACTIVE)
                .build();
    }

    @Test
    @DisplayName("createStudentFromRegistration – creates new student when none exists")
    void createStudentFromRegistration_createsNew() {
        when(studentRepository.existsByUserId(100L)).thenReturn(false);
        when(studentRepository.save(any(Student.class))).thenReturn(student);

        Student result = studentService.createStudentFromRegistration(100L, "Alice", "alice@test.com");
        assertThat(result.getName()).isEqualTo("Alice");
        verify(studentRepository).save(any(Student.class));
    }

    @Test
    @DisplayName("createStudentFromRegistration – returns existing when already present")
    void createStudentFromRegistration_returnsExisting() {
        when(studentRepository.existsByUserId(100L)).thenReturn(true);
        when(studentRepository.findByUserId(100L)).thenReturn(Optional.of(student));

        Student result = studentService.createStudentFromRegistration(100L, "Alice", "alice@test.com");
        assertThat(result.getStudentId()).isEqualTo(1L);
        verify(studentRepository, never()).save(any());
    }

    @Test
    @DisplayName("getStudentByUserId – returns student when found")
    void getStudentByUserId_found() {
        when(studentRepository.findByUserId(100L)).thenReturn(Optional.of(student));
        Student result = studentService.getStudentByUserId(100L);
        assertThat(result.getUserId()).isEqualTo(100L);
    }

    @Test
    @DisplayName("getStudentByUserId – throws ResourceNotFoundException when not found")
    void getStudentByUserId_notFound_throws() {
        when(studentRepository.findByUserId(999L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> studentService.getStudentByUserId(999L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getStudentById – returns student when found")
    void getStudentById_found() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        Student result = studentService.getStudentById(1L);
        assertThat(result.getStudentId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getStudentById – throws ResourceNotFoundException when not found")
    void getStudentById_notFound_throws() {
        when(studentRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> studentService.getStudentById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getAllStudents – delegates to repository")
    void getAllStudents_returnsList() {
        when(studentRepository.findAll()).thenReturn(List.of(student));
        List<Student> result = studentService.getAllStudents();
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("updateStudentProfile – updates and returns student")
    void updateStudentProfile_success() {
        StudentProfileRequest req = new StudentProfileRequest();
        req.setName("Alice Updated"); req.setContactInfo("newalice@test.com");
        req.setDob(LocalDate.of(2000, 1, 1));
        req.setGender("FEMALE"); req.setAddress("123 Main St");

        when(studentRepository.findByUserId(100L)).thenReturn(Optional.of(student));
        when(studentRepository.save(any(Student.class))).thenAnswer(inv -> inv.getArgument(0));

        Student result = studentService.updateStudentProfile(100L, req);
        assertThat(result.getName()).isEqualTo("Alice Updated");
    }

    @Test
    @DisplayName("uploadDocument – saves document with file bytes")
    void uploadDocument_success() throws IOException {
        MockMultipartFile file = new MockMultipartFile(
                "file", "transcript.pdf", "application/pdf", "pdf-content".getBytes());

        StudentDocument doc = StudentDocument.builder()
                .documentId(10L).student(student)
                .documentData("pdf-content".getBytes()).build();

        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        when(studentDocumentRepository.save(any(StudentDocument.class))).thenReturn(doc);

        StudentDocument result = studentService.uploadDocument(1L, file);
        assertThat(result.getDocumentId()).isEqualTo(10L);
        verify(studentDocumentRepository).save(any(StudentDocument.class));
    }

    @Test
    @DisplayName("getStudentDocuments – returns docs for student")
    void getStudentDocuments_returnsList() {
        StudentDocument doc = StudentDocument.builder().student(student).build();
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        when(studentDocumentRepository.findByStudentStudentId(1L)).thenReturn(List.of(doc));
        List<StudentDocument> result = studentService.getStudentDocuments(1L);
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("verifyDocument – sets verification status")
    void verifyDocument_success() {
        StudentDocument doc = StudentDocument.builder()
                .documentId(10L).student(student)
                .verificationStatus(StudentDocument.VerificationStatus.PENDING).build();

        when(studentDocumentRepository.findById(10L)).thenReturn(Optional.of(doc));
        when(studentDocumentRepository.save(any(StudentDocument.class))).thenAnswer(inv -> inv.getArgument(0));

        StudentDocument result = studentService.verifyDocument(10L, StudentDocument.VerificationStatus.VERIFIED);
        assertThat(result.getVerificationStatus()).isEqualTo(StudentDocument.VerificationStatus.VERIFIED);
    }
}
