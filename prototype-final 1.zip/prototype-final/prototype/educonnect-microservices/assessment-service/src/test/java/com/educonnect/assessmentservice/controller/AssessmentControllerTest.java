package com.educonnect.assessmentservice.controller;

import com.educonnect.assessmentservice.dto.*;
import com.educonnect.assessmentservice.entity.*;
import com.educonnect.assessmentservice.exception.ResourceNotFoundException;
import com.educonnect.assessmentservice.service.AssessmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AssessmentController.class)
class AssessmentControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean AssessmentService assessmentService;

    @Test
    @DisplayName("GET /assessments/course/{courseId} – 200 with list")
    void getByCourse_returns200() throws Exception {
        Assessment a = Assessment.builder().assessmentId(1L).courseId(10L).title("Midterm").build();
        when(assessmentService.getAssessmentsByCourse(10L)).thenReturn(List.of(a));

        mockMvc.perform(get("/assessments/course/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data[0].title").value("Midterm"));
    }

    @Test
    @DisplayName("GET /assessments/{id} – 200 when found")
    void getById_returns200() throws Exception {
        Assessment a = Assessment.builder().assessmentId(1L).courseId(10L).title("Midterm").build();
        when(assessmentService.getAssessmentById(1L)).thenReturn(a);

        mockMvc.perform(get("/assessments/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.assessmentId").value(1));
    }

    @Test
    @DisplayName("GET /assessments/{id} – 404 when not found")
    void getById_notFound_returns404() throws Exception {
        when(assessmentService.getAssessmentById(99L))
                .thenThrow(new ResourceNotFoundException("Assessment", 99L));

        mockMvc.perform(get("/assessments/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("POST /assessments/submissions – 201 on success")
    void submit_returns201() throws Exception {
        SubmissionRequest req = new SubmissionRequest();
        req.setAssessmentId(1L); req.setStudentId(5L);
        req.setFileUri("s3://bucket/file.pdf");

        Submission sub = Submission.builder()
                .submissionId(50L).studentId(5L)
                .status(Submission.SubmissionStatus.SUBMITTED).build();

        when(assessmentService.submitAssessment(any())).thenReturn(sub);

        mockMvc.perform(post("/assessments/submissions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.submissionId").value(50));
    }

    @Test
    @DisplayName("GET /assessments/submissions/student/{studentId} – 200 with list")
    void getByStudent_returns200() throws Exception {
        when(assessmentService.getSubmissionsByStudent(5L)).thenReturn(List.of());
        mockMvc.perform(get("/assessments/submissions/student/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }
}
