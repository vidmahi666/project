package com.educonnect.assessmentservice.service;

import com.educonnect.assessmentservice.dto.*;
import com.educonnect.assessmentservice.entity.Assessment;
import com.educonnect.assessmentservice.entity.Submission;
import com.educonnect.assessmentservice.exception.ResourceNotFoundException;
import com.educonnect.assessmentservice.repository.AssessmentRepository;
import com.educonnect.assessmentservice.repository.SubmissionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AssessmentServiceTest {

    @Mock private AssessmentRepository assessmentRepository;
    @Mock private SubmissionRepository submissionRepository;

    @InjectMocks private AssessmentService assessmentService;

    private Assessment assessment;
    private Submission submission;

    @BeforeEach
    void setUp() {
        // In setUp()
        assessment = Assessment.builder()
                .assessmentId(1L).courseId(10L).title("Midterm")
                .type(Assessment.AssessmentType.EXAM)
                .maxScore(100).passingScore(60)  // Changed to int
                .status(Assessment.AssessmentStatus.DRAFT)
                .build();


        submission = Submission.builder()
                .submissionId(50L).assessment(assessment)
                .studentId(5L).fileUri("s3://bucket/file.pdf")
                .status(Submission.SubmissionStatus.SUBMITTED)
                .submittedAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    @DisplayName("createAssessment – saves and returns assessment")
    void createAssessment_success() {
        // In createAssessment_success()
        AssessmentRequest req = new AssessmentRequest();
        req.setCourseId(10L); req.setTitle("Midterm");
        req.setType(Assessment.AssessmentType.EXAM);
        req.setMaxScore(100); req.setPassingScore(60);  // Changed to int

        when(assessmentRepository.save(any(Assessment.class))).thenReturn(assessment);

        Assessment result = assessmentService.createAssessment(req);
        assertThat(result.getTitle()).isEqualTo("Midterm");
        assertThat(result.getCourseId()).isEqualTo(10L);
        verify(assessmentRepository).save(any(Assessment.class));
    }

    @Test
    @DisplayName("getAssessmentById – returns assessment when found")
    void getAssessmentById_found() {
        when(assessmentRepository.findById(1L)).thenReturn(Optional.of(assessment));
        Assessment result = assessmentService.getAssessmentById(1L);
        assertThat(result.getAssessmentId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getAssessmentById – throws ResourceNotFoundException when not found")
    void getAssessmentById_notFound_throws() {
        when(assessmentRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> assessmentService.getAssessmentById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getAssessmentsByCourse – delegates to repository")
    void getAssessmentsByCourse_returnsAll() {
        when(assessmentRepository.findByCourseId(10L)).thenReturn(List.of(assessment));
        List<Assessment> result = assessmentService.getAssessmentsByCourse(10L);
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("activateAssessment – changes status to ACTIVE")
    void activateAssessment_success() {
        when(assessmentRepository.findById(1L)).thenReturn(Optional.of(assessment));
        when(assessmentRepository.save(any(Assessment.class))).thenAnswer(inv -> inv.getArgument(0));
        Assessment result = assessmentService.activateAssessment(1L);
        assertThat(result.getStatus()).isEqualTo(Assessment.AssessmentStatus.ACTIVE);
    }

    @Test
    @DisplayName("submitAssessment – creates submission record")
    void submitAssessment_success() {
        SubmissionRequest req = new SubmissionRequest();
        req.setAssessmentId(1L); req.setStudentId(5L);
        req.setFileUri("s3://bucket/file.pdf");

        when(assessmentRepository.findById(1L)).thenReturn(Optional.of(assessment));
        when(submissionRepository.save(any(Submission.class))).thenReturn(submission);

        Submission result = assessmentService.submitAssessment(req);
        assertThat(result.getStudentId()).isEqualTo(5L);
        verify(submissionRepository).save(any(Submission.class));
    }

    @Test
    @DisplayName("gradeSubmission – sets score and status to GRADED")
    void gradeSubmission_success() {
        // In gradeSubmission_success()
        GradeRequest gradeReq = new GradeRequest();
        gradeReq.setScore(85); gradeReq.setFeedback("Good work");  // Changed to int

        when(submissionRepository.findById(50L)).thenReturn(Optional.of(submission));
        when(submissionRepository.save(any(Submission.class))).thenAnswer(inv -> inv.getArgument(0));

        SubmissionResponse result = assessmentService.gradeSubmission(50L, gradeReq);
        assertThat(result.getScore()).isEqualTo(85);  // Changed to int
        assertThat(result.getStatus()).isEqualTo("GRADED");
    }

    @Test
    @DisplayName("gradeSubmission – throws ResourceNotFoundException for missing submission")
    void gradeSubmission_notFound_throws() {
        when(submissionRepository.findById(999L)).thenReturn(Optional.empty());
        GradeRequest gradeReq = new GradeRequest();
        assertThatThrownBy(() -> assessmentService.gradeSubmission(999L, gradeReq))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getSubmissionsByStudent – returns list")
    void getSubmissionsByStudent_returnsList() {
        when(submissionRepository.findByStudentId(5L)).thenReturn(List.of(submission));
        List<Submission> result = assessmentService.getSubmissionsByStudent(5L);
        assertThat(result).hasSize(1);
        // In getSubmissionsByStudent_returnsList()
        assertThat(result.getFirst().getStudentId()).isEqualTo(5L);  // Changed to getFirst()
    }
}
