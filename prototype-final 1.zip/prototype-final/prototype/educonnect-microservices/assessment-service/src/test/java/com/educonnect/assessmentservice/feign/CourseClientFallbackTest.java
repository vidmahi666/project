package com.educonnect.assessmentservice.feign;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;

class CourseClientFallbackTest {

    private final CourseClientFallback fallback = new CourseClientFallback();

    @Test
    @DisplayName("getCourseById fallback returns null when course-service is down")
    void getCourseById_returnsNull() {
        var result = fallback.getCourseById(10L);
        assertThat(result).isNull();
    }
}
