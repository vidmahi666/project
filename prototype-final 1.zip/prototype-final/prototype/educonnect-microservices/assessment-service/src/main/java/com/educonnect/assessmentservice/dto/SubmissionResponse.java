package com.educonnect.assessmentservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SubmissionResponse {
    private Long submissionId;
    private Long assessmentId;
    private Long studentId;
    private String fileUri;
    private String comments;
    private Integer score;
    private String status;
    private LocalDateTime submittedAt;
    private LocalDateTime updatedAt;
}

