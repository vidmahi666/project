package com.educonnect.assessmentservice.config;

import com.educonnect.assessmentservice.entity.Assessment;
import com.educonnect.assessmentservice.repository.AssessmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final AssessmentRepository assessmentRepository;

    @Override
    public void run(String... args) {
        if (assessmentRepository.count() == 0) {
            assessmentRepository.save(Assessment.builder()
                    .courseId(1L).title("Java Basics Quiz").type(Assessment.AssessmentType.QUIZ)
                    .instructions("Answer all 20 questions within 30 minutes")
                    .dueDate(LocalDate.now().plusWeeks(2)).maxScore(100).passingScore(60)
                    .status(Assessment.AssessmentStatus.ACTIVE).build());
            assessmentRepository.save(Assessment.builder()
                    .courseId(1L).title("OOP Assignment").type(Assessment.AssessmentType.ASSIGNMENT)
                    .instructions("Build a simple inventory system using OOP principles")
                    .dueDate(LocalDate.now().plusWeeks(4)).maxScore(100).passingScore(70)
                    .status(Assessment.AssessmentStatus.DRAFT).build());
            log.info("Seeded 2 assessments");
        }
    }
}
