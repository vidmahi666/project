package com.educonnect.assessmentservice.feign;

import com.educonnect.assessmentservice.feign.dto.CourseResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
    name = "course-service",
    fallback = CourseClientFallback.class,
    configuration = FeignConfig.class
)
public interface CourseClient {
    @GetMapping("/courses/{courseId}")
    CourseResponse getCourseById(@PathVariable Long courseId);
}
