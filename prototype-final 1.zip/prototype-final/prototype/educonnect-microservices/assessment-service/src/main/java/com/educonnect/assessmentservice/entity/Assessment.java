package com.educonnect.assessmentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDate; import java.time.LocalDateTime;
@Entity @Table(name = "assessments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Assessment {
    public enum AssessmentType { ASSIGNMENT, EXAM, QUIZ, PROJECT }
    public enum AssessmentStatus { DRAFT, ACTIVE, CLOSED, ARCHIVED }
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long assessmentId;
    @Column(nullable = false) private Long courseId;
    @Column(nullable = false) private String title;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private AssessmentType type;
    private String fileUri;
    @Column(columnDefinition = "TEXT") private String instructions;
    private LocalDate dueDate;
    private Integer maxScore;
    private Integer passingScore;
    @Enumerated(EnumType.STRING) @Builder.Default private AssessmentStatus status = AssessmentStatus.DRAFT;
    @CreatedDate @Column(name = "created_at", nullable = false, updatable = false) private LocalDateTime createdAt;
    @LastModifiedDate @Column(name = "updated_at") private LocalDateTime updatedAt;
}
