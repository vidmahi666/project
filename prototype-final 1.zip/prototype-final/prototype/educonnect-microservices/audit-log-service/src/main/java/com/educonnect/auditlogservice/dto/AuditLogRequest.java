package com.educonnect.auditlogservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AuditLogRequest {
    @NotNull  private Long userId;
    private String userName;
    private String userEmail;
    @NotBlank private String action;
    private String resource;
}
