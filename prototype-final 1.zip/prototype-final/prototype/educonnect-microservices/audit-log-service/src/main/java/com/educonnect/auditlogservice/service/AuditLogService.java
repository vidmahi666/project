package com.educonnect.auditlogservice.service;

import com.educonnect.auditlogservice.dto.AuditLogRequest;
import com.educonnect.auditlogservice.dto.AuditLogResponse;
import com.educonnect.auditlogservice.entity.AuditLog;
import com.educonnect.auditlogservice.exception.ResourceNotFoundException;
import com.educonnect.auditlogservice.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j @Service @RequiredArgsConstructor
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    @Transactional
    public AuditLogResponse create(AuditLogRequest request) {
        log.info("Creating audit log: userId={}, action={}, resource={}", request.getUserId(), request.getAction(), request.getResource());
        AuditLog entry = AuditLog.builder()
                .userId(request.getUserId())
                .userName(request.getUserName())
                .userEmail(request.getUserEmail())
                .action(request.getAction())
                .resource(request.getResource())
                .build();
        return toResponse(auditLogRepository.save(entry));
    }

    @Transactional(readOnly = true)
    public List<AuditLogResponse> getAll() {
        return auditLogRepository.findAllByOrderByTimestampDesc().stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public AuditLogResponse getById(Long id) {
        return toResponse(auditLogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AuditLog", id)));
    }

    @Transactional(readOnly = true)
    public List<AuditLogResponse> getByUser(Long userId) {
        return auditLogRepository.findByUserIdOrderByTimestampDesc(userId).stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<AuditLogResponse> getByDateRange(LocalDateTime from, LocalDateTime to) {
        return auditLogRepository.findByTimestampBetweenOrderByTimestampDesc(from, to).stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<AuditLogResponse> searchByAction(String action) {
        return auditLogRepository.findByActionContainingIgnoreCaseOrderByTimestampDesc(action).stream().map(this::toResponse).toList();
    }

    /** Async background log – called internally from other services via OpenFeign */
    @Async
    @Transactional
    public void logAsync(Long userId, String userName, String action, String resource) {
        try {
            AuditLog entry = AuditLog.builder().userId(userId).userName(userName).action(action).resource(resource).build();
            auditLogRepository.save(entry);
            log.debug("Async audit logged: userId={}, action={}", userId, action);
        } catch (Exception e) {
            log.error("Failed to save async audit log for userId={}: {}", userId, e.getMessage());
        }
    }

    private AuditLogResponse toResponse(AuditLog a) {
        return AuditLogResponse.builder()
                .auditLogId(a.getAuditLogId()).userId(a.getUserId())
                .userName(a.getUserName() != null ? a.getUserName() : "SYSTEM")
                .userEmail(a.getUserEmail()).action(a.getAction())
                .resource(a.getResource()).timestamp(a.getTimestamp()).build();
    }
}
