package com.educonnect.auditlogservice.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @AllArgsConstructor @NoArgsConstructor
public class AuditLogResponse {
    private Long auditLogId;
    private Long userId;
    private String userName;
    private String userEmail;
    private String action;
    private String resource;
    private LocalDateTime timestamp;
}
