package com.educonnect.auditlogservice.config;

import com.educonnect.auditlogservice.entity.AuditLog;
import com.educonnect.auditlogservice.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final AuditLogRepository auditLogRepository;

    @Override
    public void run(String... args) {
        if (auditLogRepository.count() == 0) {
            auditLogRepository.save(AuditLog.builder()
                    .userId(1L).userName("Admin User").userEmail("admin@educonnect.com")
                    .action("SYSTEM_STARTUP").resource("EduConnect Platform").build());
            auditLogRepository.save(AuditLog.builder()
                    .userId(2L).userName("Teacher One").userEmail("teacher@educonnect.com")
                    .action("COURSE_CREATED").resource("Introduction to Java").build());
            log.info("Seeded 2 audit logs");
        }
    }
}
