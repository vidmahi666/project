package com.educonnect.auditlogservice.feign;

import com.educonnect.auditlogservice.feign.dto.UserResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UserClientFallback implements UserClient {
    @Override
    public UserResponse getUserById(Long userId) {
        log.warn("user-service unavailable – returning null for userId={}", userId);
        return null;
    }
}
