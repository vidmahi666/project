package com.educonnect.auditlogservice.feign.dto;
import lombok.Data;
@Data public class UserResponse { private Long userId; private String name; private String email; private String role; }
