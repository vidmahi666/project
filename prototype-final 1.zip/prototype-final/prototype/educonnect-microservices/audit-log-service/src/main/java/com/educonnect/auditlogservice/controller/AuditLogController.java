package com.educonnect.auditlogservice.controller;

import com.educonnect.auditlogservice.dto.ApiResponse;
import com.educonnect.auditlogservice.dto.AuditLogRequest;
import com.educonnect.auditlogservice.dto.AuditLogResponse;
import com.educonnect.auditlogservice.service.AuditLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/audit-logs")
@RequiredArgsConstructor
@Tag(name = "Audit Logs", description = "User action audit trail management")
public class AuditLogController {

    private final AuditLogService auditLogService;

    @PostMapping
    @Operation(summary = "Create an audit log entry")
    public ResponseEntity<ApiResponse<AuditLogResponse>> create(@Valid @RequestBody AuditLogRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Audit log created", auditLogService.create(request)));
    }

    @GetMapping
    @Operation(summary = "Get all audit logs (newest first)")
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.ok("All audit logs", auditLogService.getAll()));
    }

    @GetMapping("/{auditLogId}")
    @Operation(summary = "Get audit log by ID")
    public ResponseEntity<ApiResponse<AuditLogResponse>> getById(@PathVariable Long auditLogId) {
        return ResponseEntity.ok(ApiResponse.ok("Audit log", auditLogService.getById(auditLogId)));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get audit logs by user ID")
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("User audit logs", auditLogService.getByUser(userId)));
    }

    @GetMapping("/date-range")
    @Operation(summary = "Get audit logs within a date-time range")
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        return ResponseEntity.ok(ApiResponse.ok("Audit logs in range", auditLogService.getByDateRange(from, to)));
    }

    @GetMapping("/search")
    @Operation(summary = "Search audit logs by action keyword")
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> searchByAction(@RequestParam String action) {
        return ResponseEntity.ok(ApiResponse.ok("Search results", auditLogService.searchByAction(action)));
    }

    /** Internal endpoint – called by other microservices via OpenFeign */
    @PostMapping("/internal/async")
    @Operation(summary = "[INTERNAL] Async audit log from other services")
    public ResponseEntity<Void> logAsync(@RequestParam Long userId,
                                         @RequestParam(required = false) String userName,
                                         @RequestParam String action,
                                         @RequestParam(required = false) String resource) {
        auditLogService.logAsync(userId, userName, action, resource);
        return ResponseEntity.accepted().build();
    }
}
