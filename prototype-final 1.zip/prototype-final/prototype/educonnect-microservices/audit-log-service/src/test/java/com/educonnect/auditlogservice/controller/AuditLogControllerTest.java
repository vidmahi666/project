package com.educonnect.auditlogservice.controller;

import com.educonnect.auditlogservice.dto.*;
import com.educonnect.auditlogservice.exception.ResourceNotFoundException;
import com.educonnect.auditlogservice.service.AuditLogService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuditLogController.class)
class AuditLogControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean AuditLogService auditLogService;

    private AuditLogResponse buildResponse() {
        return AuditLogResponse.builder()
                .auditLogId(1L).userId(10L).userName("Alice")
                .action("LOGIN").resource("/auth/login")
                .timestamp(LocalDateTime.now()).build();
    }

    @Test
    @DisplayName("POST /audit-logs – 201 on success")
    void create_returns201() throws Exception {
        AuditLogRequest req = new AuditLogRequest();
        req.setUserId(10L); req.setAction("LOGIN");

        when(auditLogService.create(any())).thenReturn(buildResponse());

        mockMvc.perform(post("/audit-logs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.action").value("LOGIN"));
    }

    @Test
    @DisplayName("GET /audit-logs – 200 with list")
    void getAll_returns200() throws Exception {
        when(auditLogService.getAll()).thenReturn(List.of(buildResponse()));
        mockMvc.perform(get("/audit-logs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /audit-logs/{id} – 404 when not found")
    void getById_notFound_returns404() throws Exception {
        when(auditLogService.getById(99L)).thenThrow(new ResourceNotFoundException("AuditLog", 99L));
        mockMvc.perform(get("/audit-logs/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("GET /audit-logs/date-range – 400 when 'from' param is missing")
    void getByDateRange_missingFrom_returns400() throws Exception {
        mockMvc.perform(get("/audit-logs/date-range")
                        .param("to", "2025-12-31T23:59:59"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("from")));
    }

    @Test
    @DisplayName("GET /audit-logs/date-range – 400 when 'to' param is missing")
    void getByDateRange_missingTo_returns400() throws Exception {
        mockMvc.perform(get("/audit-logs/date-range")
                        .param("from", "2025-01-01T00:00:00"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("to")));
    }

    @Test
    @DisplayName("GET /audit-logs/search – 400 when action param is missing")
    void search_missingAction_returns400() throws Exception {
        mockMvc.perform(get("/audit-logs/search"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("action")));
    }

    @Test
    @DisplayName("GET /audit-logs/search – 200 when action provided")
    void search_returns200() throws Exception {
        when(auditLogService.searchByAction("LOGIN")).thenReturn(List.of(buildResponse()));
        mockMvc.perform(get("/audit-logs/search").param("action", "LOGIN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("POST /audit-logs/internal/async – 400 when userId missing")
    void logAsync_missingUserId_returns400() throws Exception {
        mockMvc.perform(post("/audit-logs/internal/async")
                        .param("action", "LOGIN"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("userId")));
    }
}
