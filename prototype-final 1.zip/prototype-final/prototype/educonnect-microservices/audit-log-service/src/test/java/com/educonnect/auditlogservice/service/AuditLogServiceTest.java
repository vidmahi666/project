package com.educonnect.auditlogservice.service;

import com.educonnect.auditlogservice.dto.AuditLogRequest;
import com.educonnect.auditlogservice.dto.AuditLogResponse;
import com.educonnect.auditlogservice.entity.AuditLog;
import com.educonnect.auditlogservice.exception.ResourceNotFoundException;
import com.educonnect.auditlogservice.repository.AuditLogRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuditLogServiceTest {

    @Mock private AuditLogRepository auditLogRepository;
    @InjectMocks private AuditLogService auditLogService;

    private AuditLog log1;

    @BeforeEach
    void setUp() {
        log1 = AuditLog.builder()
                .auditLogId(1L).userId(10L).userName("Alice")
                .action("LOGIN").resource("/auth/login")
                .timestamp(LocalDateTime.now()).build();
    }

    @Test
    @DisplayName("create – saves and returns response")
    void create_success() {
        AuditLogRequest req = new AuditLogRequest();
        req.setUserId(10L); req.setUserName("Alice");
        req.setAction("LOGIN"); req.setResource("/auth/login");

        when(auditLogRepository.save(any(AuditLog.class))).thenReturn(log1);
        AuditLogResponse resp = auditLogService.create(req);

        assertThat(resp.getAction()).isEqualTo("LOGIN");
        assertThat(resp.getUserId()).isEqualTo(10L);
        verify(auditLogRepository).save(any(AuditLog.class));
    }

    @Test
    @DisplayName("getAll – returns list from repository")
    void getAll_returnsList() {
        when(auditLogRepository.findAllByOrderByTimestampDesc()).thenReturn(List.of(log1));
        List<AuditLogResponse> result = auditLogService.getAll();
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getById – returns response for valid id")
    void getById_found() {
        when(auditLogRepository.findById(1L)).thenReturn(Optional.of(log1));
        AuditLogResponse resp = auditLogService.getById(1L);
        assertThat(resp.getAuditLogId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getById – throws ResourceNotFoundException for unknown id")
    void getById_notFound_throws() {
        when(auditLogRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> auditLogService.getById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getByUser – returns logs for userId")
    void getByUser_returnsList() {
        when(auditLogRepository.findByUserIdOrderByTimestampDesc(10L)).thenReturn(List.of(log1));
        List<AuditLogResponse> result = auditLogService.getByUser(10L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getUserId()).isEqualTo(10L);
    }

    @Test
    @DisplayName("searchByAction – returns matching logs")
    void searchByAction_returnsMatching() {
        when(auditLogRepository.findByActionContainingIgnoreCaseOrderByTimestampDesc("LOGIN"))
                .thenReturn(List.of(log1));
        List<AuditLogResponse> result = auditLogService.searchByAction("LOGIN");
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getByDateRange – returns logs within range")
    void getByDateRange_returnsInRange() {
        LocalDateTime from = LocalDateTime.now().minusDays(1);
        LocalDateTime to = LocalDateTime.now().plusDays(1);
        when(auditLogRepository.findByTimestampBetweenOrderByTimestampDesc(from, to))
                .thenReturn(List.of(log1));
        List<AuditLogResponse> result = auditLogService.getByDateRange(from, to);
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("logAsync – saves audit log without throwing")
    void logAsync_savesSuccessfully() {
        when(auditLogRepository.save(any(AuditLog.class))).thenReturn(log1);
        assertThatNoException().isThrownBy(
                () -> auditLogService.logAsync(10L, "Alice", "LOGIN", "/auth/login"));
    }
}
