package com.educonnect.reportservice.controller;

import com.educonnect.reportservice.entity.Report;
import com.educonnect.reportservice.exception.ResourceNotFoundException;
import com.educonnect.reportservice.service.ReportService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReportController.class)
class ReportControllerTest {

    @Autowired MockMvc mockMvc;
    @MockBean ReportService reportService;

    @Test
    @DisplayName("GET /reports/dashboard – 200 with metrics")
    void getDashboard_returns200() throws Exception {
        when(reportService.getDashboardMetrics())
                .thenReturn(Map.of("totalStudents", 10, "totalCourses", 5));

        mockMvc.perform(get("/reports/dashboard"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.totalStudents").value(10));
    }

    @Test
    @DisplayName("POST /reports/generate – 400 when scope param missing")
    void generate_missingScope_returns400() throws Exception {
        mockMvc.perform(post("/reports/generate"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(containsString("scope")));
    }

    @Test
    @DisplayName("POST /reports/generate – 200 with scope provided")
    void generate_returns200() throws Exception {
        when(reportService.generateReport("DASHBOARD", "system"))
                .thenReturn(Map.of("scope", "DASHBOARD"));

        mockMvc.perform(post("/reports/generate").param("scope", "DASHBOARD"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.scope").value("DASHBOARD"));
    }

    @Test
    @DisplayName("GET /reports – 200 with list")
    void getAllReports_returns200() throws Exception {
        Report r = Report.builder().reportId(1L).scope(Report.ReportScope.DASHBOARD).build();
        when(reportService.getAllReports()).thenReturn(List.of(r));

        mockMvc.perform(get("/reports"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /reports/{id} – 404 when not found")
    void getById_notFound_returns404() throws Exception {
        when(reportService.getById(99L)).thenThrow(new ResourceNotFoundException("Report", 99L));

        mockMvc.perform(get("/reports/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("GET /reports/scope/{scope} – 200 with filtered list")
    void getByScope_returns200() throws Exception {
        when(reportService.getByScope("DASHBOARD")).thenReturn(List.of());
        mockMvc.perform(get("/reports/scope/DASHBOARD"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }
}
