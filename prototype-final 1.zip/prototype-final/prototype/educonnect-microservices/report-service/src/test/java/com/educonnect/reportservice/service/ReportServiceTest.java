package com.educonnect.reportservice.service;

import com.educonnect.reportservice.entity.Report;
import com.educonnect.reportservice.exception.ResourceNotFoundException;
import com.educonnect.reportservice.feign.CourseServiceClient;
import com.educonnect.reportservice.feign.StudentServiceClient;
import com.educonnect.reportservice.repository.ReportRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReportServiceTest {

    @Mock private ReportRepository reportRepository;
    @Mock private StudentServiceClient studentServiceClient;
    @Mock private CourseServiceClient courseServiceClient;

    @Spy @InjectMocks private ReportService reportService;

    private Report savedReport;

    @BeforeEach
    void setUp() {
        savedReport = Report.builder()
                .reportId(1L)
                .scope(Report.ReportScope.DASHBOARD)
                .metrics("{totalStudents=10, totalCourses=5}")
                .generatedBy("system")
                .build();
    }

    @Test
    @DisplayName("generateReport STUDENT scope – fetches student count")
    void generateReport_studentScope() {
        when(studentServiceClient.getAllStudents()).thenReturn(List.of(Map.of(), Map.of()));
        when(reportRepository.save(any(Report.class))).thenReturn(savedReport);

        Map<String, Object> result = reportService.generateReport("STUDENT", "admin");

        assertThat(result).containsKey("totalStudents");
        assertThat(result.get("totalStudents")).isEqualTo(2);
    }

    @Test
    @DisplayName("generateReport COURSE scope – fetches course count")
    void generateReport_courseScope() {
        when(courseServiceClient.getAllCourses()).thenReturn(List.of(Map.of()));
        when(reportRepository.save(any(Report.class))).thenReturn(savedReport);

        Map<String, Object> result = reportService.generateReport("COURSE", "admin");

        assertThat(result).containsKey("totalCourses");
        assertThat(result.get("totalCourses")).isEqualTo(1);
    }

    @Test
    @DisplayName("generateReport DASHBOARD scope – fetches both counts")
    void generateReport_dashboardScope() {
        when(studentServiceClient.getAllStudents()).thenReturn(List.of(Map.of(), Map.of(), Map.of()));
        when(courseServiceClient.getAllCourses()).thenReturn(List.of(Map.of(), Map.of()));
        when(reportRepository.save(any(Report.class))).thenReturn(savedReport);

        Map<String, Object> result = reportService.generateReport("DASHBOARD", "system");

        assertThat(result).containsKeys("totalStudents", "totalCourses");
        assertThat(result.get("totalStudents")).isEqualTo(3);
        assertThat(result.get("totalCourses")).isEqualTo(2);
    }

    @Test
    @DisplayName("generateReport – falls back when student-service is down")
    void generateReport_studentServiceDown_fallback() {
        when(reportService.fetchStudentCount()).thenReturn(-1);  // Mock the method to return -1 (fallback value)
        when(reportRepository.save(any(Report.class))).thenReturn(savedReport);

        Map<String, Object> result = reportService.generateReport("STUDENT", "system");

        assertThat(result.get("totalStudents")).isEqualTo("service-unavailable");
    }

    @Test
    @DisplayName("getDashboardMetrics – returns metrics map and saves report")
    void getDashboardMetrics_success() {
        when(studentServiceClient.getAllStudents()).thenReturn(List.of(Map.of()));
        when(courseServiceClient.getAllCourses()).thenReturn(List.of(Map.of()));
        when(reportRepository.save(any(Report.class))).thenReturn(savedReport);

        Map<String, Object> result = reportService.getDashboardMetrics();

        assertThat(result).containsKeys("totalStudents", "totalCourses", "generatedAt");
        verify(reportRepository).save(any(Report.class));
    }

    @Test
    @DisplayName("getAllReports – returns all reports")
    void getAllReports_returnsList() {
        when(reportRepository.findAll()).thenReturn(List.of(savedReport));
        List<Report> result = reportService.getAllReports();
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getById – returns report when found")
    void getById_found() {
        when(reportRepository.findById(1L)).thenReturn(Optional.of(savedReport));
        Report result = reportService.getById(1L);
        assertThat(result.getReportId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getById – throws ResourceNotFoundException when not found")
    void getById_notFound_throws() {
        when(reportRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> reportService.getById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getByScope – returns reports filtered by scope")
    void getByScope_returnsFiltered() {
        when(reportRepository.findByScope(Report.ReportScope.DASHBOARD)).thenReturn(List.of(savedReport));
        List<Report> result = reportService.getByScope("DASHBOARD");
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getScope()).isEqualTo(Report.ReportScope.DASHBOARD);
    }

    @Test
    @DisplayName("getByScope – throws IllegalArgumentException for invalid scope")
    void getByScope_invalidScope_throws() {
        assertThatThrownBy(() -> reportService.getByScope("INVALID_SCOPE"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("studentCountFallback – returns -1 on exception")
    void studentCountFallback_returnsMinusOne() {
        int result = reportService.studentCountFallback(new RuntimeException("timeout"));
        assertThat(result).isEqualTo(-1);
    }

    @Test
    @DisplayName("courseCountFallback – returns -1 on exception")
    void courseCountFallback_returnsMinusOne() {
        int result = reportService.courseCountFallback(new RuntimeException("timeout"));
        assertThat(result).isEqualTo(-1);
    }
}
