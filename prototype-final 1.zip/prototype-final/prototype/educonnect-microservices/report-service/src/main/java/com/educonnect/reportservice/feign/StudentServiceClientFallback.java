package com.educonnect.reportservice.feign;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.util.Collections;
import java.util.List;
import java.util.Map;
@Slf4j @Component
public class StudentServiceClientFallback implements StudentServiceClient {
    @Override public List<Map<String,Object>> getAllStudents() {
        log.warn("student-service unavailable for report"); return Collections.emptyList();
    }
}
