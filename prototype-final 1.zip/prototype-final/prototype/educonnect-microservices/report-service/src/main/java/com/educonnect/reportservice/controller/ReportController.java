package com.educonnect.reportservice.controller;

import com.educonnect.reportservice.dto.ApiResponse;
import com.educonnect.reportservice.entity.Report;
import com.educonnect.reportservice.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController @RequestMapping("/reports") @RequiredArgsConstructor
@Tag(name = "Reports", description = "Platform-wide reporting and dashboard metrics")
public class ReportController {
    private final ReportService reportService;

    @GetMapping("/dashboard") @Operation(summary = "Get live dashboard metrics across all services")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.ok("Dashboard metrics", reportService.getDashboardMetrics()));
    }

    @PostMapping("/generate") @Operation(summary = "Generate a scoped report (COURSE, STUDENT, ASSESSMENT, COMPLIANCE, PROGRAM, DASHBOARD)")
    public ResponseEntity<ApiResponse<Map<String, Object>>> generate(
            @RequestParam String scope,
            @RequestParam(required = false, defaultValue = "system") String generatedBy) {
        return ResponseEntity.ok(ApiResponse.ok("Report generated", reportService.generateReport(scope, generatedBy)));
    }

    @GetMapping @Operation(summary = "Get all saved reports")
    public ResponseEntity<ApiResponse<List<Report>>> getAllReports() {
        return ResponseEntity.ok(ApiResponse.ok("Reports", reportService.getAllReports()));
    }

    @GetMapping("/{reportId}") @Operation(summary = "Get report by ID")
    public ResponseEntity<ApiResponse<Report>> getById(@PathVariable Long reportId) {
        return ResponseEntity.ok(ApiResponse.ok("Report", reportService.getById(reportId)));
    }

    @GetMapping("/scope/{scope}") @Operation(summary = "Get reports by scope")
    public ResponseEntity<ApiResponse<List<Report>>> getByScope(@PathVariable String scope) {
        return ResponseEntity.ok(ApiResponse.ok("Reports by scope", reportService.getByScope(scope)));
    }
}
