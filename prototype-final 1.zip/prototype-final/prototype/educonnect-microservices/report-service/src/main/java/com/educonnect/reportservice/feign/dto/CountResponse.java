package com.educonnect.reportservice.feign.dto;
import lombok.Data;
@Data public class CountResponse { private Long count; }
