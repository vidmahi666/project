package com.educonnect.authservice.feign;

import com.educonnect.authservice.feign.dto.StudentCreateRequest;
import com.educonnect.authservice.feign.dto.StudentResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j @Component
public class StudentClientFallback implements StudentClient {
    @Override
    public StudentResponse createStudentProfile(StudentCreateRequest request) {
        log.warn("student-service unavailable – student profile for userId={} will not be auto-created.", request.getUserId());
        return null;
    }
}
