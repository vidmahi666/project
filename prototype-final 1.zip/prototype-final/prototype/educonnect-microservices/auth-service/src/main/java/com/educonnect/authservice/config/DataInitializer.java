package com.educonnect.authservice.config;

import com.educonnect.authservice.entity.User;
import com.educonnect.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        seedUser("Admin User",       "admin@educonnect.com",      "Admin@123",      User.Role.ADMIN);
        seedUser("Teacher One",      "teacher@educonnect.com",    "Teacher@123",    User.Role.TEACHER);
        seedUser("Student One",      "student@educonnect.com",    "Student@123",    User.Role.STUDENT);
        seedUser("Program Manager",  "pm@educonnect.com",         "Pm@1234",        User.Role.PROGRAM_MANAGER);
        seedUser("Compliance Officer","compliance@educonnect.com","Compliance@123", User.Role.COMPLIANCE_OFFICER);
        seedUser("Gov Auditor",      "auditor@educonnect.com",    "Auditor@123",    User.Role.GOVERNMENT_AUDITOR);
        log.info("DataInitializer: seed complete");
    }

    private void seedUser(String name, String email, String password, User.Role role) {
        if (!userRepository.existsByEmail(email)) {
            userRepository.save(User.builder()
                    .name(name).email(email)
                    .password(passwordEncoder.encode(password))
                    .role(role).status(User.Status.ACTIVE).build());
            log.info("Seeded user: {} [{}]", email, role);
        }
    }
}
