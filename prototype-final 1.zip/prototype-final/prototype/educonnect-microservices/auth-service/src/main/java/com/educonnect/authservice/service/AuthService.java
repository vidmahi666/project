package com.educonnect.authservice.service;

import com.educonnect.authservice.dto.*;
import com.educonnect.authservice.entity.User;
import com.educonnect.authservice.exception.ResourceNotFoundException;
import com.educonnect.authservice.exception.EmailAlreadyExistsException;
import com.educonnect.authservice.feign.StudentClient;
import com.educonnect.authservice.feign.dto.StudentCreateRequest;
import com.educonnect.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Slf4j @Service @RequiredArgsConstructor
public class AuthService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final StudentClient studentClient;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail()))
            throw new EmailAlreadyExistsException(request.getEmail());

        User user = User.builder()
                .name(request.getName()).email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone()).role(User.Role.STUDENT)
                .status(User.Status.ACTIVE).build();
        User savedUser = userRepository.save(user);

        // Auto-create student profile in student-service via OpenFeign
        try {
            StudentCreateRequest studentReq = StudentCreateRequest.builder()
                    .userId(savedUser.getUserId()).name(savedUser.getName())
                    .contactInfo(savedUser.getPhone()).build();
            var studentResp = studentClient.createStudentProfile(studentReq);
            if (studentResp != null)
                log.info("Auto-created student profile (studentId={}) for userId={}",
                        studentResp.getStudentId(), savedUser.getUserId());
        } catch (Exception e) {
            log.warn("Could not auto-create student profile for userId={}: {}", savedUser.getUserId(), e.getMessage());
        }
        return mapToResponse(savedUser);
    }

    @Transactional
    public User createTeacher(CreateUserRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(buildUser(req, User.Role.TEACHER));
    }

    @Transactional
    public User createProgramManager(CreateUserRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(buildUser(req, User.Role.PROGRAM_MANAGER));
    }

    @Transactional
    public User createComplianceOfficer(CreateUserRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(buildUser(req, User.Role.COMPLIANCE_OFFICER));
    }

    @Transactional
    public User createGovernmentAuditor(CreateUserRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(buildUser(req, User.Role.GOVERNMENT_AUDITOR));
    }

    public List<User> getAllTeachers() { return userRepository.findByRoleIn(List.of(User.Role.TEACHER)); }
    public List<User> getAllUsers() { return userRepository.findAll(); }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", id));
    }

    @Transactional
    public User deactivateUser(Long id) {
        User user = getUserById(id); user.setStatus(User.Status.INACTIVE); return userRepository.save(user);
    }

    @Transactional
    public User activateUser(Long id) {
        User user = getUserById(id); user.setStatus(User.Status.ACTIVE); return userRepository.save(user);
    }

    private User buildUser(CreateUserRequest req, User.Role role) {
        return User.builder().name(req.getName()).email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .phone(req.getPhone()).role(role).status(User.Status.ACTIVE).build();
    }

    private void validateUniqueEmail(String email) {
        if (userRepository.existsByEmail(email)) throw new EmailAlreadyExistsException(email);
    }

    private AuthResponse mapToResponse(User user) {
        return AuthResponse.builder().userId(user.getUserId()).name(user.getName())
                .email(user.getEmail()).role(user.getRole()).build();
    }
}
