package com.educonnect.authservice.config;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JCircuitBreakerFactory;
import org.springframework.cloud.client.circuitbreaker.Customizer;

import static org.assertj.core.api.Assertions.*;

class ResilienceConfigTest {

    private final ResilienceConfig config = new ResilienceConfig();

    @Test
    @DisplayName("defaultCustomizer bean is created")
    void defaultCustomizer_isNotNull() {
        Customizer<Resilience4JCircuitBreakerFactory> customizer = config.defaultCustomizer();
        assertThat(customizer).isNotNull();
    }
}
