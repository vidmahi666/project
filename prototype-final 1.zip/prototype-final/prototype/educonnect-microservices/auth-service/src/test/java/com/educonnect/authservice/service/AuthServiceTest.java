package com.educonnect.authservice.service;

import com.educonnect.authservice.dto.*;
import com.educonnect.authservice.entity.User;
import com.educonnect.authservice.exception.EmailAlreadyExistsException;
import com.educonnect.authservice.exception.ResourceNotFoundException;
import com.educonnect.authservice.feign.StudentClient;
import com.educonnect.authservice.feign.dto.StudentCreateRequest;
import com.educonnect.authservice.feign.dto.StudentResponse;
import com.educonnect.authservice.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock private UserRepository userRepository;
    @Mock private PasswordEncoder passwordEncoder;
    @Mock private StudentClient studentClient;

    @InjectMocks private AuthService authService;

    private RegisterRequest registerRequest;
    private User savedUser;

    @BeforeEach
    void setUp() {
        registerRequest = new RegisterRequest();
        registerRequest.setName("Alice");
        registerRequest.setEmail("alice@test.com");
        registerRequest.setPassword("secret");
        registerRequest.setPhone("9876543210");

        savedUser = User.builder()
                .userId(1L).name("Alice").email("alice@test.com")
                .password("encoded").phone("9876543210")
                .role(User.Role.STUDENT).status(User.Status.ACTIVE).build();
    }

    @Test
    @DisplayName("register – success: saves user and creates student profile")
    void register_success() {
        when(userRepository.existsByEmail(anyString())).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("encoded");
        when(userRepository.save(any(User.class))).thenReturn(savedUser);

        StudentResponse sr = new StudentResponse();
        sr.setStudentId(10L);
        when(studentClient.createStudentProfile(any(StudentCreateRequest.class))).thenReturn(sr);

        AuthResponse response = authService.register(registerRequest);

        assertThat(response).isNotNull();
        assertThat(response.getEmail()).isEqualTo("alice@test.com");
        assertThat(response.getRole()).isEqualTo(User.Role.STUDENT);
        verify(userRepository).save(any(User.class));
        verify(studentClient).createStudentProfile(any(StudentCreateRequest.class));
    }

    @Test
    @DisplayName("register – fails with EmailAlreadyExistsException when email exists")
    void register_duplicateEmail_throws() {
        when(userRepository.existsByEmail("alice@test.com")).thenReturn(true);
        assertThatThrownBy(() -> authService.register(registerRequest))
                .isInstanceOf(EmailAlreadyExistsException.class);
        verify(userRepository, never()).save(any());
    }

    @Test
    @DisplayName("register – succeeds even if student-service feign call fails (circuit breaker fallback)")
    void register_studentServiceDown_stillRegisters() {
        when(userRepository.existsByEmail(anyString())).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("encoded");
        when(userRepository.save(any(User.class))).thenReturn(savedUser);
        when(studentClient.createStudentProfile(any())).thenThrow(new RuntimeException("service unavailable"));

        AuthResponse response = authService.register(registerRequest);

        assertThat(response).isNotNull();
        assertThat(response.getEmail()).isEqualTo("alice@test.com");
    }

    @Test
    @DisplayName("getUserById – returns user when found")
    void getUserById_found() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(savedUser));
        User result = authService.getUserById(1L);
        assertThat(result.getUserId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getUserById – throws ResourceNotFoundException when not found")
    void getUserById_notFound_throws() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> authService.getUserById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("deactivateUser – sets status to INACTIVE")
    void deactivateUser_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(savedUser));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));
        User result = authService.deactivateUser(1L);
        assertThat(result.getStatus()).isEqualTo(User.Status.INACTIVE);
    }

    @Test
    @DisplayName("activateUser – sets status to ACTIVE")
    void activateUser_success() {
        savedUser.setStatus(User.Status.INACTIVE);
        when(userRepository.findById(1L)).thenReturn(Optional.of(savedUser));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));
        User result = authService.activateUser(1L);
        assertThat(result.getStatus()).isEqualTo(User.Status.ACTIVE);
    }

    @Test
    @DisplayName("createTeacher – validates unique email")
    void createTeacher_duplicateEmail_throws() {
        CreateUserRequest req = new CreateUserRequest();
        req.setEmail("teacher@test.com");
        when(userRepository.existsByEmail("teacher@test.com")).thenReturn(true);
        assertThatThrownBy(() -> authService.createTeacher(req))
                .isInstanceOf(EmailAlreadyExistsException.class);
    }

    @Test
    @DisplayName("getAllTeachers – delegates to repository")
    void getAllTeachers_delegatesToRepo() {
        User teacher = User.builder().role(User.Role.TEACHER).build();
        when(userRepository.findByRoleIn(List.of(User.Role.TEACHER))).thenReturn(List.of(teacher));
        List<User> teachers = authService.getAllTeachers();
        assertThat(teachers).hasSize(1);
    }
}
