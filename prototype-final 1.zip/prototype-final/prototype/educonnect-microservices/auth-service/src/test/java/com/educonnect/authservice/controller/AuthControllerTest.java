package com.educonnect.authservice.controller;

import com.educonnect.authservice.dto.*;
import com.educonnect.authservice.entity.User;
import com.educonnect.authservice.exception.EmailAlreadyExistsException;
import com.educonnect.authservice.service.AuthService;
import com.educonnect.authservice.service.JWTService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
class AuthControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;

    @MockBean AuthService authService;
    @MockBean JWTService jwtService;
    @MockBean AuthenticationManager authenticationManager;
    @MockBean com.educonnect.authservice.repository.UserRepository userRepository;

    @Test
    @DisplayName("POST /auth/register – 201 on success")
    void register_returns201() throws Exception {
        RegisterRequest req = new RegisterRequest();
        req.setName("Alice"); req.setEmail("alice@test.com");
        req.setPassword("secret123"); req.setPhone("9876543210");

        AuthResponse resp = AuthResponse.builder()
                .userId(1L).name("Alice").email("alice@test.com")
                .role(User.Role.STUDENT).build();
        when(authService.register(any())).thenReturn(resp);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.email").value("alice@test.com"));
    }

    @Test
    @DisplayName("POST /auth/register – 409 when email already exists")
    void register_duplicateEmail_returns409() throws Exception {
        RegisterRequest req = new RegisterRequest();
        req.setName("Alice"); req.setEmail("alice@test.com");
        req.setPassword("secret123"); req.setPhone("9876543210");

        when(authService.register(any())).thenThrow(new EmailAlreadyExistsException("Email already exists"));

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isConflict());
    }

    @Test
    @DisplayName("POST /auth/login – 401 on bad credentials")
    void login_badCredentials_returns401() throws Exception {
        LoginRequest req = new LoginRequest();
        req.setEmail("wrong@test.com"); req.setPassword("wrongpass");

        when(authenticationManager.authenticate(any()))
                .thenThrow(new BadCredentialsException("Bad credentials"));

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("GET /admin/users – 200 with list")
    void getAllUsers_returns200() throws Exception {
        User user = User.builder().userId(1L).name("Alice").email("alice@test.com")
                .role(User.Role.STUDENT).status(User.Status.ACTIVE).build();
        when(authService.getAllUsers()).thenReturn(List.of(user));

        mockMvc.perform(get("/admin/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /admin/users/{id} – 404 when user not found")
    void getUserById_notFound_returns404() throws Exception {
        when(authService.getUserById(99L))
                .thenThrow(new com.educonnect.authservice.exception.ResourceNotFoundException("User", 99L));

        mockMvc.perform(get("/admin/users/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("PATCH /admin/users/{id}/deactivate – 200")
    void deactivateUser_returns200() throws Exception {
        User user = User.builder().userId(1L).status(User.Status.INACTIVE).build();
        when(authService.deactivateUser(1L)).thenReturn(user);

        mockMvc.perform(patch("/admin/users/1/deactivate"))
                .andExpect(status().isOk());
    }
}
