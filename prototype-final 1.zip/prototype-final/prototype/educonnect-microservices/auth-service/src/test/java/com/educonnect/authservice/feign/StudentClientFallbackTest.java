package com.educonnect.authservice.feign;

import com.educonnect.authservice.feign.dto.StudentCreateRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;

class StudentClientFallbackTest {

    private final StudentClientFallback fallback = new StudentClientFallback();

    @Test
    @DisplayName("createStudentProfile fallback returns null when student-service is down")
    void createStudentProfile_returnsNull() {
        StudentCreateRequest req = StudentCreateRequest.builder()
                .userId(1L).name("Alice").build();
        var result = fallback.createStudentProfile(req);
        assertThat(result).isNull();
    }
}
