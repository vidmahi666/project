package com.educonnect.progressservice.feign;

import com.educonnect.progressservice.feign.dto.CourseResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CourseClientFallback implements CourseClient {
    @Override
    public CourseResponse getCourseById(Long courseId) {
        log.warn("course-service unavailable – returning null for courseId={}", courseId);
        return null;
    }
}
