package com.educonnect.progressservice.feign.dto;
import lombok.Data;
@Data public class StudentResponse { private Long studentId; private String name; private Long userId; }
