package com.educonnect.progressservice.dto;
import com.educonnect.progressservice.entity.Progress;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @AllArgsConstructor @NoArgsConstructor
public class ProgressResponse {
    private Long progressId;
    private Long studentId; private String studentName;
    private Long courseId;  private String courseTitle;
    private Double completionPercentage;
    private String metricsJson;
    private Progress.ProgressStatus status;
    private LocalDateTime updatedAt;
}
