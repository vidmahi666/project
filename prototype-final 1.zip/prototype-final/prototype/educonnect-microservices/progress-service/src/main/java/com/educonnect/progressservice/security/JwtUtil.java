package com.educonnect.progressservice.security;
import io.jsonwebtoken.Claims; import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders; import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Component;
import javax.crypto.SecretKey;
@Component
public class JwtUtil {
    @Value("${jwt.secret}") private String secret;
    public Claims extractAllClaims(String t) { return Jwts.parser().verifyWith(getKey()).build().parseSignedClaims(t).getPayload(); }
    private SecretKey getKey() { return Keys.hmacShaKeyFor(Decoders.BASE64URL.decode(secret)); }
    public boolean validateToken(String t) { try { return !extractAllClaims(t).getExpiration().before(new java.util.Date()); } catch (Exception e) { return false; } }
    public String extractUsername(String t) { return extractAllClaims(t).getSubject(); }
}
