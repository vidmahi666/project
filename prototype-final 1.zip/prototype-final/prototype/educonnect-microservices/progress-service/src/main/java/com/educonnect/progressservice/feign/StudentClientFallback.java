package com.educonnect.progressservice.feign;

import com.educonnect.progressservice.feign.dto.StudentResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class StudentClientFallback implements StudentClient {
    @Override
    public StudentResponse getStudentById(Long studentId) {
        log.warn("student-service unavailable – returning null for studentId={}", studentId);
        return null;
    }
}
