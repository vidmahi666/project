package com.educonnect.progressservice.service;

import com.educonnect.progressservice.dto.ProgressResponse;
import com.educonnect.progressservice.dto.ProgressUpdateRequest;
import com.educonnect.progressservice.entity.Progress;
import com.educonnect.progressservice.exception.ResourceNotFoundException;
import com.educonnect.progressservice.repository.ProgressRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Slf4j @Service @RequiredArgsConstructor
public class ProgressService {
    private final ProgressRepository progressRepository;

    @Transactional
    public ProgressResponse initProgress(Long studentId, Long courseId, String studentName, String courseTitle) {
        return progressRepository.findByStudentIdAndCourseId(studentId, courseId)
                .map(this::mapToResponse)
                .orElseGet(() -> {
                    Progress p = Progress.builder().studentId(studentId).courseId(courseId)
                            .studentName(studentName).courseTitle(courseTitle).completionPercentage(0.0).build();
                    return mapToResponse(progressRepository.save(p));
                });
    }

    @Transactional
    public ProgressResponse updateProgress(Long studentId, Long courseId, ProgressUpdateRequest req) {
        Progress progress = progressRepository.findByStudentIdAndCourseId(studentId, courseId)
                .orElseGet(() -> Progress.builder().studentId(studentId).courseId(courseId).completionPercentage(0.0).build());

        if (req.getCompletionPercentage() != null) {
            progress.setCompletionPercentage(req.getCompletionPercentage());
            if (req.getCompletionPercentage() >= 100.0)
                progress.setStatus(Progress.ProgressStatus.COMPLETED);
        }
        if (req.getMetricsJson() != null) progress.setMetricsJson(req.getMetricsJson());
        return mapToResponse(progressRepository.save(progress));
    }

    @Transactional(readOnly = true)
    public ProgressResponse getByStudentAndCourse(Long studentId, Long courseId) {
        return mapToResponse(progressRepository.findByStudentIdAndCourseId(studentId, courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Progress not found for student " + studentId + " course " + courseId)));
    }

    @Transactional(readOnly = true)
    public List<ProgressResponse> getByStudent(Long studentId) {
        return progressRepository.findByStudentId(studentId).stream().map(this::mapToResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<ProgressResponse> getByCourse(Long courseId) {
        return progressRepository.findByCourseId(courseId).stream().map(this::mapToResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<ProgressResponse> getCompletedProgress() {
        return progressRepository.findByStatus(Progress.ProgressStatus.COMPLETED).stream().map(this::mapToResponse).toList();
    }

    private ProgressResponse mapToResponse(Progress p) {
        return ProgressResponse.builder()
                .progressId(p.getProgressId()).studentId(p.getStudentId()).studentName(p.getStudentName())
                .courseId(p.getCourseId()).courseTitle(p.getCourseTitle())
                .completionPercentage(p.getCompletionPercentage()).metricsJson(p.getMetricsJson())
                .status(p.getStatus()).updatedAt(p.getUpdatedAt()).build();
    }
}
