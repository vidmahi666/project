package com.educonnect.progressservice.service;

import com.educonnect.progressservice.dto.ProgressResponse;
import com.educonnect.progressservice.dto.ProgressUpdateRequest;
import com.educonnect.progressservice.entity.Progress;
import com.educonnect.progressservice.exception.ResourceNotFoundException;
import com.educonnect.progressservice.repository.ProgressRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProgressServiceTest {

    @Mock private ProgressRepository progressRepository;

    @InjectMocks private ProgressService progressService;

    private Progress progress;

    @BeforeEach
    void setUp() {
        progress = Progress.builder()
                .progressId(1L).studentId(5L).courseId(10L)
                .studentName("Alice").courseTitle("Java Basics")
                .completionPercentage(40.0)
                .status(Progress.ProgressStatus.IN_PROGRESS)
                .build();
    }

    @Test
    @DisplayName("initProgress – creates new progress when none exists")
    void initProgress_createsNew() {
        when(progressRepository.findByStudentIdAndCourseId(5L, 10L)).thenReturn(Optional.empty());
        when(progressRepository.save(any(Progress.class))).thenReturn(progress);

        ProgressResponse result = progressService.initProgress(5L, 10L, "Alice", "Java Basics");
        assertThat(result.getStudentId()).isEqualTo(5L);
        assertThat(result.getCourseId()).isEqualTo(10L);
        verify(progressRepository).save(any(Progress.class));
    }

    @Test
    @DisplayName("initProgress – returns existing progress when already present")
    void initProgress_returnsExisting() {
        when(progressRepository.findByStudentIdAndCourseId(5L, 10L)).thenReturn(Optional.of(progress));

        ProgressResponse result = progressService.initProgress(5L, 10L, "Alice", "Java Basics");
        assertThat(result.getCompletionPercentage()).isEqualTo(40.0);
        verify(progressRepository, never()).save(any());
    }

    @Test
    @DisplayName("updateProgress – updates completion percentage")
    void updateProgress_updatesPercentage() {
        ProgressUpdateRequest req = new ProgressUpdateRequest();
        req.setCompletionPercentage(75.0);

        when(progressRepository.findByStudentIdAndCourseId(5L, 10L)).thenReturn(Optional.of(progress));
        when(progressRepository.save(any(Progress.class))).thenAnswer(inv -> inv.getArgument(0));

        ProgressResponse result = progressService.updateProgress(5L, 10L, req);
        assertThat(result.getCompletionPercentage()).isEqualTo(75.0);
    }

    @Test
    @DisplayName("updateProgress – sets COMPLETED status when percentage reaches 100")
    void updateProgress_setsCompletedAt100() {
        ProgressUpdateRequest req = new ProgressUpdateRequest();
        req.setCompletionPercentage(100.0);

        when(progressRepository.findByStudentIdAndCourseId(5L, 10L)).thenReturn(Optional.of(progress));
        when(progressRepository.save(any(Progress.class))).thenAnswer(inv -> inv.getArgument(0));

        ProgressResponse result = progressService.updateProgress(5L, 10L, req);
        assertThat(result.getStatus()).isEqualTo(Progress.ProgressStatus.COMPLETED);
    }

    @Test
    @DisplayName("getByStudentAndCourse – returns response when found")
    void getByStudentAndCourse_found() {
        when(progressRepository.findByStudentIdAndCourseId(5L, 10L)).thenReturn(Optional.of(progress));
        ProgressResponse result = progressService.getByStudentAndCourse(5L, 10L);
        assertThat(result.getProgressId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getByStudentAndCourse – throws ResourceNotFoundException when not found")
    void getByStudentAndCourse_notFound_throws() {
        when(progressRepository.findByStudentIdAndCourseId(5L, 99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> progressService.getByStudentAndCourse(5L, 99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getByStudent – returns all progress records for student")
    void getByStudent_returnsList() {
        when(progressRepository.findByStudentId(5L)).thenReturn(List.of(progress));
        List<ProgressResponse> result = progressService.getByStudent(5L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStudentId()).isEqualTo(5L);
    }

    @Test
    @DisplayName("getCompletedProgress – returns only COMPLETED records")
    void getCompletedProgress_returnsCompleted() {
        Progress completed = Progress.builder()
                .progressId(2L).studentId(6L).courseId(11L)
                .completionPercentage(100.0).status(Progress.ProgressStatus.COMPLETED).build();
        when(progressRepository.findByStatus(Progress.ProgressStatus.COMPLETED)).thenReturn(List.of(completed));
        List<ProgressResponse> result = progressService.getCompletedProgress();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStatus()).isEqualTo(Progress.ProgressStatus.COMPLETED);
    }
}
