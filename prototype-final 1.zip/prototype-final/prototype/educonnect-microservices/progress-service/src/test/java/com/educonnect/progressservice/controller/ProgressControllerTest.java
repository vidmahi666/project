package com.educonnect.progressservice.controller;

import com.educonnect.progressservice.dto.ProgressResponse;
import com.educonnect.progressservice.dto.ProgressUpdateRequest;
import com.educonnect.progressservice.entity.Progress;
import com.educonnect.progressservice.exception.ResourceNotFoundException;
import com.educonnect.progressservice.service.ProgressService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProgressController.class)
class ProgressControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean ProgressService progressService;

    private ProgressResponse buildResponse() {
        ProgressResponse r = new ProgressResponse();
        r.setProgressId(1L); r.setStudentId(5L); r.setCourseId(10L);
        r.setCompletionPercentage(50.0); r.setStatus(Progress.ProgressStatus.IN_PROGRESS);
        return r;
    }

    @Test
    @DisplayName("POST /progress/init – 400 when studentId missing")
    void initProgress_missingStudentId_returns400() throws Exception {
        mockMvc.perform(post("/progress/init").param("courseId", "10"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("studentId")));
    }

    @Test
    @DisplayName("POST /progress/init – 400 when courseId missing")
    void initProgress_missingCourseId_returns400() throws Exception {
        mockMvc.perform(post("/progress/init").param("studentId", "5"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("courseId")));
    }

    @Test
    @DisplayName("POST /progress/init – 201 when required params present")
    void initProgress_returns201() throws Exception {
        when(progressService.initProgress(5L, 10L, "Alice", "Java")).thenReturn(buildResponse());

        mockMvc.perform(post("/progress/init")
                        .param("studentId", "5").param("courseId", "10")
                        .param("studentName", "Alice").param("courseTitle", "Java"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.studentId").value(5));
    }

    @Test
    @DisplayName("PUT /progress/student/{studentId}/course/{courseId} – 200 on success")
    void updateProgress_returns200() throws Exception {
        ProgressUpdateRequest req = new ProgressUpdateRequest();
        req.setCompletionPercentage(75.0);

        ProgressResponse resp = buildResponse();
        resp.setCompletionPercentage(75.0);
        when(progressService.updateProgress(eq(5L), eq(10L), any())).thenReturn(resp);

        mockMvc.perform(put("/progress/student/5/course/10")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.completionPercentage").value(75.0));
    }

    @Test
    @DisplayName("GET /progress/student/{studentId}/course/{courseId} – 200 when found")
    void getByStudentAndCourse_returns200() throws Exception {
        when(progressService.getByStudentAndCourse(5L, 10L)).thenReturn(buildResponse());

        mockMvc.perform(get("/progress/student/5/course/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.progressId").value(1));
    }

    @Test
    @DisplayName("GET /progress/student/{studentId}/course/{courseId} – 404 when not found")
    void getByStudentAndCourse_notFound_returns404() throws Exception {
        when(progressService.getByStudentAndCourse(5L, 99L))
                .thenThrow(new ResourceNotFoundException("Progress not found"));

        mockMvc.perform(get("/progress/student/5/course/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("GET /progress/student/{studentId} – 200 with list")
    void getByStudent_returns200() throws Exception {
        when(progressService.getByStudent(5L)).thenReturn(List.of(buildResponse()));
        mockMvc.perform(get("/progress/student/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /progress/completed – 200 with list")
    void getCompleted_returns200() throws Exception {
        when(progressService.getCompletedProgress()).thenReturn(List.of());
        mockMvc.perform(get("/progress/completed"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }
}
