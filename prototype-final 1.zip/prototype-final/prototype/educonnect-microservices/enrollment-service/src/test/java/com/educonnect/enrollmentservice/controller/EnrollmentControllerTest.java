package com.educonnect.enrollmentservice.controller;

import com.educonnect.enrollmentservice.dto.*;
import com.educonnect.enrollmentservice.entity.Enrollment;
import com.educonnect.enrollmentservice.exception.BadRequestException;
import com.educonnect.enrollmentservice.exception.ResourceNotFoundException;
import com.educonnect.enrollmentservice.service.EnrollmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EnrollmentController.class)
class EnrollmentControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean EnrollmentService enrollmentService;

    private EnrollmentResponse buildResponse() {
        EnrollmentResponse r = new EnrollmentResponse();
        r.setEnrollmentId(1L); r.setStudentId(5L); r.setCourseId(10L);
        r.setStatus(Enrollment.EnrollmentStatus.ACTIVE);
        return r;
    }

    @Test
    @DisplayName("POST /enrollments – 201 on success")
    void enroll_returns201() throws Exception {
        EnrollmentRequest req = new EnrollmentRequest();
        req.setStudentId(5L); req.setCourseId(10L);

        when(enrollmentService.enroll(any())).thenReturn(buildResponse());

        mockMvc.perform(post("/enrollments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.studentId").value(5));
    }

    @Test
    @DisplayName("POST /enrollments – 400 when already enrolled")
    void enroll_alreadyEnrolled_returns400() throws Exception {
        EnrollmentRequest req = new EnrollmentRequest();
        req.setStudentId(5L); req.setCourseId(10L);

        when(enrollmentService.enroll(any()))
                .thenThrow(new BadRequestException("Student already enrolled in this course"));

        mockMvc.perform(post("/enrollments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Student already enrolled in this course"));
    }

    @Test
    @DisplayName("GET /enrollments/{id} – 200 when found")
    void getById_returns200() throws Exception {
        when(enrollmentService.getById(1L)).thenReturn(buildResponse());
        mockMvc.perform(get("/enrollments/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.enrollmentId").value(1));
    }

    @Test
    @DisplayName("GET /enrollments/{id} – 404 when not found")
    void getById_notFound_returns404() throws Exception {
        when(enrollmentService.getById(99L))
                .thenThrow(new ResourceNotFoundException("Enrollment", 99L));

        mockMvc.perform(get("/enrollments/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("GET /enrollments/student/{studentId} – 200 with list")
    void getByStudent_returns200() throws Exception {
        when(enrollmentService.getByStudent(5L)).thenReturn(List.of(buildResponse()));
        mockMvc.perform(get("/enrollments/student/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("PATCH /enrollments/{id}/status – 400 when status param missing")
    void updateStatus_missingParam_returns400() throws Exception {
        mockMvc.perform(patch("/enrollments/1/status"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("status")));
    }

    @Test
    @DisplayName("PATCH /enrollments/{id}/status – 200 on success")
    void updateStatus_returns200() throws Exception {
        EnrollmentResponse resp = buildResponse();
        resp.setStatus(Enrollment.EnrollmentStatus.COMPLETED);
        when(enrollmentService.updateStatus(1L, "COMPLETED")).thenReturn(resp);

        mockMvc.perform(patch("/enrollments/1/status").param("status", "COMPLETED"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("COMPLETED"));
    }

    @Test
    @DisplayName("PATCH /enrollments/{id}/unenroll – 200 on success")
    void unenroll_returns200() throws Exception {
        EnrollmentResponse resp = buildResponse();
        resp.setStatus(Enrollment.EnrollmentStatus.DROPPED);
        when(enrollmentService.unenroll(1L)).thenReturn(resp);

        mockMvc.perform(patch("/enrollments/1/unenroll"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("DROPPED"));
    }
}
