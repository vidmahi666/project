package com.educonnect.enrollmentservice.service;

import com.educonnect.enrollmentservice.dto.EnrollmentRequest;
import com.educonnect.enrollmentservice.dto.EnrollmentResponse;
import com.educonnect.enrollmentservice.entity.Enrollment;
import com.educonnect.enrollmentservice.exception.BadRequestException;
import com.educonnect.enrollmentservice.exception.ResourceNotFoundException;
import com.educonnect.enrollmentservice.feign.CourseClient;
import com.educonnect.enrollmentservice.feign.StudentClient;
import com.educonnect.enrollmentservice.feign.dto.CourseResponse;
import com.educonnect.enrollmentservice.feign.dto.StudentResponse;
import com.educonnect.enrollmentservice.repository.EnrollmentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EnrollmentServiceTest {

    @Mock private EnrollmentRepository enrollmentRepository;
    @Mock private StudentClient studentClient;
    @Mock private CourseClient courseClient;

    @InjectMocks private EnrollmentService enrollmentService;

    private EnrollmentRequest request;
    private Enrollment enrollment;

    @BeforeEach
    void setUp() {
        request = new EnrollmentRequest();
        request.setStudentId(1L);
        request.setCourseId(10L);
        request.setStudentName("Alice");
        request.setCourseTitle("Java Basics");

        enrollment = Enrollment.builder()
                .enrollmentId(100L)
                .studentId(1L).courseId(10L)
                .studentName("Alice").courseTitle("Java Basics")
                .enrollmentDate(LocalDateTime.now())
                .status(Enrollment.EnrollmentStatus.ACTIVE)
                .build();
    }

    @Test
    @DisplayName("enroll – success when student and course exist and not already enrolled")
    void enroll_success() {
        when(enrollmentRepository.existsByStudentIdAndCourseId(1L, 10L)).thenReturn(false);
        when(enrollmentRepository.save(any(Enrollment.class))).thenReturn(enrollment);

        EnrollmentResponse response = enrollmentService.enroll(request);

        assertThat(response).isNotNull();
        assertThat(response.getStudentId()).isEqualTo(1L);
        assertThat(response.getCourseId()).isEqualTo(10L);
        assertThat(response.getStatus()).isEqualTo(Enrollment.EnrollmentStatus.ACTIVE);
        verify(enrollmentRepository).save(any(Enrollment.class));
    }

    @Test
    @DisplayName("enroll – throws BadRequestException when already enrolled")
    void enroll_alreadyEnrolled_throws() {
        when(enrollmentRepository.existsByStudentIdAndCourseId(1L, 10L)).thenReturn(true);
        assertThatThrownBy(() -> enrollmentService.enroll(request))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("already enrolled");
        verify(enrollmentRepository, never()).save(any());
    }

    @Test
    @DisplayName("enroll – uses feign fallback when student name not provided and student-service is down")
    void enroll_studentServiceDown_usesFallbackName() {
        request.setStudentName(null);
        when(enrollmentRepository.existsByStudentIdAndCourseId(1L, 10L)).thenReturn(false);
        // Simulate circuit breaker open – fallback returns null from feign
        when(studentClient.getStudentByUserId(1L)).thenReturn(null);
        when(enrollmentRepository.save(any(Enrollment.class))).thenReturn(enrollment);

        EnrollmentResponse response = enrollmentService.enroll(request);
        assertThat(response).isNotNull();
    }

    @Test
    @DisplayName("fetchStudentName – returns name when student-service responds")
    void fetchStudentName_success() {
        StudentResponse sr = new StudentResponse();
        sr.setName("Alice");
        when(studentClient.getStudentByUserId(1L)).thenReturn(sr);
        String name = enrollmentService.fetchStudentName(1L);
        assertThat(name).isEqualTo("Alice");
    }

    @Test
    @DisplayName("fetchStudentName – fallback returns Student-{id} when feign returns null")
    void fetchStudentName_nullResponse_returnsFallback() {
        when(studentClient.getStudentByUserId(1L)).thenReturn(null);
        String name = enrollmentService.fetchStudentName(1L);
        assertThat(name).isEqualTo("Student-1");
    }

    @Test
    @DisplayName("studentNameFallback – returns Student-{id} on exception")
    void studentNameFallback_returnsDefaultName() {
        String name = enrollmentService.studentNameFallback(5L, new RuntimeException("timeout"));
        assertThat(name).isEqualTo("Student-5");
    }

    @Test
    @DisplayName("fetchCourseTitle – returns title when course-service responds")
    void fetchCourseTitle_success() {
        CourseResponse cr = new CourseResponse();
        cr.setTitle("Java Basics");
        when(courseClient.getCourseById(10L)).thenReturn(cr);
        String title = enrollmentService.fetchCourseTitle(10L);
        assertThat(title).isEqualTo("Java Basics");
    }

    @Test
    @DisplayName("courseTitleFallback – returns Course-{id} on exception")
    void courseTitleFallback_returnsDefaultTitle() {
        String title = enrollmentService.courseTitleFallback(10L, new RuntimeException("circuit open"));
        assertThat(title).isEqualTo("Course-10");
    }

    @Test
    @DisplayName("getByStudent – returns list from repository")
    void getByStudent_returnsList() {
        when(enrollmentRepository.findByStudentId(1L)).thenReturn(List.of(enrollment));
        List<EnrollmentResponse> result = enrollmentService.getByStudent(1L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStudentId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getById – throws ResourceNotFoundException when not found")
    void getById_notFound_throws() {
        when(enrollmentRepository.findById(999L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> enrollmentService.getById(999L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("updateStatus – changes enrollment status")
    void updateStatus_success() {
        when(enrollmentRepository.findById(100L)).thenReturn(Optional.of(enrollment));
        when(enrollmentRepository.save(any(Enrollment.class))).thenAnswer(inv -> inv.getArgument(0));
        EnrollmentResponse result = enrollmentService.updateStatus(100L, "COMPLETED");
        assertThat(result.getStatus()).isEqualTo(Enrollment.EnrollmentStatus.COMPLETED);
    }

    @Test
    @DisplayName("unenroll – sets status to DROPPED")
    void unenroll_success() {
        when(enrollmentRepository.findById(100L)).thenReturn(Optional.of(enrollment));
        when(enrollmentRepository.save(any(Enrollment.class))).thenAnswer(inv -> inv.getArgument(0));
        EnrollmentResponse result = enrollmentService.unenroll(100L);
        assertThat(result.getStatus()).isEqualTo(Enrollment.EnrollmentStatus.DROPPED);
    }
}
