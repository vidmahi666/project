package com.educonnect.enrollmentservice.feign;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;

class StudentClientFallbackTest {

    private final StudentClientFallback fallback = new StudentClientFallback();

    @Test
    @DisplayName("getStudentByUserId fallback returns null when student-service is down")
    void getStudentByUserId_returnsNull() {
        var result = fallback.getStudentByUserId(1L);
        assertThat(result).isNull();
    }
}
