package com.educonnect.enrollmentservice.feign;
import com.educonnect.enrollmentservice.feign.dto.StudentResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
@Slf4j @Component
public class StudentClientFallback implements StudentClient {
    @Override public StudentResponse getStudentByUserId(Long userId) {
        log.warn("student-service unavailable for userId={}", userId); return null;
    }
}
