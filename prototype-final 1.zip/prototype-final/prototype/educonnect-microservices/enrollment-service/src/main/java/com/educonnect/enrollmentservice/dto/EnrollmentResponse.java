package com.educonnect.enrollmentservice.dto;
import com.educonnect.enrollmentservice.entity.Enrollment;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @AllArgsConstructor @NoArgsConstructor
public class EnrollmentResponse {
    private Long enrollmentId;
    private Long studentId;
    private String studentName;
    private Long courseId;
    private String courseTitle;
    private LocalDateTime enrollmentDate;
    private Enrollment.EnrollmentStatus status;
}
