package com.educonnect.enrollmentservice.config;

import com.educonnect.enrollmentservice.entity.Enrollment;
import com.educonnect.enrollmentservice.repository.EnrollmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final EnrollmentRepository enrollmentRepository;

    @Override
    public void run(String... args) {
        if (enrollmentRepository.count() == 0) {
            enrollmentRepository.save(Enrollment.builder()
                    .studentId(1L).courseId(1L)
                    .studentName("Student One").courseTitle("Introduction to Java")
                    .status(Enrollment.EnrollmentStatus.ACTIVE).build());
            enrollmentRepository.save(Enrollment.builder()
                    .studentId(1L).courseId(2L)
                    .studentName("Student One").courseTitle("Spring Boot Microservices")
                    .status(Enrollment.EnrollmentStatus.ACTIVE).build());
            log.info("Seeded 2 enrollments");
        }
    }
}
