package com.educonnect.enrollmentservice.service;

import com.educonnect.enrollmentservice.dto.EnrollmentRequest;
import com.educonnect.enrollmentservice.dto.EnrollmentResponse;
import com.educonnect.enrollmentservice.entity.Enrollment;
import com.educonnect.enrollmentservice.exception.BadRequestException;
import com.educonnect.enrollmentservice.exception.ResourceNotFoundException;
import com.educonnect.enrollmentservice.feign.CourseClient;
import com.educonnect.enrollmentservice.feign.StudentClient;
import com.educonnect.enrollmentservice.feign.dto.CourseResponse;
import com.educonnect.enrollmentservice.feign.dto.StudentResponse;
import com.educonnect.enrollmentservice.repository.EnrollmentRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentClient studentClient;
    private final CourseClient courseClient;

    @Transactional
    public EnrollmentResponse enroll(EnrollmentRequest request) {
        if (enrollmentRepository.existsByStudentIdAndCourseId(request.getStudentId(), request.getCourseId()))
            throw new BadRequestException("Student " + request.getStudentId() + " is already enrolled in course " + request.getCourseId());

        String studentName = request.getStudentName() != null ? request.getStudentName() : fetchStudentName(request.getStudentId());
        String courseTitle  = request.getCourseTitle()  != null ? request.getCourseTitle()  : fetchCourseTitle(request.getCourseId());

        Enrollment saved = enrollmentRepository.save(Enrollment.builder()
                .studentId(request.getStudentId()).courseId(request.getCourseId())
                .studentName(studentName).courseTitle(courseTitle).build());
        log.info("Enrollment created id={}", saved.getEnrollmentId());
        return mapToResponse(saved);
    }

    @CircuitBreaker(name = "studentService", fallbackMethod = "studentNameFallback")
    @Retry(name = "studentService")
    public String fetchStudentName(Long studentId) {
        StudentResponse sr = studentClient.getStudentByUserId(studentId);
        return sr != null ? sr.getName() : "Student-" + studentId;
    }

    public String studentNameFallback(Long studentId, Exception ex) {
        log.warn("Circuit open for student-service, using fallback name for studentId={}: {}", studentId, ex.getMessage());
        return "Student-" + studentId;
    }

    @CircuitBreaker(name = "courseService", fallbackMethod = "courseTitleFallback")
    @Retry(name = "courseService")
    public String fetchCourseTitle(Long courseId) {
        CourseResponse cr = courseClient.getCourseById(courseId);
        return cr != null ? cr.getTitle() : "Course-" + courseId;
    }

    public String courseTitleFallback(Long courseId, Exception ex) {
        log.warn("Circuit open for course-service, using fallback title for courseId={}: {}", courseId, ex.getMessage());
        return "Course-" + courseId;
    }

    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByStudent(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId).stream().map(this::mapToResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByCourse(Long courseId) {
        return enrollmentRepository.findByCourseId(courseId).stream().map(this::mapToResponse).toList();
    }

    @Transactional(readOnly = true)
    public EnrollmentResponse getById(Long id) {
        return mapToResponse(enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment", id)));
    }

    @Transactional
    public EnrollmentResponse updateStatus(Long id, String status) {
        Enrollment e = findOrThrow(id);
        e.setStatus(Enrollment.EnrollmentStatus.valueOf(status.toUpperCase()));
        return mapToResponse(enrollmentRepository.save(e));
    }

    @Transactional
    public EnrollmentResponse unenroll(Long id) {
        Enrollment e = findOrThrow(id);
        e.setStatus(Enrollment.EnrollmentStatus.DROPPED);
        return mapToResponse(enrollmentRepository.save(e));
    }

    private Enrollment findOrThrow(Long id) {
        return enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment", id));
    }

    private EnrollmentResponse mapToResponse(Enrollment e) {
        return EnrollmentResponse.builder()
                .enrollmentId(e.getEnrollmentId()).studentId(e.getStudentId()).studentName(e.getStudentName())
                .courseId(e.getCourseId()).courseTitle(e.getCourseTitle())
                .enrollmentDate(e.getEnrollmentDate()).status(e.getStatus()).build();
    }
}
