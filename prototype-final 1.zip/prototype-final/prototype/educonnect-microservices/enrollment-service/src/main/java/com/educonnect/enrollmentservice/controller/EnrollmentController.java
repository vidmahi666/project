package com.educonnect.enrollmentservice.controller;

import com.educonnect.enrollmentservice.dto.ApiResponse;
import com.educonnect.enrollmentservice.dto.EnrollmentRequest;
import com.educonnect.enrollmentservice.dto.EnrollmentResponse;
import com.educonnect.enrollmentservice.service.EnrollmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/enrollments") @RequiredArgsConstructor
@Tag(name = "Enrollments", description = "Student course enrollment management")
public class EnrollmentController {
    private final EnrollmentService enrollmentService;

    @PostMapping @Operation(summary = "Enroll a student in a course")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> enroll(@Valid @RequestBody EnrollmentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Enrolled successfully", enrollmentService.enroll(request)));
    }

    @GetMapping("/{enrollmentId}") @Operation(summary = "Get enrollment by ID")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> getById(@PathVariable Long enrollmentId) {
        return ResponseEntity.ok(ApiResponse.ok("Enrollment", enrollmentService.getById(enrollmentId)));
    }

    @GetMapping("/student/{studentId}") @Operation(summary = "Get all enrollments for a student")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.ok("Enrollments", enrollmentService.getByStudent(studentId)));
    }

    @GetMapping("/course/{courseId}") @Operation(summary = "Get all enrollments for a course")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByCourse(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.ok("Enrollments", enrollmentService.getByCourse(courseId)));
    }

    @PatchMapping("/{enrollmentId}/status") @Operation(summary = "Update enrollment status")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> updateStatus(@PathVariable Long enrollmentId, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.ok("Status updated", enrollmentService.updateStatus(enrollmentId, status)));
    }

    @PatchMapping("/{enrollmentId}/unenroll") @Operation(summary = "Drop (unenroll) a student from a course")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> unenroll(@PathVariable Long enrollmentId) {
        return ResponseEntity.ok(ApiResponse.ok("Student unenrolled", enrollmentService.unenroll(enrollmentId)));
    }
}
