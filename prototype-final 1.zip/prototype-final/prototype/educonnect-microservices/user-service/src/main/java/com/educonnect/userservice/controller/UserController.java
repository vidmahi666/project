package com.educonnect.userservice.controller;
import com.educonnect.userservice.dto.ApiResponse;
import com.educonnect.userservice.dto.UpdateUserRequest;
import com.educonnect.userservice.dto.UserResponse;
import com.educonnect.userservice.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/users") @RequiredArgsConstructor
@Tag(name = "Users", description = "User management and queries")
public class UserController {
    private final UserService userService;

    @GetMapping @Operation(summary = "Get all users")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllUsers() {
        return ResponseEntity.ok(ApiResponse.ok("All users", userService.getAllUsers()));
    }
    @GetMapping("/{userId}") @Operation(summary = "Get user by ID")
    public ResponseEntity<ApiResponse<UserResponse>> getById(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("User", userService.getUserById(userId)));
    }
    @GetMapping("/by-email") @Operation(summary = "Get user by email")
    public ResponseEntity<ApiResponse<UserResponse>> getByEmail(@RequestParam String email) {
        return ResponseEntity.ok(ApiResponse.ok("User", userService.getUserByEmail(email)));
    }
    @GetMapping("/role/{role}") @Operation(summary = "Get users by role")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getByRole(@PathVariable String role) {
        return ResponseEntity.ok(ApiResponse.ok("Users by role", userService.getUsersByRole(role)));
    }
    @GetMapping("/status/{status}") @Operation(summary = "Get users by status")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getByStatus(@PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.ok("Users by status", userService.getUsersByStatus(status)));
    }
    @PatchMapping("/{userId}") @Operation(summary = "Update user details")
    public ResponseEntity<ApiResponse<UserResponse>> updateUser(@PathVariable Long userId, @RequestBody UpdateUserRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("User updated", userService.updateUser(userId, request)));
    }
    @PatchMapping("/{userId}/status") @Operation(summary = "Update user status")
    public ResponseEntity<ApiResponse<UserResponse>> updateStatus(@PathVariable Long userId, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.ok("Status updated", userService.updateStatus(userId, status)));
    }
    @DeleteMapping("/{userId}") @Operation(summary = "Deactivate (soft-delete) user")
    public ResponseEntity<ApiResponse<Void>> deactivate(@PathVariable Long userId) {
        userService.deactivateUser(userId);
        return ResponseEntity.ok(ApiResponse.ok("User deactivated", null));
    }
    /** Internal endpoint for other services to look up user info */
    @GetMapping("/internal/{userId}") @Operation(summary = "[INTERNAL] Get user by ID for inter-service calls")
    public ResponseEntity<ApiResponse<UserResponse>> getByIdInternal(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("User", userService.getUserById(userId)));
    }
}
