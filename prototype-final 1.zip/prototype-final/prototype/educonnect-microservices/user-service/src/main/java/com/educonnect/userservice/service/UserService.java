package com.educonnect.userservice.service;
import com.educonnect.userservice.dto.UpdateUserRequest;
import com.educonnect.userservice.dto.UserResponse;
import com.educonnect.userservice.entity.User;
import com.educonnect.userservice.exception.ResourceNotFoundException;
import com.educonnect.userservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
@Slf4j @Service @RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public List<UserResponse> getAllUsers() { return userRepository.findAll().stream().map(this::mapToResponse).toList(); }

    public UserResponse getUserById(Long id) { return mapToResponse(findOrThrow(id)); }

    public UserResponse getUserByEmail(String email) {
        return mapToResponse(userRepository.findByEmail(email).orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email)));
    }

    public List<UserResponse> getUsersByRole(String role) {
        return userRepository.findByRole(User.Role.valueOf(role.toUpperCase())).stream().map(this::mapToResponse).toList();
    }

    public List<UserResponse> getUsersByStatus(String status) {
        return userRepository.findByStatus(User.Status.valueOf(status.toUpperCase())).stream().map(this::mapToResponse).toList();
    }

    @Transactional
    public UserResponse updateUser(Long id, UpdateUserRequest request) {
        User user = findOrThrow(id);
        if (request.getName() != null) user.setName(request.getName());
        if (request.getPhone() != null) user.setPhone(request.getPhone());
        if (request.getStatus() != null) user.setStatus(request.getStatus());
        return mapToResponse(userRepository.save(user));
    }

    @Transactional
    public UserResponse updateStatus(Long id, String status) {
        User user = findOrThrow(id);
        user.setStatus(User.Status.valueOf(status.toUpperCase()));
        return mapToResponse(userRepository.save(user));
    }

    @Transactional
    public void deactivateUser(Long id) {
        User user = findOrThrow(id);
        user.setStatus(User.Status.INACTIVE);
        userRepository.save(user);
        log.info("User id={} deactivated", id);
    }

    private User findOrThrow(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", id));
    }

    private UserResponse mapToResponse(User u) {
        return UserResponse.builder().userId(u.getUserId()).name(u.getName()).email(u.getEmail())
                .phone(u.getPhone()).role(u.getRole()).status(u.getStatus()).createdAt(u.getCreatedAt()).build();
    }
}
