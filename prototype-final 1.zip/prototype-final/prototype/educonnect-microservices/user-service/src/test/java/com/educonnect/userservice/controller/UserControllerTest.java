package com.educonnect.userservice.controller;

import com.educonnect.userservice.dto.*;
import com.educonnect.userservice.entity.User;
import com.educonnect.userservice.exception.ResourceNotFoundException;
import com.educonnect.userservice.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
class UserControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean UserService userService;

    private UserResponse buildUserResponse() {
        return UserResponse.builder().userId(1L).name("Alice")
                .email("alice@test.com").role(User.Role.STUDENT)
                .status(User.Status.ACTIVE).build();
    }

    @Test
    @DisplayName("GET /users – 200 with list")
    void getAllUsers_returns200() throws Exception {
        when(userService.getAllUsers()).thenReturn(List.of(buildUserResponse()));
        mockMvc.perform(get("/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /users/{id} – 200 when found")
    void getById_returns200() throws Exception {
        when(userService.getUserById(1L)).thenReturn(buildUserResponse());
        mockMvc.perform(get("/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userId").value(1));
    }

    @Test
    @DisplayName("GET /users/{id} – 404 when not found")
    void getById_notFound_returns404() throws Exception {
        when(userService.getUserById(99L))
                .thenThrow(new ResourceNotFoundException("User", 99L));
        mockMvc.perform(get("/users/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("GET /users/by-email – 400 when email param missing")
    void getByEmail_missingParam_returns400() throws Exception {
        mockMvc.perform(get("/users/by-email"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("email")));
    }

    @Test
    @DisplayName("GET /users/by-email – 200 when email provided")
    void getByEmail_returns200() throws Exception {
        when(userService.getUserByEmail("alice@test.com")).thenReturn(buildUserResponse());
        mockMvc.perform(get("/users/by-email").param("email", "alice@test.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.email").value("alice@test.com"));
    }

    @Test
    @DisplayName("PATCH /users/{id}/status – 400 when status param missing")
    void updateStatus_missingParam_returns400() throws Exception {
        mockMvc.perform(patch("/users/1/status"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("status")));
    }

    @Test
    @DisplayName("PATCH /users/{id}/status – 200 on success")
    void updateStatus_returns200() throws Exception {
        UserResponse resp = buildUserResponse();
        resp = UserResponse.builder().userId(1L).status(User.Status.INACTIVE).build();
        when(userService.updateStatus(1L, "INACTIVE")).thenReturn(resp);

        mockMvc.perform(patch("/users/1/status").param("status", "INACTIVE"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("DELETE /users/{id} – 200 (soft delete)")
    void deactivate_returns200() throws Exception {
        doNothing().when(userService).deactivateUser(1L);
        mockMvc.perform(delete("/users/1"))
                .andExpect(status().isOk());
    }
}
