package com.educonnect.userservice.service;

import com.educonnect.userservice.dto.UpdateUserRequest;
import com.educonnect.userservice.dto.UserResponse;
import com.educonnect.userservice.entity.User;
import com.educonnect.userservice.exception.ResourceNotFoundException;
import com.educonnect.userservice.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock private UserRepository userRepository;
    @InjectMocks private UserService userService;

    private User user;

    @BeforeEach
    void setUp() {
        user = User.builder()
                .userId(1L).name("Alice").email("alice@test.com")
                .phone("9876543210").role(User.Role.STUDENT)
                .status(User.Status.ACTIVE).build();
    }

    @Test
    @DisplayName("getAllUsers – returns mapped list from repository")
    void getAllUsers_returnsList() {
        when(userRepository.findAll()).thenReturn(List.of(user));
        List<UserResponse> result = userService.getAllUsers();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getEmail()).isEqualTo("alice@test.com");
    }

    @Test
    @DisplayName("getUserById – returns response when found")
    void getUserById_found() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        UserResponse result = userService.getUserById(1L);
        assertThat(result.getUserId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getUserById – throws ResourceNotFoundException when not found")
    void getUserById_notFound_throws() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> userService.getUserById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getUserByEmail – returns user for valid email")
    void getUserByEmail_found() {
        when(userRepository.findByEmail("alice@test.com")).thenReturn(Optional.of(user));
        UserResponse result = userService.getUserByEmail("alice@test.com");
        assertThat(result.getEmail()).isEqualTo("alice@test.com");
    }

    @Test
    @DisplayName("getUserByEmail – throws ResourceNotFoundException for unknown email")
    void getUserByEmail_notFound_throws() {
        when(userRepository.findByEmail("ghost@test.com")).thenReturn(Optional.empty());
        assertThatThrownBy(() -> userService.getUserByEmail("ghost@test.com"))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getUsersByRole – filters by role")
    void getUsersByRole_returnsFiltered() {
        when(userRepository.findByRole(User.Role.STUDENT)).thenReturn(List.of(user));
        List<UserResponse> result = userService.getUsersByRole("STUDENT");
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getRole()).isEqualTo(User.Role.STUDENT);
    }

    @Test
    @DisplayName("getUsersByRole – throws IllegalArgumentException for invalid role")
    void getUsersByRole_invalidRole_throws() {
        assertThatThrownBy(() -> userService.getUsersByRole("INVALID_ROLE"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("getUsersByStatus – filters by status")
    void getUsersByStatus_returnsFiltered() {
        when(userRepository.findByStatus(User.Status.ACTIVE)).thenReturn(List.of(user));
        List<UserResponse> result = userService.getUsersByStatus("ACTIVE");
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("updateUser – updates name and phone")
    void updateUser_success() {
        UpdateUserRequest req = new UpdateUserRequest();
        req.setName("Alice Updated"); req.setPhone("1111111111");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        UserResponse result = userService.updateUser(1L, req);
        assertThat(result.getName()).isEqualTo("Alice Updated");
        assertThat(result.getPhone()).isEqualTo("1111111111");
    }

    @Test
    @DisplayName("updateStatus – changes user status")
    void updateStatus_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        UserResponse result = userService.updateStatus(1L, "INACTIVE");
        assertThat(result.getStatus()).isEqualTo(User.Status.INACTIVE);
    }

    @Test
    @DisplayName("updateStatus – throws IllegalArgumentException for invalid status")
    void updateStatus_invalidStatus_throws() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        assertThatThrownBy(() -> userService.updateStatus(1L, "BAD_STATUS"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("deactivateUser – sets status to INACTIVE")
    void deactivateUser_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);
        assertThatNoException().isThrownBy(() -> userService.deactivateUser(1L));
        verify(userRepository).save(argThat(u -> u.getStatus() == User.Status.INACTIVE));
    }

    @Test
    @DisplayName("deactivateUser – throws ResourceNotFoundException when not found")
    void deactivateUser_notFound_throws() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> userService.deactivateUser(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }
}
