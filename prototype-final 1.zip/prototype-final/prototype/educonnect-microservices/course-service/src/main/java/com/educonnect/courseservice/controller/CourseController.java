package com.educonnect.courseservice.controller;

import com.educonnect.courseservice.dto.*;
import com.educonnect.courseservice.entity.*;
import com.educonnect.courseservice.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courses")
@RequiredArgsConstructor
@Tag(name = "Courses", description = "Course management")
public class CourseController {
    private final CourseService courseService;

    @PostMapping
    @PreAuthorize("hasRole('TEACHER')")
    @Operation(summary = "Create course")
    public ResponseEntity<ApiResponse<Course>> createCourse(@Valid @RequestBody CourseRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Course created", courseService.createCourse(req)));
    }

    @GetMapping
    @Operation(summary = "Get all courses")
    public ResponseEntity<ApiResponse<List<Course>>> getAllCourses() {
        return ResponseEntity.ok(ApiResponse.ok("Courses", courseService.getAllCourses()));
    }

    @GetMapping("/{courseId}")
    @Operation(summary = "Get course by ID")
    public ResponseEntity<ApiResponse<Course>> getCourseById(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.ok("Course", courseService.getCourseById(courseId)));
    }

    @PutMapping("/{courseId}")
    @PreAuthorize("hasRole('TEACHER')")
    @Operation(summary = "Update course")
    public ResponseEntity<ApiResponse<Course>> updateCourse(@PathVariable Long courseId, @Valid @RequestBody CourseRequest req) {
        return ResponseEntity.ok(ApiResponse.ok("Course updated", courseService.updateCourse(courseId, req)));
    }
}
