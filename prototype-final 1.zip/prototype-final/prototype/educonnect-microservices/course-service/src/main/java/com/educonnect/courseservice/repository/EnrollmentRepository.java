package com.educonnect.courseservice.repository;

import com.educonnect.courseservice.entity.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByStudentId(Long studentId);
    List<Enrollment> findByCourseCourseId(Long courseId);
    Optional<Enrollment> findByStudentIdAndCourseCourseId(Long studentId, Long courseId);
    boolean existsByStudentIdAndCourseCourseId(Long studentId, Long courseId);
}
