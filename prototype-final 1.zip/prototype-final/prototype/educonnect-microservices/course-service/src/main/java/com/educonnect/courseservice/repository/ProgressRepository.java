package com.educonnect.courseservice.repository;

import com.educonnect.courseservice.entity.Progress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProgressRepository extends JpaRepository<Progress, Long> {
    List<Progress> findByStudentId(Long studentId);
    Optional<Progress> findByStudentIdAndCourseCourseId(Long studentId, Long courseId);
}
