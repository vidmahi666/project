package com.educonnect.courseservice.security;
import io.jsonwebtoken.Claims; import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders; import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Component;
import javax.crypto.SecretKey;
@Component
public class JwtUtil {
    @Value("${jwt.secret}") private String secret;
    public Claims extractAllClaims(String token) { return Jwts.parser().verifyWith(getSignKey()).build().parseSignedClaims(token).getPayload(); }
    private SecretKey getSignKey() { return Keys.hmacShaKeyFor(Decoders.BASE64URL.decode(secret)); }
    public boolean validateToken(String token) { try { return !extractAllClaims(token).getExpiration().before(new java.util.Date()); } catch(Exception e){return false;} }
    public String extractUsername(String token) { return extractAllClaims(token).getSubject(); }
}
