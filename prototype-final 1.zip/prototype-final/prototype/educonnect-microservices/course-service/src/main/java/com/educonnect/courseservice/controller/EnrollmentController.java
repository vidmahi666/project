package com.educonnect.courseservice.controller;

import com.educonnect.courseservice.dto.*;
import com.educonnect.courseservice.entity.Enrollment;
import com.educonnect.courseservice.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/enrollments") @RequiredArgsConstructor
@Tag(name = "Enrollments", description = "Course enrollment management")
public class EnrollmentController {
    private final CourseService courseService;

    @PostMapping @Operation(summary = "Enroll student in course")
    public ResponseEntity<ApiResponse<Enrollment>> enrollStudent(@Valid @RequestBody EnrollmentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Student enrolled", courseService.enrollStudent(req)));
    }

    @GetMapping("/student/{studentId}") @Operation(summary = "Get enrollments by student")
    public ResponseEntity<ApiResponse<List<Enrollment>>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.ok("Enrollments", courseService.getEnrollmentsByStudent(studentId)));
    }

    @GetMapping("/course/{courseId}") @Operation(summary = "Get enrollments by course")
    public ResponseEntity<ApiResponse<List<Enrollment>>> getByCourse(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.ok("Enrollments", courseService.getEnrollmentsByCourse(courseId)));
    }
}
