package com.educonnect.courseservice.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;
@Data
public class CourseRequest {
    @NotBlank private String title;
    private String description;
    @NotNull private Long teacherUserId;
    private LocalDate startDate;
    private LocalDate endDate;
}
