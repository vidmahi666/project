package com.educonnect.courseservice.feign;

import com.educonnect.courseservice.feign.dto.StudentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
    name = "student-service",
    fallback = StudentClientFallback.class,
    configuration = FeignConfig.class
)
public interface StudentClient {
    @GetMapping("/students/{studentId}")
    StudentResponse getStudentById(@PathVariable Long studentId);
}
