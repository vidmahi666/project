package com.educonnect.courseservice.repository;

import com.educonnect.courseservice.entity.Curriculum;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CurriculumRepository extends JpaRepository<Curriculum, Long> {
    List<Curriculum> findByCourseCourseId(Long courseId);
}
