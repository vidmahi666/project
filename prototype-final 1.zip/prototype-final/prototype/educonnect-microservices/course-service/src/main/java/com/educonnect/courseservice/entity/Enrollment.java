package com.educonnect.courseservice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;

@Entity @Table(name = "enrollments", uniqueConstraints = @UniqueConstraint(columnNames = {"student_id","course_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Enrollment {
    public enum EnrollmentStatus { ACTIVE, COMPLETED, DROPPED, SUSPENDED }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long enrollmentId;
    @Column(nullable = false) private Long studentId;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "course_id", nullable = false) private Course course;
    @CreatedDate private LocalDateTime enrollmentDate;
    @Enumerated(EnumType.STRING) @Builder.Default private EnrollmentStatus status = EnrollmentStatus.ACTIVE;
}
