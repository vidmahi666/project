package com.educonnect.courseservice.dto;
import lombok.Data;
@Data
public class ProgressUpdateRequest {
    private Double completionPercentage;
    private String metricsJson;
}
