package com.educonnect.courseservice.exception;
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) { super(message); }
    public ResourceNotFoundException(String r, Long id) { super(r + " not found with id: " + id); }
}
