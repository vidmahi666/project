package com.educonnect.courseservice.service;

import com.educonnect.courseservice.dto.*;
import com.educonnect.courseservice.entity.*;
import com.educonnect.courseservice.exception.ResourceNotFoundException;
import com.educonnect.courseservice.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CourseServiceTest {

    @Mock private CourseRepository courseRepository;
    @Mock private EnrollmentRepository enrollmentRepository;
    @Mock private ProgressRepository progressRepository;
    @Mock private CurriculumRepository curriculumRepository;

    @InjectMocks private CourseService courseService;

    private Course course;

    @BeforeEach
    void setUp() {
        course = Course.builder()
                .courseId(1L).title("Java Basics").description("Intro to Java")
                .teacherUserId(100L)
                .startDate(LocalDate.now()).endDate(LocalDate.now().plusMonths(3))
                .status(Course.CourseStatus.ACTIVE)
                .build();
    }

    @Test
    @DisplayName("createCourse – saves and returns course")
    void createCourse_success() {
        CourseRequest req = new CourseRequest();
        req.setTitle("Java Basics"); req.setDescription("Intro to Java");
        req.setTeacherUserId(100L);
        req.setStartDate(LocalDate.now()); req.setEndDate(LocalDate.now().plusMonths(3));

        when(courseRepository.save(any(Course.class))).thenReturn(course);
        Course result = courseService.createCourse(req);

        assertThat(result.getTitle()).isEqualTo("Java Basics");
        assertThat(result.getTeacherUserId()).isEqualTo(100L);
        verify(courseRepository).save(any(Course.class));
    }

    @Test
    @DisplayName("getCourseById – returns course when found")
    void getCourseById_found() {
        when(courseRepository.findById(1L)).thenReturn(Optional.of(course));
        Course result = courseService.getCourseById(1L);
        assertThat(result.getCourseId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getCourseById – throws ResourceNotFoundException when not found")
    void getCourseById_notFound_throws() {
        when(courseRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> courseService.getCourseById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getAllCourses – returns all courses from repository")
    void getAllCourses_returnsList() {
        when(courseRepository.findAll()).thenReturn(List.of(course));
        List<Course> result = courseService.getAllCourses();
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getCoursesByTeacher – filters by teacherUserId")
    void getCoursesByTeacher_returnsList() {
        when(courseRepository.findByTeacherUserId(100L)).thenReturn(List.of(course));
        List<Course> result = courseService.getCoursesByTeacher(100L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getTeacherUserId()).isEqualTo(100L);
    }

    @Test
    @DisplayName("updateCourse – updates title and description")
    void updateCourse_success() {
        CourseRequest req = new CourseRequest();
        req.setTitle("Advanced Java"); req.setDescription("Deep dive");
        req.setStartDate(LocalDate.now()); req.setEndDate(LocalDate.now().plusMonths(6));

        when(courseRepository.findById(1L)).thenReturn(Optional.of(course));
        when(courseRepository.save(any(Course.class))).thenAnswer(inv -> inv.getArgument(0));

        Course result = courseService.updateCourse(1L, req);
        assertThat(result.getTitle()).isEqualTo("Advanced Java");
    }

    @Test
    @DisplayName("enrollStudent – saves enrollment and creates progress record")
    void enrollStudent_success() {
        EnrollmentRequest req = new EnrollmentRequest();
        req.setStudentId(5L); req.setCourseId(1L);

        Enrollment enrollment = Enrollment.builder()
                .enrollmentId(200L).studentId(5L).course(course).build();

        when(courseRepository.findById(1L)).thenReturn(Optional.of(course));
        when(enrollmentRepository.existsByStudentIdAndCourseCourseId(5L, 1L)).thenReturn(false);
        when(enrollmentRepository.save(any(Enrollment.class))).thenReturn(enrollment);
        when(progressRepository.save(any(Progress.class))).thenReturn(Progress.builder().build());

        Enrollment result = courseService.enrollStudent(req);
        assertThat(result.getStudentId()).isEqualTo(5L);
        verify(progressRepository).save(any(Progress.class));
    }

    @Test
    @DisplayName("enrollStudent – throws when already enrolled")
    void enrollStudent_alreadyEnrolled_throws() {
        EnrollmentRequest req = new EnrollmentRequest();
        req.setStudentId(5L); req.setCourseId(1L);

        when(enrollmentRepository.existsByStudentIdAndCourseCourseId(5L, 1L)).thenReturn(true);
        assertThatThrownBy(() -> courseService.enrollStudent(req))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("already enrolled");
    }

    @Test
    @DisplayName("updateProgress – sets COMPLETED status when 100%")
    void updateProgress_setsCompleted() {
        ProgressUpdateRequest req = new ProgressUpdateRequest();
        req.setCompletionPercentage(100.0);

        Progress progress = Progress.builder().studentId(5L).course(course).completionPercentage(50.0).build();
        when(progressRepository.findByStudentIdAndCourseCourseId(5L, 1L)).thenReturn(Optional.of(progress));
        when(progressRepository.save(any(Progress.class))).thenAnswer(inv -> inv.getArgument(0));

        Progress result = courseService.updateProgress(5L, 1L, req);
        assertThat(result.getStatus()).isEqualTo(Progress.ProgressStatus.COMPLETED);
        assertThat(result.getCompletionPercentage()).isEqualTo(100.0);
    }
}
