package com.educonnect.complianceservice.controller;

import com.educonnect.complianceservice.dto.*;
import com.educonnect.complianceservice.entity.*;
import com.educonnect.complianceservice.service.ComplianceService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ComplianceController.class)
class ComplianceControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean ComplianceService complianceService;

    @Test
    @DisplayName("GET /compliance – 200 with all records")
    void getAll_returns200() throws Exception {
        ComplianceRecord r = ComplianceRecord.builder().complianceId(1L)
                .result(ComplianceRecord.ComplianceResult.UNDER_REVIEW).build();
        when(complianceService.getAllRecords()).thenReturn(List.of(r));

        mockMvc.perform(get("/compliance"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /compliance/entity/{entityId} – 200 with filtered list")
    void getByEntity_returns200() throws Exception {
        when(complianceService.getRecordsByEntity(10L)).thenReturn(List.of());
        mockMvc.perform(get("/compliance/entity/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("PATCH /compliance/{id}/result – 400 when result param missing")
    void updateResult_missingParam_returns400() throws Exception {
        mockMvc.perform(patch("/compliance/1/result"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("result")));
    }

    @Test
    @DisplayName("PATCH /compliance/{id}/result – 200 on success")
    void updateResult_returns200() throws Exception {
        ComplianceRecord r = ComplianceRecord.builder().complianceId(1L)
                .result(ComplianceRecord.ComplianceResult.COMPLIANT).build();
        when(complianceService.updateResult(1L, ComplianceRecord.ComplianceResult.COMPLIANT)).thenReturn(r);

        mockMvc.perform(patch("/compliance/1/result").param("result", "COMPLIANT"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.result").value("COMPLIANT"));
    }
}
