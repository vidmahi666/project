package com.educonnect.complianceservice.service;

import com.educonnect.complianceservice.dto.*;
import com.educonnect.complianceservice.entity.*;
import com.educonnect.complianceservice.exception.ResourceNotFoundException;
import com.educonnect.complianceservice.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ComplianceServiceTest {

    @Mock private ComplianceRecordRepository complianceRecordRepository;
    @Mock private AuditRepository auditRepository;
    @Mock private AuditLogRepository auditLogRepository;

    @InjectMocks private ComplianceService complianceService;

    private ComplianceRecord record;
    private Audit audit;
    private AuditLog auditLog;

    @BeforeEach
    void setUp() {
        // In setUp()
        record = ComplianceRecord.builder()
                .complianceId(1L).entityId(10L)
                .type(ComplianceRecord.ComplianceType.COURSE)
                .result(ComplianceRecord.ComplianceResult.UNDER_REVIEW)  // Changed from PENDING
                .notes("Awaiting review")
                .build();

        audit = Audit.builder()
                .auditId(2L).title("Q1 Audit").description("Quarterly compliance review")
                .auditorUserId(100L).status(Audit.AuditStatus.SCHEDULED)  // Changed from OPEN
                .build();

        auditLog = AuditLog.builder()
                .logId(3L).action("COURSE_CREATED").entityType("COURSE")
                .entityId(10L).performedByUserId(100L)
                .build();
    }

    @Test
    @DisplayName("createComplianceRecord – saves and returns record")
    void createComplianceRecord_success() {
        ComplianceRecordRequest req = new ComplianceRecordRequest();
        req.setEntityId(10L);
        req.setType(ComplianceRecord.ComplianceType.COURSE);
        req.setResult(ComplianceRecord.ComplianceResult.UNDER_REVIEW);  // Changed from PENDING
        req.setNotes("Awaiting review");

        when(complianceRecordRepository.save(any(ComplianceRecord.class))).thenReturn(record);
        ComplianceRecord result = complianceService.createComplianceRecord(req);

        assertThat(result.getEntityId()).isEqualTo(10L);
        assertThat(result.getResult()).isEqualTo(ComplianceRecord.ComplianceResult.UNDER_REVIEW);
        verify(complianceRecordRepository).save(any(ComplianceRecord.class));
    }

    @Test
    @DisplayName("getAllRecords – returns all records")
    void getAllRecords_returnsList() {
        when(complianceRecordRepository.findAll()).thenReturn(List.of(record));
        List<ComplianceRecord> result = complianceService.getAllRecords();
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getRecordsByEntity – filters by entityId")
    void getRecordsByEntity_returnsList() {
        when(complianceRecordRepository.findByEntityId(10L)).thenReturn(List.of(record));
        List<ComplianceRecord> result = complianceService.getRecordsByEntity(10L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getEntityId()).isEqualTo(10L);
    }

    @Test
    @DisplayName("updateResult – changes compliance result")
    void updateResult_success() {
        when(complianceRecordRepository.findById(1L)).thenReturn(Optional.of(record));
        when(complianceRecordRepository.save(any(ComplianceRecord.class))).thenAnswer(inv -> inv.getArgument(0));
        // In updateResult_success()
        ComplianceRecord result = complianceService.updateResult(1L, ComplianceRecord.ComplianceResult.COMPLIANT);  // Changed from COMPLIANT (already correct, but ensuring consistency)
        assertThat(result.getResult()).isEqualTo(ComplianceRecord.ComplianceResult.COMPLIANT);
    }

    @Test
    @DisplayName("updateResult – throws ResourceNotFoundException when record missing")
    void updateResult_notFound_throws() {
        when(complianceRecordRepository.findById(99L)).thenReturn(Optional.empty());
        // In updateResult_notFound_throws()
        assertThatThrownBy(() -> complianceService.updateResult(99L, ComplianceRecord.ComplianceResult.COMPLIANT))  // Changed from COMPLIANT (already correct)
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("createAudit – saves and returns audit")
    void createAudit_success() {
        AuditRequest req = new AuditRequest();
        req.setTitle("Q1 Audit"); req.setDescription("Quarterly compliance review");
        req.setAuditorUserId(100L);

        when(auditRepository.save(any(Audit.class))).thenReturn(audit);
        Audit result = complianceService.createAudit(req);

        // In createAudit_success()
        assertThat(result.getTitle()).isEqualTo("Q1 Audit");
        assertThat(result.getStatus()).isEqualTo(Audit.AuditStatus.SCHEDULED);  // Changed from OPEN
        verify(auditRepository).save(any(Audit.class));
    }

    @Test
    @DisplayName("getAllAudits – returns full list")
    void getAllAudits_returnsList() {
        when(auditRepository.findAll()).thenReturn(List.of(audit));
        List<Audit> result = complianceService.getAllAudits();
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("updateAuditStatus – sets new status")
    void updateAuditStatus_success() {
        when(auditRepository.findById(2L)).thenReturn(Optional.of(audit));
        when(auditRepository.save(any(Audit.class))).thenAnswer(inv -> inv.getArgument(0));
        // In updateAuditStatus_success()
        Audit result = complianceService.updateAuditStatus(2L, Audit.AuditStatus.COMPLETED);  // Changed from CLOSED
        assertThat(result.getStatus()).isEqualTo(Audit.AuditStatus.COMPLETED);  // Changed from CLOSED
    }

    @Test
    @DisplayName("logAction – saves audit log entry")
    void logAction_success() {
        AuditLogRequest req = new AuditLogRequest();
        req.setAction("COURSE_CREATED"); req.setEntityType("COURSE");
        req.setEntityId(10L); req.setPerformedByUserId(100L);

        when(auditLogRepository.save(any(AuditLog.class))).thenReturn(auditLog);
        AuditLog result = complianceService.logAction(req);

        assertThat(result.getAction()).isEqualTo("COURSE_CREATED");
        verify(auditLogRepository).save(any(AuditLog.class));
    }

    @Test
    @DisplayName("getLogsByEntity – returns logs for entity type and id")
    void getLogsByEntity_returnsList() {
        when(auditLogRepository.findByEntityTypeAndEntityId("COURSE", 10L)).thenReturn(List.of(auditLog));
        List<AuditLog> result = complianceService.getLogsByEntity("COURSE", 10L);
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getLogsByUser – returns logs for user")
    void getLogsByUser_returnsList() {
        when(auditLogRepository.findByPerformedByUserId(100L)).thenReturn(List.of(auditLog));
        List<AuditLog> result = complianceService.getLogsByUser(100L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getPerformedByUserId()).isEqualTo(100L);
    }
}
