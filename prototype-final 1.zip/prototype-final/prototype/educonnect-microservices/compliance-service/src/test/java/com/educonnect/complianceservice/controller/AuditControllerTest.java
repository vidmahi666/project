package com.educonnect.complianceservice.controller;

import com.educonnect.complianceservice.dto.*;
import com.educonnect.complianceservice.entity.*;
import com.educonnect.complianceservice.service.ComplianceService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuditController.class)
class AuditControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean ComplianceService complianceService;

    @Test
    @DisplayName("GET /audits – 200 with all audits")
    void getAll_returns200() throws Exception {
        when(complianceService.getAllAudits()).thenReturn(List.of());
        mockMvc.perform(get("/audits"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("PATCH /audits/{id}/status – 400 when status param missing")
    void updateStatus_missingParam_returns400() throws Exception {
        mockMvc.perform(patch("/audits/1/status"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("status")));
    }

    @Test
    @DisplayName("GET /audits/logs/entity – 400 when entityType missing")
    void getByEntity_missingEntityType_returns400() throws Exception {
        mockMvc.perform(get("/audits/logs/entity").param("entityId", "10"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("entityType")));
    }

    @Test
    @DisplayName("GET /audits/logs/entity – 400 when entityId missing")
    void getByEntity_missingEntityId_returns400() throws Exception {
        mockMvc.perform(get("/audits/logs/entity").param("entityType", "COURSE"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("entityId")));
    }

    @Test
    @DisplayName("GET /audits/logs/entity – 200 with both params")
    void getByEntity_returns200() throws Exception {
        when(complianceService.getLogsByEntity("COURSE", 10L)).thenReturn(List.of());
        mockMvc.perform(get("/audits/logs/entity")
                        .param("entityType", "COURSE").param("entityId", "10"))
                .andExpect(status().isOk());
    }
}
