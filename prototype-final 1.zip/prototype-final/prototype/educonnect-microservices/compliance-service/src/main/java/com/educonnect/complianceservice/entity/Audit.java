package com.educonnect.complianceservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name="audits")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Audit{
    public enum AuditStatus{SCHEDULED,IN_PROGRESS,COMPLETED,CANCELLED}
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long auditId;
    @Column(nullable=false) private String title;
    @Column(columnDefinition="TEXT") private String description;
    private Long auditorUserId;
    @Enumerated(EnumType.STRING) @Builder.Default private AuditStatus status=AuditStatus.SCHEDULED;
    @CreatedDate private LocalDateTime createdAt;
}
