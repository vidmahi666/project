package com.educonnect.complianceservice.dto;
import jakarta.validation.constraints.NotBlank;import lombok.Data;
@Data public class AuditLogRequest{
    @NotBlank private String action;
    @NotBlank private String entityType;
    private Long entityId;
    private Long performedByUserId;
    private String details;
}
