package com.educonnect.complianceservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name="compliance_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class ComplianceRecord{
    public enum ComplianceType{COURSE,ASSESSMENT,PROGRAM,CONTENT}
    public enum ComplianceResult{COMPLIANT,NON_COMPLIANT,UNDER_REVIEW,REMEDIATED}
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long complianceId;
    private Long entityId;
    @Enumerated(EnumType.STRING) @Column(nullable=false) private ComplianceType type;
    @Enumerated(EnumType.STRING) private ComplianceResult result;
    @CreatedDate private LocalDateTime recordDate;
    @Column(columnDefinition="TEXT") private String notes;
}
