package com.educonnect.complianceservice.config;

import com.educonnect.complianceservice.entity.*;
import com.educonnect.complianceservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final ComplianceRecordRepository complianceRecordRepository;
    private final AuditRepository auditRepository;
    private final AuditLogRepository auditLogRepository;

    @Override
    public void run(String... args) {
        if (complianceRecordRepository.count() == 0) {
            complianceRecordRepository.save(ComplianceRecord.builder()
                    .entityId(1L).type(ComplianceRecord.ComplianceType.COURSE)
                    .result(ComplianceRecord.ComplianceResult.COMPLIANT)
                    .notes("Introduction to Java meets all curriculum standards").build());
            complianceRecordRepository.save(ComplianceRecord.builder()
                    .entityId(1L).type(ComplianceRecord.ComplianceType.ASSESSMENT)
                    .result(ComplianceRecord.ComplianceResult.UNDER_REVIEW)
                    .notes("Assessment rubric under review by compliance team").build());
            log.info("Seeded 2 compliance records");
        }
        if (auditRepository.count() == 0) {
            auditRepository.save(Audit.builder()
                    .title("Q1 Course Content Audit").description("Quarterly audit of course content for Q1 2025")
                    .auditorUserId(5L).status(Audit.AuditStatus.SCHEDULED).build());
            log.info("Seeded 1 audit");
        }
        if (auditLogRepository.count() == 0) {
            auditLogRepository.save(AuditLog.builder()
                    .action("COURSE_CREATED").entityType("COURSE").entityId(1L)
                    .performedByUserId(2L).details("Introduction to Java course created by teacher").build());
            log.info("Seeded 1 audit log");
        }
    }
}
