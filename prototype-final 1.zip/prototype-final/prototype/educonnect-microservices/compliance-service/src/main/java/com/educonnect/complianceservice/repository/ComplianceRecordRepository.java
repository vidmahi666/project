package com.educonnect.complianceservice.repository;
import com.educonnect.complianceservice.entity.ComplianceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository public interface ComplianceRecordRepository extends JpaRepository<ComplianceRecord,Long>{
    List<ComplianceRecord> findByType(ComplianceRecord.ComplianceType type);
    List<ComplianceRecord> findByEntityId(Long entityId);
}
