package com.educonnect.complianceservice.repository;
import com.educonnect.complianceservice.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository public interface AuditLogRepository extends JpaRepository<AuditLog,Long>{
    List<AuditLog> findByEntityTypeAndEntityId(String entityType,Long entityId);
    List<AuditLog> findByPerformedByUserId(Long userId);
}
