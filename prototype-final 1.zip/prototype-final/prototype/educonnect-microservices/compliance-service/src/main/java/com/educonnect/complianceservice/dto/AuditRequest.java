package com.educonnect.complianceservice.dto;
import jakarta.validation.constraints.NotBlank;import jakarta.validation.constraints.NotNull;import lombok.Data;
@Data public class AuditRequest{
    @NotBlank private String title;
    private String description;
    @NotNull private Long auditorUserId;
}
