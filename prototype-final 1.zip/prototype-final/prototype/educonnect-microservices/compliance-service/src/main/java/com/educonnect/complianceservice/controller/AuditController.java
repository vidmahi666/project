package com.educonnect.complianceservice.controller;

import com.educonnect.complianceservice.dto.*;
import com.educonnect.complianceservice.entity.*;
import com.educonnect.complianceservice.service.ComplianceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/audits")
@RequiredArgsConstructor
@Tag(name = "Audits", description = "Audit and audit log management")
public class AuditController {
    private final ComplianceService complianceService;

    @PostMapping
    @PreAuthorize("hasRole('GOVERNMENT_AUDITOR')")
    @Operation(summary = "Create audit")
    public ResponseEntity<ApiResponse<Audit>> create(@Valid @RequestBody AuditRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Audit created", complianceService.createAudit(req)));
    }

    @GetMapping
    @Operation(summary = "Get all audits")
    public ResponseEntity<ApiResponse<List<Audit>>> getAll() {
        return ResponseEntity.ok(ApiResponse.ok("Audits", complianceService.getAllAudits()));
    }

    @PatchMapping("/{auditId}/status")
    @PreAuthorize("hasRole('GOVERNMENT_AUDITOR')")
    @Operation(summary = "Update audit status")
    public ResponseEntity<ApiResponse<Audit>> updateStatus(@PathVariable Long auditId, @RequestParam Audit.AuditStatus status) {
        return ResponseEntity.ok(ApiResponse.ok("Status updated", complianceService.updateAuditStatus(auditId, status)));
    }

    @PostMapping("/logs")
    @Operation(summary = "Log an action")
    public ResponseEntity<ApiResponse<AuditLog>> logAction(@Valid @RequestBody AuditLogRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Logged", complianceService.logAction(req)));
    }

    @GetMapping("/logs/entity")
    @Operation(summary = "Get logs by entity")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getByEntity(@RequestParam String entityType, @RequestParam Long entityId) {
        return ResponseEntity.ok(ApiResponse.ok("Logs", complianceService.getLogsByEntity(entityType, entityId)));
    }

    @GetMapping("/logs/user/{userId}")
    @Operation(summary = "Get logs by user")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Logs", complianceService.getLogsByUser(userId)));
    }
}
