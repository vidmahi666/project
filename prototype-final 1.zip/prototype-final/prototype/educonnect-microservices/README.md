# EduConnect Microservices

Monolith-to-microservices conversion of the EduConnect platform, modelled after the CityCare microservices architecture.

## Architecture

```
                        ┌──────────────────┐
                        │   API Gateway    │  :8080
                        │  (JWT Filter)    │
                        └────────┬─────────┘
                                 │
              ┌──────────────────┼──────────────────────┐
              │                  │                       │
    ┌─────────▼────────┐ ┌──────▼───────┐ ┌────────────▼──────┐
    │  auth-service    │ │student-service│ │  course-service   │
    │     :8081        │ │    :8082      │ │      :8083        │
    └──────────────────┘ └──────────────┘ └───────────────────┘
              │                                      │
    ┌─────────▼──────────┐            ┌──────────────▼────────┐
    │ assessment-service │            │   content-service     │
    │      :8084         │            │       :8085           │
    └────────────────────┘            └───────────────────────┘
              │
    ┌─────────▼──────────┐  ┌────────────────────────────────┐
    │notification-service│  │    compliance-service          │
    │       :8086        │  │         :8087                  │
    └────────────────────┘  └────────────────────────────────┘

Infrastructure:
  Eureka Server  :8761
  Config Server  :8888
```

## Services

| Service              | Port | Database               | Description                              |
|----------------------|------|------------------------|------------------------------------------|
| eureka-server        | 8761 | —                      | Service registry                         |
| config-server        | 8888 | —                      | Centralised configuration                |
| api-gateway          | 8080 | —                      | JWT auth filter + routing                |
| auth-service         | 8081 | educonnect_auth        | Register, login, user management         |
| student-service      | 8082 | educonnect_student     | Student profiles & documents             |
| course-service       | 8083 | educonnect_course      | Courses, enrolments & progress           |
| assessment-service   | 8084 | educonnect_assessment  | Assessments & submissions                |
| content-service      | 8085 | educonnect_content     | Course content & access tracking         |
| notification-service | 8086 | educonnect_notification| User notifications                       |
| compliance-service   | 8087 | educonnect_compliance  | Compliance records & audits              |

## Role Mapping (CityCare → EduConnect)

| CityCare Role          | EduConnect Role       |
|------------------------|-----------------------|
| CITIZEN                | STUDENT               |
| DOCTOR / NURSE         | TEACHER               |
| DISPATCHER             | PROGRAM_MANAGER       |
| COMPLIANCE_OFFICER     | COMPLIANCE_OFFICER    |
| CITY_HEALTH_OFFICER    | GOVERNMENT_AUDITOR    |
| ADMIN                  | ADMIN                 |

## OpenFeign Inter-Service Calls

- **auth-service → student-service**: After a STUDENT registers, auth-service auto-calls `student-service` via OpenFeign to create a student profile (`/api/students/internal/create`). Fallback: logs a warning; student can create their profile later.

## Prerequisites

- Java 21
- Maven 3.9+
- MySQL 8.0+

## Database Setup

Run once in MySQL before starting any service:

```sql
CREATE DATABASE educonnect_auth;
CREATE DATABASE educonnect_student;
CREATE DATABASE educonnect_course;
CREATE DATABASE educonnect_assessment;
CREATE DATABASE educonnect_content;
CREATE DATABASE educonnect_notification;
CREATE DATABASE educonnect_compliance;
```

## Startup Order

Start services **in this order**:

1. `eureka-server`      (wait for it to be ready at http://localhost:8761)
2. `config-server`      (wait for it to be ready at http://localhost:8888)
3. All other services in any order (they pull config from config-server on startup)
4. `api-gateway`        (last, after all downstream services have registered with Eureka)

```bash
# Example startup (each in a separate terminal)
cd eureka-server   && mvn spring-boot:run
cd config-server   && mvn spring-boot:run
cd auth-service    && mvn spring-boot:run
cd student-service && mvn spring-boot:run
cd course-service  && mvn spring-boot:run
cd assessment-service  && mvn spring-boot:run
cd content-service     && mvn spring-boot:run
cd notification-service && mvn spring-boot:run
cd compliance-service  && mvn spring-boot:run
cd api-gateway     && mvn spring-boot:run
```

## Configuration

All service configuration is centralised in **config-server**.
Edit files in `config-server/src/main/resources/config/` to change:
- Database URL / credentials
- JWT secret & expiration
- Server ports
- Eureka URL

The shared `application.properties` in the config folder applies to **all** services.
Each `<service-name>.properties` file overrides settings for that specific service.

## API Access via Gateway (port 8080)

| Route prefix         | Forwarded to         |
|----------------------|----------------------|
| `/auth/**`           | auth-service         |
| `/admin/**`          | auth-service         |
| `/students/**`       | student-service      |
| `/courses/**`        | course-service       |
| `/enrollments/**`    | course-service       |
| `/progress/**`       | course-service       |
| `/assessments/**`    | assessment-service   |
| `/submissions/**`    | assessment-service   |
| `/contents/**`       | content-service      |
| `/notifications/**`  | notification-service |
| `/compliance/**`     | compliance-service   |
| `/audits/**`         | compliance-service   |

## Swagger UI (per service)

Each service exposes Swagger UI at: `http://localhost:<port>/swagger-ui.html`

## JWT

- Secret is shared across `api-gateway` and all services via config-server.
- The gateway validates the token and forwards `X-Auth-User` header to downstream services.
- Individual services use the JWT secret to validate tokens independently as a second layer.
