package com.educonnect.notificationservice.service;

import com.educonnect.notificationservice.dto.NotificationRequest;
import com.educonnect.notificationservice.entity.Notification;
import com.educonnect.notificationservice.exception.ResourceNotFoundException;
import com.educonnect.notificationservice.repository.NotificationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock private NotificationRepository notificationRepository;
    @InjectMocks private NotificationService notificationService;

    private Notification notification;

    @BeforeEach
    void setUp() {
        notification = Notification.builder()
                .notificationId(1L).userId(5L)
                .message("Your enrollment was confirmed.")
                .category(Notification.NotificationCategory.COURSE)
                .status(Notification.NotificationStatus.UNREAD)
                .build();
    }

    @Test
    @DisplayName("createNotification – saves and returns notification")
    void createNotification_success() {
        NotificationRequest req = new NotificationRequest();
        req.setUserId(5L);
        req.setMessage("Your enrollment was confirmed.");
        req.setCategory(Notification.NotificationCategory.COURSE);

        when(notificationRepository.save(any(Notification.class))).thenReturn(notification);
        Notification result = notificationService.createNotification(req);

        assertThat(result.getUserId()).isEqualTo(5L);
        assertThat(result.getStatus()).isEqualTo(Notification.NotificationStatus.UNREAD);
        verify(notificationRepository).save(any(Notification.class));
    }

    @Test
    @DisplayName("getByUser – returns all notifications for user")
    void getByUser_returnsList() {
        when(notificationRepository.findByUserId(5L)).thenReturn(List.of(notification));
        List<Notification> result = notificationService.getByUser(5L);
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getUnreadByUser – returns only UNREAD notifications")
    void getUnreadByUser_returnsUnread() {
        when(notificationRepository.findByUserIdAndStatus(5L, Notification.NotificationStatus.UNREAD))
                .thenReturn(List.of(notification));
        List<Notification> result = notificationService.getUnreadByUser(5L);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStatus()).isEqualTo(Notification.NotificationStatus.UNREAD);
    }

    @Test
    @DisplayName("markAsRead – sets status to READ")
    void markAsRead_success() {
        when(notificationRepository.findById(1L)).thenReturn(Optional.of(notification));
        when(notificationRepository.save(any(Notification.class))).thenAnswer(inv -> inv.getArgument(0));
        Notification result = notificationService.markAsRead(1L);
        assertThat(result.getStatus()).isEqualTo(Notification.NotificationStatus.READ);
    }

    @Test
    @DisplayName("markAsRead – throws ResourceNotFoundException for unknown id")
    void markAsRead_notFound_throws() {
        when(notificationRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> notificationService.markAsRead(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("archive – sets status to ARCHIVED")
    void archive_success() {
        when(notificationRepository.findById(1L)).thenReturn(Optional.of(notification));
        when(notificationRepository.save(any(Notification.class))).thenAnswer(inv -> inv.getArgument(0));
        Notification result = notificationService.archive(1L);
        assertThat(result.getStatus()).isEqualTo(Notification.NotificationStatus.ARCHIVED);
    }

    @Test
    @DisplayName("archive – throws ResourceNotFoundException for unknown id")
    void archive_notFound_throws() {
        when(notificationRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> notificationService.archive(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }
}
