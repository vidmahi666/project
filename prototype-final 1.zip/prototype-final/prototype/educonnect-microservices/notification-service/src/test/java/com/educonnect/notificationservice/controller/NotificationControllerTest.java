package com.educonnect.notificationservice.controller;

import com.educonnect.notificationservice.dto.NotificationRequest;
import com.educonnect.notificationservice.entity.Notification;
import com.educonnect.notificationservice.exception.ResourceNotFoundException;
import com.educonnect.notificationservice.service.NotificationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(NotificationController.class)
class NotificationControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean NotificationService notificationService;

    @Test
    @DisplayName("POST /notifications – 201 on success")
    void create_returns201() throws Exception {
        NotificationRequest req = new NotificationRequest();
        req.setUserId(5L); req.setMessage("New enrollment!");
        req.setCategory(Notification.NotificationCategory.COURSE);

        Notification n = Notification.builder().notificationId(1L).userId(5L)
                .message("New enrollment!").status(Notification.NotificationStatus.UNREAD).build();
        when(notificationService.createNotification(any())).thenReturn(n);

        mockMvc.perform(post("/notifications")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.userId").value(5));
    }

    @Test
    @DisplayName("GET /notifications/user/{userId} – 200 with list")
    void getByUser_returns200() throws Exception {
        when(notificationService.getByUser(5L)).thenReturn(List.of());
        mockMvc.perform(get("/notifications/user/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("GET /notifications/user/{userId}/unread – 200 with list")
    void getUnread_returns200() throws Exception {
        when(notificationService.getUnreadByUser(5L)).thenReturn(List.of());
        mockMvc.perform(get("/notifications/user/5/unread"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("PATCH /notifications/{id}/read – 200 on success")
    void markRead_returns200() throws Exception {
        Notification n = Notification.builder().notificationId(1L)
                .status(Notification.NotificationStatus.READ).build();
        when(notificationService.markAsRead(1L)).thenReturn(n);

        mockMvc.perform(patch("/notifications/1/read"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("READ"));
    }

    @Test
    @DisplayName("PATCH /notifications/{id}/read – 404 when not found")
    void markRead_notFound_returns404() throws Exception {
        when(notificationService.markAsRead(99L))
                .thenThrow(new ResourceNotFoundException("Notification", 99L));
        mockMvc.perform(patch("/notifications/99/read"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("PATCH /notifications/{id}/archive – 200 on success")
    void archive_returns200() throws Exception {
        Notification n = Notification.builder().notificationId(1L)
                .status(Notification.NotificationStatus.ARCHIVED).build();
        when(notificationService.archive(1L)).thenReturn(n);

        mockMvc.perform(patch("/notifications/1/archive"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ARCHIVED"));
    }
}
