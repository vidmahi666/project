package com.educonnect.notificationservice;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
@SpringBootApplication @EnableJpaAuditing
public class NotificationServiceApplication{public static void main(String[] a){SpringApplication.run(NotificationServiceApplication.class,a);}}
