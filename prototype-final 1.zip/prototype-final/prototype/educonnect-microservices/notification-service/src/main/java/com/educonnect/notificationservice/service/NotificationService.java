package com.educonnect.notificationservice.service;
import com.educonnect.notificationservice.dto.NotificationRequest;
import com.educonnect.notificationservice.entity.Notification;
import com.educonnect.notificationservice.exception.ResourceNotFoundException;
import com.educonnect.notificationservice.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;
import java.util.List;
@Service @RequiredArgsConstructor
public class NotificationService{
    private final NotificationRepository notificationRepository;
    @Transactional public Notification createNotification(NotificationRequest req){
        return notificationRepository.save(Notification.builder().userId(req.getUserId())
                .entityId(req.getEntityId()).message(req.getMessage()).category(req.getCategory()).build());
    }
    public List<Notification> getByUser(Long userId){return notificationRepository.findByUserId(userId);}
    public List<Notification> getUnreadByUser(Long userId){return notificationRepository.findByUserIdAndStatus(userId,Notification.NotificationStatus.UNREAD);}
    @Transactional public Notification markAsRead(Long id){
        Notification n=notificationRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Notification",id));
        n.setStatus(Notification.NotificationStatus.READ);return notificationRepository.save(n);
    }
    @Transactional public Notification archive(Long id){
        Notification n=notificationRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Notification",id));
        n.setStatus(Notification.NotificationStatus.ARCHIVED);return notificationRepository.save(n);
    }
}
