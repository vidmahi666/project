import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
})
export class LandingComponent {
  stats = [
    { value: '12,000+', label: 'Active Learners', icon: 'bi-mortarboard-fill' },
    { value: '340+',    label: 'Expert Courses',  icon: 'bi-book-fill' },
    { value: '98%',     label: 'Compliance Rate', icon: 'bi-shield-check' },
    { value: '4.9★',    label: 'Average Rating',  icon: 'bi-star-fill' },
  ];

  features = [
    { icon: 'bi-mortarboard-fill',        tone: 'blue',   title: 'Smart Enrollment',        desc: 'Students enroll with one click and receive instant deadline notifications.' },
    { icon: 'bi-bar-chart-fill',          tone: 'mint',   title: 'Progress Tracking',       desc: 'Real-time dashboards show exactly where every learner stands.' },
    { icon: 'bi-clipboard-check-fill',    tone: 'gold',   title: 'Assessments & Grading',   desc: 'Create quizzes, assignments and exams with automatic grading workflows.' },
    { icon: 'bi-shield-check',            tone: 'purple', title: 'Compliance & Audits',     desc: 'Automated compliance checks and full audit trails for regulatory needs.' },
    { icon: 'bi-people-fill',             tone: 'rose',   title: 'Multi-Role Platform',     desc: 'Tailored dashboards for students, teachers, admins, and auditors.' },
    { icon: 'bi-bell-fill',               tone: 'blue',   title: 'Smart Notifications',     desc: 'Timely alerts for enrollments, deadlines, grades and announcements.' },
  ];

  roles = [
    { icon: 'bi-mortarboard',      tone: 'blue',   label: 'Students',    items: ['Enroll in courses', 'Track progress', 'Take assessments', 'Get deadline alerts'] },
    { icon: 'bi-person-video2',    tone: 'mint',   label: 'Teachers',    items: ['Create courses', 'Upload content', 'Grade submissions', 'Monitor students'] },
    { icon: 'bi-shield-fill',      tone: 'gold',   label: 'Admins',      items: ['Manage all users', 'Compliance oversight', 'Audit trails', 'Platform reports'] },
    { icon: 'bi-search',           tone: 'purple', label: 'Auditors',    items: ['Review audit logs', 'Compliance reports', 'Flag issues', 'Export data'] },
  ];
}
