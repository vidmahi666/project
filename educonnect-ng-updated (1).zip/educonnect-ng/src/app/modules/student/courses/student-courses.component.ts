import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService, NotificationService } from '../../../core/services/index';
import { ToastService } from '../../../core/services/index';
import { Course, Enrollment } from '../../../core/models';

@Component({
  selector: 'app-student-courses',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './student-courses.component.html',
  styleUrls: ['./student-courses.component.scss'],
})
export class StudentCoursesComponent implements OnInit {
  private auth      = inject(AuthService);
  private courseSvc = inject(CourseService);
  private enrollSvc = inject(EnrollmentService);
  private notifSvc  = inject(NotificationService);
  private toast     = inject(ToastService);
  private route     = inject(ActivatedRoute);

  loading    = signal(true);
  enrolling  = signal<number | null>(null);
  allCourses = signal<Course[]>([]);
  enrolledIds = signal<Set<number>>(new Set());
  search = signal('');
  activeTab  = 'all';

  tabs = [
    { key: 'all',      label: 'All Courses' },
    { key: 'enrolled', label: 'Enrolled' },
    { key: 'active',   label: 'Active' },
  ];

  private COLORS = ['blue','mint','gold','purple','rose'];
  private ICONS  = ['bi-book','bi-code-slash','bi-bar-chart-line','bi-flask','bi-music-note-beamed','bi-camera','bi-globe'];

  colorOf(c: Course): string { return this.COLORS[c.courseId % this.COLORS.length]; }
  iconOf(c: Course):  string { return this.ICONS[c.courseId  % this.ICONS.length]; }
  isNew(c: Course): boolean {
    const d = new Date(c.createdAt ?? '');
    return !isNaN(d.getTime()) && (Date.now() - d.getTime()) < 7 * 86400000;
  }

  tabCount(key: string): number {
    if (key === 'all')      return this.allCourses().length;
    if (key === 'enrolled') return this.enrolledIds().size;
    if (key === 'active')   return this.allCourses().filter(c => c.status === 'ACTIVE').length;
    return 0;
  }

  filtered = computed(() => {
    let list = this.allCourses();
    if (this.activeTab === 'enrolled') list = list.filter(c => this.enrolledIds().has(c.courseId));
    if (this.activeTab === 'active')   list = list.filter(c => c.status === 'ACTIVE');
    const q = this.search().trim().toLowerCase();
    if (q) list = list.filter(c =>
      c.title.toLowerCase().includes(q) || (c.description ?? '').toLowerCase().includes(q)
    );
    return list;
  });

  ngOnInit(): void {
    // Support search from topbar query param
    this.route.queryParams.subscribe(params => {
      if (params['q']) this.search.set(params['q']);
    });

    this.courseSvc.getAll().subscribe({
      next: r => { if (r.success) this.allCourses.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
    const sId = this.auth.userId() ?? 1;
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => { if (r.success) this.enrolledIds.set(new Set((r.data ?? []).map(e => e.courseId))); },
    });
  }

  enroll(c: Course): void {
    const sId = this.auth.userId() ?? 1;
    this.enrolling.set(c.courseId);
    this.enrollSvc.enroll({ studentId: sId, courseId: c.courseId }).subscribe({
      next: r => {
        this.enrolling.set(null);
        if (r.success) {
          this.enrolledIds.update(s => { s.add(c.courseId); return new Set(s); });
          this.toast.success('Enrolled!', `You are now enrolled in "${c.title}"`);
          this.notifSvc.create({
            userId: sId,
            message: `Enrolled in "${c.title}". Your learning journey begins now!`,
            category: 'COURSE' as any,
          }).subscribe();
          if (c.endDate) {
            this.notifSvc.create({
              userId: sId,
              message: `Deadline: "${c.title}" ends on ${new Date(c.endDate).toLocaleDateString()}. Plan accordingly!`,
              category: 'COURSE' as any,
            }).subscribe();
          }
        } else {
          this.toast.error('Enroll failed', r.message);
        }
      },
      error: err => { this.enrolling.set(null); this.toast.error('Enroll failed', err?.error?.message); },
    });
  }
}
