import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AuditService, ToastService } from '../../../core/services/index';
import { Audit, AuditLog, AuditStatus } from '../../../core/models';

@Component({
  selector: 'app-admin-audits',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './admin-audits.component.html',
  styleUrls: ['./admin-audits.component.scss'],
})
export class AdminAuditsComponent implements OnInit {
  private auth     = inject(AuthService);
  private auditSvc = inject(AuditService);
  private toast    = inject(ToastService);
  private fb       = inject(FormBuilder);

  loading      = signal(true);
  logsLoading  = signal(true);
  saving       = signal(false);
  showModal    = signal(false);
  audits       = signal<Audit[]>([]);
  auditLogs    = signal<AuditLog[]>([]);
  formError    = signal('');
  activeTab    = signal<'audits' | 'logs'>('audits');
  logsSearch = signal('');

  form = this.fb.nonNullable.group({
    title:         ['', Validators.required],
    description:   [''],
    auditorUserId: [null as unknown as number],
  });

  filteredLogs = computed(() => {
    const q = this.logsSearch().trim().toLowerCase();
    if (!q) return this.auditLogs();
    return this.auditLogs().filter(l =>
      (l.action ?? '').toLowerCase().includes(q) ||
      (l.entityType ?? '').toLowerCase().includes(q) ||
      (String(l.userId ?? '')).toLowerCase().includes(q)
    );
  });

  statusSummary = () => [
    { label: 'Scheduled',   tone: 'blue',   icon: 'bi-calendar-check',  count: this.audits().filter(a => a.status === 'SCHEDULED').length },
    { label: 'In Progress', tone: 'gold',   icon: 'bi-hourglass-split', count: this.audits().filter(a => a.status === 'IN_PROGRESS').length },
    { label: 'Completed',   tone: 'mint',   icon: 'bi-patch-check-fill', count: this.audits().filter(a => a.status === 'COMPLETED').length },
    { label: 'Cancelled',   tone: 'rose',   icon: 'bi-x-circle-fill',   count: this.audits().filter(a => a.status === 'CANCELLED').length },
  ];

  statusIcon(s: AuditStatus): string {
    const m: Partial<Record<AuditStatus, string>> = {
      SCHEDULED: 'bi-calendar-check', IN_PROGRESS: 'bi-hourglass-split',
      COMPLETED: 'bi-patch-check-fill', CANCELLED: 'bi-x-circle-fill',
    };
    return m[s] ?? 'bi-search';
  }

  ngOnInit(): void {
    this.loadAudits();
    this.loadLogs();
  }

  loadAudits(): void {
    this.auditSvc.getAll().subscribe({
      next: r => { if (r.success) this.audits.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  loadLogs(): void {
    this.auditSvc.getLogs().subscribe({
      next: r => { if (r.success) this.auditLogs.set(r.data ?? []); this.logsLoading.set(false); },
      error: () => this.logsLoading.set(false),
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const v = this.form.getRawValue();
    this.auditSvc.create({ ...v, auditorUserId: v.auditorUserId || undefined }).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.audits.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Audit initiated', `"${r.data.title}" has been created.`);
        } else { this.formError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  updateStatus(a: Audit, status: string): void {
    this.auditSvc.updateStatus(a.auditId, status).subscribe({
      next: r => {
        if (r.success) {
          this.audits.update(arr => arr.map(x => x.auditId === a.auditId ? { ...x, status: status as AuditStatus } : x));
          this.toast.success('Updated', `Audit marked as ${status}.`);
        }
      },
    });
  }

  exportPdf(): void {
    const data = this.activeTab() === 'audits' ? this.audits() : this.auditLogs();
    const title = this.activeTab() === 'audits' ? 'Audits Report' : 'Audit Logs Report';
    this.generatePdf(title, data);
  }

  private generatePdf(title: string, data: any[]): void {
    const printContent = this.buildPrintHtml(title, data);
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(printContent);
      win.document.close();
      win.focus();
      setTimeout(() => { win.print(); win.close(); }, 500);
    }
  }

  private buildPrintHtml(title: string, data: any[]): string {
    const isLogs = this.activeTab() === 'logs';
    const rows = data.map(item => {
      if (isLogs) {
        return `<tr>
          <td>${item.logId ?? ''}</td>
          <td>${item.action ?? ''}</td>
          <td>${item.entityType ?? ''}</td>
          <td>${item.entityId ?? ''}</td>
          <td>${String(item.userId ?? '')}</td>
          <td>${item.timestamp ? new Date(item.timestamp).toLocaleString() : ''}</td>
        </tr>`;
      }
      return `<tr>
        <td>${item.auditId ?? ''}</td>
        <td>${item.title ?? ''}</td>
        <td>${item.status ?? ''}</td>
        <td>${item.auditorUserId ?? 'N/A'}</td>
        <td>${item.timestamp ? new Date(item.timestamp).toLocaleString() : ''}</td>
        <td>${item.description ?? ''}</td>
      </tr>`;
    }).join('');

    const headers = isLogs
      ? '<tr><th>ID</th><th>Action</th><th>Entity Type</th><th>Entity ID</th><th>Performed By</th><th>Date</th></tr>'
      : '<tr><th>ID</th><th>Title</th><th>Status</th><th>Auditor ID</th><th>Created</th><th>Description</th></tr>';

    return `<!DOCTYPE html><html><head><title>${title}</title>
    <style>
      body { font-family: Arial, sans-serif; padding: 20px; }
      h1 { color: #1e40af; font-size: 1.4rem; border-bottom: 2px solid #1e40af; padding-bottom: 8px; }
      p.meta { color: #64748b; font-size: .85rem; margin: 4px 0 16px; }
      table { width: 100%; border-collapse: collapse; font-size: .85rem; }
      th { background: #1e40af; color: white; padding: 8px 10px; text-align: left; }
      td { padding: 7px 10px; border-bottom: 1px solid #e2e8f0; }
      tr:nth-child(even) td { background: #f8fafc; }
    </style></head><body>
    <h1>${title}</h1>
    <p class="meta">Generated: ${new Date().toLocaleString()} | Total records: ${data.length}</p>
    <table><thead>${headers}</thead><tbody>${rows}</tbody></table>
    </body></html>`;
  }
}
