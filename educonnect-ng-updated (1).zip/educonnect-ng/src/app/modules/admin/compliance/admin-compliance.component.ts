import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ComplianceService, ToastService } from '../../../core/services/index';
import { ComplianceRecord, ComplianceResult, ComplianceType } from '../../../core/models';

@Component({
  selector: 'app-admin-compliance',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './admin-compliance.component.html',
  styleUrls: ['./admin-compliance.component.scss'],
})
export class AdminComplianceComponent implements OnInit {
  readonly ComplianceResult = ComplianceResult;

  private complianceSvc = inject(ComplianceService);
  private toast         = inject(ToastService);
  private fb            = inject(FormBuilder);

  loading    = signal(true);
  saving     = signal(false);
  showModal  = signal(false);
  records    = signal<ComplianceRecord[]>([]);
  formError  = signal('');
  search = signal('');

  compTypes: ComplianceType[] = [
    ComplianceType.COURSE,
    ComplianceType.ASSESSMENT,
    ComplianceType.PROGRAM,
    ComplianceType.CONTENT,
  ];

  form = this.fb.nonNullable.group({
    entityId: [null as unknown as number, Validators.required],
    type:     ['', Validators.required],
    notes:    [''],
  });

  filteredRecords = computed(() => {
    const q = this.search().trim().toLowerCase();
    if (!q) return this.records();
    return this.records().filter(r =>
      (r.type ?? '').toLowerCase().includes(q) ||
      (r.result ?? '').toLowerCase().includes(q) ||
      String(r.entityId).includes(q)
    );
  });

  countByResult(r: string): number {
    return this.records().filter(x => (x.result ?? 'UNDER_REVIEW') === r).length;
  }

  ngOnInit(): void {
    this.complianceSvc.getAll().subscribe({
      next: r => { if (r.success) this.records.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    this.complianceSvc.create(this.form.getRawValue() as any).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.records.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Record added', 'Compliance record created.');
        } else { this.formError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  setResult(rec: ComplianceRecord, result: ComplianceResult): void {
    this.complianceSvc.updateResult(rec.complianceId, result).subscribe({
      next: r => {
        if (r.success) {
          this.records.update(arr => arr.map(x => x.complianceId === rec.complianceId ? { ...x, result } : x));
          this.toast.success('Updated', `Record marked as ${result}.`);
        }
      },
    });
  }

  exportPdf(): void {
    const data = this.filteredRecords();
    const rows = data.map(r => `
      <tr>
        <td>${r.complianceId}</td>
        <td>${r.entityId}</td>
        <td>${r.type}</td>
        <td><span class="r-${(r.result ?? 'UNDER_REVIEW').toLowerCase().replace('_','-')}">${r.result ?? 'UNDER_REVIEW'}</span></td>
        <td>${r.recordDate ? new Date(r.recordDate).toLocaleDateString() : ''}</td>
        <td>${r.notes ?? ''}</td>
      </tr>`).join('');

    const html = `<!DOCTYPE html><html><head><title>Compliance Records</title>
    <style>
      body { font-family: Arial, sans-serif; padding: 20px; }
      h1 { color: #1e40af; font-size: 1.4rem; border-bottom: 2px solid #1e40af; padding-bottom: 8px; }
      .meta { color: #64748b; font-size: .85rem; margin: 4px 0 16px; }
      table { width: 100%; border-collapse: collapse; font-size: .85rem; }
      th { background: #1e40af; color: white; padding: 8px 10px; text-align: left; }
      td { padding: 7px 10px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
      tr:nth-child(even) td { background: #f8fafc; }
      .r-compliant { color: #065f46; font-weight: 600; }
      .r-non-compliant { color: #991b1b; font-weight: 600; }
      .r-under-review { color: #92400e; font-weight: 600; }
      .r-remediated { color: #1e40af; font-weight: 600; }
    </style></head><body>
    <h1>Compliance Records Report</h1>
    <p class="meta">Generated: ${new Date().toLocaleString()} | Total: ${data.length} records</p>
    <table>
      <thead><tr><th>ID</th><th>Entity ID</th><th>Type</th><th>Result</th><th>Recorded</th><th>Notes</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    </body></html>`;

    const win = window.open('', '_blank');
    if (win) { win.document.write(html); win.document.close(); win.focus(); setTimeout(() => { win.print(); win.close(); }, 500); }
  }
}
