import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ReportService, AdminUserService, CourseService, EnrollmentService } from '../../../core/services/index';
import { DashboardMetrics, User } from '../../../core/models';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss'],
})
export class AdminDashboardComponent implements OnInit {
  private auth       = inject(AuthService);
  private reportSvc  = inject(ReportService);
  private adminSvc   = inject(AdminUserService);
  private courseSvc  = inject(CourseService);

  loadingMetrics = signal(true);
  loadingUsers   = signal(true);
  metrics        = signal<DashboardMetrics | null>(null);
  recentUsers    = signal<User[]>([]);
  totalCourses   = signal(0);
  error          = signal('');

  quickActions = [
    { label: 'User Management', desc: 'Roles & accounts',  icon: 'bi-people-fill',            route: '/admin/users',      tone: 'blue' },
    { label: 'Courses',         desc: 'All platform courses', icon: 'bi-book-fill',            route: '/admin/courses',    tone: 'mint' },
    { label: 'Compliance',      desc: 'Policy records',    icon: 'bi-shield-check',            route: '/admin/compliance', tone: 'gold' },
    { label: 'Audits',          desc: 'Formal audits',     icon: 'bi-search',                  route: '/admin/audits',     tone: 'purple' },
    { label: 'Reports',         desc: 'Analytics & KPIs',  icon: 'bi-file-earmark-bar-graph',  route: '/admin/reports',    tone: 'rose' },
  ];

  adminName = computed(() => (this.auth.user()?.name ?? 'Admin').split(' ')[0]);

  ngOnInit(): void {
    // Try to get dashboard metrics first
    this.reportSvc.getDashboard().subscribe({
      next: r => {
        if (r.success && r.data) {
          this.metrics.set(r.data);
        }
        this.loadingMetrics.set(false);
      },
      error: () => {
        // Fallback: compute from raw data
        this.computeMetricsFromData();
      },
    });

    this.adminSvc.getAllUsers().subscribe({
      next: r => {
        if (r.success) this.recentUsers.set((r.data ?? []).slice(0, 6));
        this.loadingUsers.set(false);
        // Build fallback metrics from user list
        const users = r.data ?? [];
        if (!this.metrics()) {
          this.metrics.update(m => ({
            ...(m ?? {} as any),
            totalStudents: users.filter(u => u.role === 'STUDENT').length,
            totalTeachers: users.filter(u => u.role === 'TEACHER').length,
          } as DashboardMetrics));
        }
      },
      error: () => this.loadingUsers.set(false),
    });

    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          this.totalCourses.set((r.data ?? []).length);
          if (!this.metrics()) {
            this.metrics.update(m => ({ ...(m ?? {} as any), totalCourses: r.data?.length ?? 0 } as DashboardMetrics));
          }
        }
      }
    });
  }

  private computeMetricsFromData(): void {
    this.loadingMetrics.set(false);
  }
}
